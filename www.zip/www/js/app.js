// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic','ngRoute','firebase','ngMap','ng-mfb'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
.service('jsonsave', function () {
        var property = {};

        return {
            getProperty: function () {
                return property;
            },
            setProperty: function(value) {
                property = value;
            }
        };
    })
.service('checknwstate', function ($ionicPopup) {
      this.checkConnection = function (exitAppl) {
			var networkState = navigator.connection.type;
				if (exitAppl == true) {	
					if (networkState == "none") {
						var alertPopup = $ionicPopup.alert({
						  title: 'Network Error!',
						  template: 'No internet connection found.'
						});
						alertPopup.then(function(res) {
						  navigator.app.exitApp();
						});
					}
				}
				else{
					if (networkState == "none") {
						var alertPopup = $ionicPopup.alert({
						  title: 'Network Error!',
						  template: 'No internet connection found.'
						});
					}
					
				}
				}
				
    })
.controller("maincontroller",function($scope,$location,$firebaseObject,$filter){ // this controller is run at once and used to initialize firebase at once
	var config = {
    apiKey: "AIzaSyAW_skoUZVzOJKBEUg4tbtkSNKuGAreInQ",
    authDomain: "cordovatravelapp.firebaseapp.com",
    databaseURL: "https://cordovatravelapp.firebaseio.com",
    storageBucket: "cordovatravelapp.appspot.com",
    messagingSenderId: "830405359657"
  };
  	firebase.initializeApp(config); 
})

.controller("splashController",function($scope,$location,$timeout,checknwstate){ //this controller is used to load splash screen and to autologin of user
	//checknwstate.checkConnection(true);

	$timeout(function () {
			//localStorage.setItem("username","");
			var userName = localStorage.getItem("username");
		
			console.log("splashControllerUsername",userName)
			if(userName== "" || userName == null){
				$location.path('/log');
			}
			else{
				$location.path('/main');
			}
		}, 3000);
})

.controller("regController",function($scope,$location,$timeout,$firebaseObject,$ionicPopup,checknwstate,$ionicPlatform){
	//controller for registering the new user
	$scope.cancel = function(){
		//checknwstate.checkConnection(false);

		/*var alertPopup = $ionicPopup.alert({
			title: 'Alert',
			template: 'Canceled !'
		});*/
		$location.path("/log");

	}
	$scope.showbtn = function(){
		//checknwstate.checkConnection(false);

		if(($scope.userName == null || $scope.userName =="") && ($scope.pswd ==null || $scope.pswd =="") && ($scope.confpswd ==null || $scope.confpswd ==""))
		{	
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'All fields are Mandatory '
			});
		}
		else if(($scope.userName == null || $scope.userName =="")){
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'Email is not valid !'
			});
		}
		else if(($scope.pswd ==null || $scope.pswd =="")){
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'Password is not valid !'
			});
		}
		else if(($scope.confpswd ==null || $scope.confpswd =="")){
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'Confirm Password is not valid !'
			});
		}
		else{
			
			var isgen;
			
			if($scope.pswd==$scope.confpswd){
				$scope.userAuth = function(){
					if(isgen!=false){
						var alertPopup = $ionicPopup.alert({
						title: 'Success !',
						template:'User registered Successfully !'
						});
						$location.path('/log');
					}else{
						var alertPopup = $ionicPopup.alert({
						title: 'Error',
						template: 'Password do not match ! '
					});
					}
				}
				
				$timeout(function() {
				firebase.auth().createUserWithEmailAndPassword($scope.userName,$scope.pswd).catch(function(error) {
					var errorCode = error.code;
					console.log(errorCode);
					var errorMessage = error.message;
					console.log(errorMessage);
					var alertPopup = $ionicPopup.alert({
					title: 'Error',
					template:errorMessage
					});
					isgen = false;
					//$scope.userAuth();
				});
				
				
				})
				$scope.userAuth();
			}else{
				var alertPopup = $ionicPopup.alert({
					title: 'Error',
					template: 'Password do not match ! '
				});
			}
	
		}
	}
	$ionicPlatform.registerBackButtonAction(function(event) {
		//checknwstate.checkConnection(false);

		$timeout(function () {
			navigator.app.exitApp();
		})
	}, 100);	
}).controller("logcontroller",function($scope,$location,$timeout,$firebaseObject,$ionicPopup,$ionicLoading,$firebaseAuth,checknwstate,$ionicPlatform,$route){
	
	$scope.reg = function(){
		//checknwstate.checkConnection(false);

		$location.path('/reg');
	} 
	$scope.showbtn = function(){
		//checknwstate.checkConnection(false);


		if(($scope.userName == null || $scope.userName =="") && ($scope.pswd ==null || $scope.pswd ==""))
		{
			
			//checknwstate.checkConnection(false);

				var alertPopup = $ionicPopup.alert({
					title: '',
					template: 'All fields are Mandatory '
				});
			

		}
		else if($scope.userName == null || $scope.userName ==""){
				//checknwstate.checkConnection(false);

				var alertPopup = $ionicPopup.alert({
					title: '',
					template: 'Email address is not valid !'
				});
			}
		else if($scope.pswd ==null || $scope.pswd ==""){
			//checknwstate.checkConnection(false);

				var alertPopup = $ionicPopup.alert({
					title: '',
					template: 'Password is not valid !'
				});
			
		}
		else{
			//if($scope.$error.username)
				var isauth;// = true;
				
			$timeout(function() {
				firebase.auth().signInWithEmailAndPassword($scope.userName, $scope.pswd).catch(function(error) {
				// Handle Errors here.
					var errorCode = error.code;
					console.log(errorCode);
					var errorMessage = error.message;
					console.log(errorMessage);
					isauth = false;
					$scope.userAuth();
				// ...
				});
				
				
				firebase.auth().onAuthStateChanged(function(user) {
				if (user) {
				// User is signed in.
				 console.log(user.uid);
				 $scope.uid  = user.uid;
				 localStorage.setItem("username",$scope.uid);
				 console.log(localStorage.getItem("username"))
				 console.log($scope.uid )
				 $scope.userAuth();
				 $route.reload();
				} else {
					// No user is signed in.
				}
				});
				
				
				//console.log(fou);
				console.log(isauth)
				
				
			})
			$scope.userAuth = function(){
			if(isauth!=false){
					//checknwstate.checkConnection(false);

					console.log($scope.uid)
					//localStorage.setItem("username",$scope.uid);
					$location.path('/main');
					
					}
					else{
					//checknwstate.checkConnection(false);


						var alertPopup = $ionicPopup.alert({
						title: 'Alert',
						template: 'Wrong Username or Password !'
						
					});
					}
				}
		}
	}
	
	$ionicPlatform.registerBackButtonAction(function(event) {
					//checknwstate.checkConnection(false);


	$timeout(function () {
		navigator.app.exitApp();
	})
	}, 100);

})
.controller("appcontroller",function($scope,$location,$firebaseObject,$filter,$timeout,$state,jsonsave,$ionicPopup,$ionicLoading,checknwstate,$ionicPlatform){
	//checknwstate.checkConnection(false);

	var jsondata = {};
			$ionicLoading.show({
			  template: 'Loading...'
			}).then(function(){
			   console.log("The Sending indicator is now displayed");
			});
	var username = localStorage.getItem("username");
	console.log("appcontrUsername",username);
	var starCountRef = firebase.database().ref('users/'+username);
	console.log(starCountRef);
		starCountRef.on('value', function(snapshot) {
			console.log(snapshot.val());
			$timeout(function() {
   
		jsondata = snapshot.val();
		console.log(jsondata);
		$scope.jsondata = jsondata;
		jsonsave.setProperty(jsondata);
		//checknwstate.checkConnection(false);

		$ionicLoading.hide().then(function(){
			   console.log("The progressDialog indicator is now hidden");
			});
		
		  });
	});
	//$scope.loading = false;
		 
 
	$scope.deletedata = function(index){
		//alert(index);
		var jsondata = jsonsave.getProperty();
		var lastIndex = Object.keys(jsondata).length-1;
		if(index!=(lastIndex))
		{
		
			for(var i= index ;i<lastIndex;i++){
				
				var dataAtIndex = firebase.database().ref('users/'+username+'/'+i);
				//var dataNextToIndex = firebase.database().ref('users/'+(i+1));
				dataAtIndex.set({
				
					destination: jsondata[i+1].destination,
					startd: jsondata[i+1].startd,
					endd: jsondata[i+1].endd,
					notes: jsondata[i+1].notes	
			})
			}
			var dataAtIndex = firebase.database().ref('users/'+username+'/'+lastIndex);
			dataAtIndex.remove();
		}
		else{
			var dataAtIndex = firebase.database().ref('users/'+username+'/'+index);
			dataAtIndex.remove();
		}
		
		var alertPopup = $ionicPopup.alert({
			title: 'Alert',
			template: 'Data Deleted Successfully ! '
		});
	}
	
	$scope.openform = function(){
		//alert("openform")			
		//checknwstate.checkConnection(false);

			$location.path('/app');	 
		}	
	$scope.showdet = function(index){
		//checknwstate.checkConnection(false);

		$location.path('/tab/'+index);
	}
	$scope.logout = function(){ 
		//checknwstate.checkConnection(false);

		localStorage.setItem("username", "");
		$timeout(function() {
		firebase.auth().signOut().then(function() {
			console.log('Signed Out');
				}, function(error) {
			console.error('Sign Out Error', error);
			});
		});	
	}
	$ionicPlatform.registerBackButtonAction(function(event) {
	//checknwstate.checkConnection(false);

	$timeout(function () {
		navigator.app.exitApp();
	})
	}, 100);
})

.controller("tabcontroller",function($scope,$location,$firebaseObject,$filter,$routeParams,jsonsave,$ionicPlatform,$timeout,checknwstate){
	//alert("tabcontroller");
	//alert($routeParams.index);
	console.log(jsonsave.getProperty())
				//checknwstate.checkConnection(false);


	$scope.data = jsonsave.getProperty()[$routeParams.index].destination;
	$scope.index = $routeParams.index;
	$scope.adddata = function(ind){
		//checknwstate.checkConnection(false);

		if(ind == 1){$location.path('/hotelform/'+$scope.index); }else if(ind == 2){$location.path('/thingstodoform/'+$scope.index); }else if(ind == 3){$location.path('/flightform/'+$scope.index); }else if(ind == 4){$location.path('/transportform/'+$scope.index); }else{$location.path('/shoppingform/'+$scope.index); }
	}
	$scope.showdet = function(ind){
		//alert("inside here")
		//checknwstate.checkConnection(false);

		if(ind == 1){$location.path('/hotelview/'+ $scope.index +'/data/' + ind); }else if(ind == 2){$location.path('/thingstodoview/'+$scope.index+'/data/' + ind); }else if(ind == 3){$location.path('/flightview/'+$scope.index+'/data/' + ind); }else if(ind == 4){$location.path('/transportview/'+$scope.index+'/data/' + ind); }else{$location.path('/shoppingview/'+$scope.index+'/data/' + ind); }
	}
	
	$scope.googleMapsUrl="http://maps.google.com/maps/api/js?key=AIzaSyCtgm4Xc72R7SJuyVB1SVwL72IaAATVVyk"
	if(jsonsave.getProperty()[$routeParams.index].hotel != null)
	{
		$scope.hotel = jsonsave.getProperty()[$routeParams.index].hotel[0].city;}
		$scope.backbtnmain = function(){
		//checknwstate.checkConnection(false);

		$location.path("/main");
	}
	$scope.logout = function(){ 
		//checknwstate.checkConnection(false);

		localStorage.setItem("username", "");
		$timeout(function() {
		firebase.auth().signOut().then(function() {
			console.log('Signed Out');
				}, function(error) {
			console.error('Sign Out Error', error);
			});
		});
	}

	$ionicPlatform.registerBackButtonAction(function(event) {
	//checknwstate.checkConnection(false);

	$timeout(function () {
		$location.path("/main");
	})
	}, 100);
})


.controller("formcontroller",function($scope,$location,$firebaseObject,$filter,jsonsave,$ionicPopup,$ionicPlatform,$timeout,checknwstate){
	//alert("formcontroller");	
	$scope.showbtn = function(){
		console.log($scope.startd);
		console.log($scope.endd);
		//checknwstate.checkConnection(false);

		if(jsonsave.getProperty() == null){
			index =0;
		}
		else 
		{
			var obj = jsonsave.getProperty();
			var index = Object.keys(obj).length
		}
		
		console.log(index);
		var username = localStorage.getItem("username");
		console.log(username);
		if($scope.destination != null && $scope.destination !="" && $scope.notes !=null && $scope.notes !="" && $scope.startd !=null && $scope.startd !=""&& $scope.endd !=null && $scope.endd !="")
		{
			if($scope.startd<=$scope.endd){
				//alert("true");
				var username = localStorage.getItem("username");
				var database = firebase.database();
				database.ref('users/'+username+'/' + index).set({
				destination: $scope.destination,
				startd: $filter('date')($scope.startd,'yyyy-MM-dd').toString(),
				endd: $filter('date')($scope.endd,'yyyy-MM-dd').toString(),
				notes: $scope.notes  })
				
				/* var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Data Added Successfully !'
					
				}); */
				$location.path("/main");
				
			}
			else{
				var alertPopup = $ionicPopup.alert({
					title: 'Error',
					template: 'Invalidate date ! '
				});
			}
		}
		else{
			var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Fill All Details ! '
				});
		}	
		}
	$scope.cancel = function(){	
		//checknwstate.checkConnection(false);

		/*var alertPopup = $ionicPopup.alert({
			title: 'Alert',
			template: 'Canceled !'
		});*/
		$location.path("/main");
	}
	
	
	$ionicPlatform.registerBackButtonAction(function(event) {
	//checknwstate.checkConnection(false);

	$timeout(function () {
		$location.path("/main");
	})
	}, 100);
	
})

.controller("catformcontroller",function($scope,$location,$firebaseObject,$routeParams,$filter,jsonsave,$ionicPopup,$ionicPlatform,$timeout,checknwstate){
	var username = localStorage.getItem("username");
	$scope.ObjTask = {};
	$scope.ObjHotel = {};
	$scope.ObjFlight = {};
	$scope.objTransport = {};
	$scope.objShopping = {};
	$scope.hotelform = function(){
		//checknwstate.checkConnection(false);

		if(jsonsave.getProperty()[$routeParams.index].hotel == null){
			ind =0;
		}
		else 
		{
			var obj = jsonsave.getProperty()[$routeParams.index].hotel
			var ind = Object.keys(obj).length
		}
		//alert(ind)
		
		if($scope.ObjHotel.name != null && $scope.ObjHotel.name !="" && $scope.ObjHotel.city !=null && $scope.ObjHotel.city !=""&& $scope.ObjHotel.state !=null && $scope.ObjHotel.state !="" && $scope.ObjHotel.cid !=null && $scope.ObjHotel.cid !=""&& $scope.ObjHotel.cod !=null && $scope.ObjHotel.cod !="")
		{
		 if($scope.ObjHotel.cid<=$scope.ObjHotel.cod){
			//alert("true");
			
			
			$timeout(function () {
			var database = firebase.database();
			database.ref('users/'+username+'/'+ $routeParams.index +'/hotel/' + ind).set({
			name: $scope.ObjHotel.name,
			city: $scope.ObjHotel.city,
			state: $scope.ObjHotel.state,
			cid: $filter('date')($scope.ObjHotel.cid,'yyyy-MM-dd').toString(),
			cod: $filter('date')($scope.ObjHotel.cod,'yyyy-MM-dd').toString()
			 })
			 /* var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Data Added Successfully !'
				}); */
				//$location.path('/tab/'+$routeParams.index);
				$location.path('/hotelview/'+ $routeParams.index+'/data/' + 1);
			})
		}
		else{
			var alertPopup = $ionicPopup.alert({
					title: 'Error',
					template: 'Invalidate date ! '
				});
			}
		}
		else{
			var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Fill All Details ! '
				});
		}
		
	}
	$scope.flightform = function(){
	//checknwstate.checkConnection(false);

		if(jsonsave.getProperty()[$routeParams.index].flight == null){
			ind =0;
		}
		else 
		{
			var obj = jsonsave.getProperty()[$routeParams.index].flight
			var ind = Object.keys(obj).length
		}
		//alert(ind)
if($scope.ObjFlight.airoplane != null && $scope.ObjFlight.airoplane !="" && $scope.ObjFlight.fn !=null && $scope.ObjFlight.fn !=""&& $scope.ObjFlight.fromw !=null && $scope.ObjFlight.fromw !="" &&$scope.ObjFlight.tow !=null && $scope.ObjFlight.tow !="" && $scope.ObjFlight.fromd !=null && $scope.ObjFlight.fromd !=""&& $scope.ObjFlight.tod !=null && $scope.ObjFlight.tod !="")
		{	
		 if($scope.ObjFlight.fromd<=$scope.ObjFlight.tod){
			//alert("true");
			$timeout(function () {
			var database = firebase.database();
			database.ref('users/'+username+'/'+ $routeParams.index +'/flight/' + ind).set({
			airoplane: $scope.ObjFlight.airoplane,
			flight_no: $scope.ObjFlight.fn,
			from_: $scope.ObjFlight.fromw,
			to: $scope.ObjFlight.tow,
			fromd: $filter('date')($scope.ObjFlight.fromd,'yyyy-MM-dd').toString(),
			tod: $filter('date')($scope.ObjFlight.tod,'yyyy-MM-dd').toString()
			 })
			 /* var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Data Added Successfully !'
				}); */
				//$location.path('/tab/'+$routeParams.index);
				$location.path('/flightview/'+$routeParams.index+'/data/' + 3);
			})
		}
		else{
			var alertPopup = $ionicPopup.alert({
					title: 'Error',
					template: 'Invalidate date ! '
				});
		} 
	}
	else{
		var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Fill All Details ! '
				});
		
	}
	}
	$scope.thingstodoform = function(){
		//checknwstate.checkConnection(false);

		if(jsonsave.getProperty()[$routeParams.index].thingstodo == null){
			ind =0;
		}
		else 
		{
			var obj = jsonsave.getProperty()[$routeParams.index].thingstodo
			var ind = Object.keys(obj).length
		}
		console.log($scope.objTask.task);
			if($scope.objTask.task!=null && $scope.objTask.task!=""){
			
			$timeout(function () {
				var database = firebase.database();
				database.ref('users/'+username+'/'+ $routeParams.index +'/thingstodo/' + ind).set({
				task: $scope.objTask.task
				})
				
				$location.path('/thingstodoview/'+$routeParams.index+'/data/' + 2);
				
			});
			 /* var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Data Added Successfully !'
				}); */
				//$location.path('/tab/'+$routeParams.index);
				
				
			 
			}else{
				var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Fill All Details ! '
				});
			}
		
	}
	$scope.transportform = function(){
		//checknwstate.checkConnection(false);

		if(jsonsave.getProperty()[$routeParams.index].transport == null){
			ind =0;
		}
		else 
		{
			var obj = jsonsave.getProperty()[$routeParams.index].transport
			var ind = Object.keys(obj).length
		}
		//alert(ind)
		if($scope.objTransport.trasnp != null && $scope.objTransport.trasnp !="" && $scope.objTransport.fromw !=null && $scope.objTransport.fromw !="" &&$scope.objTransport.tow !=null && $scope.objTransport.tow !="" && $scope.objTransport.fromd !=null && $scope.objTransport.fromd !=""&& $scope.objTransport.tod !=null && $scope.objTransport.tod !="")
		{
		 if($scope.objTransport.fromd<=$scope.objTransport.tod){
			//alert("true");
			$timeout(function () {
			var database = firebase.database();
			database.ref('users/'+username+'/'+ $routeParams.index +'/transport/' + ind).set({
			trasnp: $scope.objTransport.trasnp,
			from_: $scope.objTransport.fromw,
			to: $scope.objTransport.tow,
			fromd: $filter('date')($scope.objTransport.fromd,'yyyy-MM-dd').toString(),
			tod: $filter('date')($scope.objTransport.tod,'yyyy-MM-dd').toString()
			 })
			  /* var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Data Added Successfully !'
				}); */
				//$location.path('/tab/'+$routeParams.index);
				$location.path('/transportview/'+$routeParams.index+'/data/' + 4);
			})
		}
		else{
			var alertPopup = $ionicPopup.alert({
					title: 'Error',
					template: 'Invalidate date ! '
				});
		} 
		}else{
			var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Fill All Details ! '
				});
			
		}
	}
	$scope.shoppingform = function(){
		//checknwstate.checkConnection(false);

		if(jsonsave.getProperty()[$routeParams.index].shopping == null){
			ind =0;
		}
		else 
		{
			var obj = jsonsave.getProperty()[$routeParams.index].shopping
			var ind = Object.keys(obj).length
		}
	if($scope.objShopping.item != null && $scope.objShopping.item !="" && $scope.objShopping.details !=null && $scope.objShopping.details !="" &&$scope.objShopping.quantity !=null && $scope.objShopping.quantity !="")
	{
		$timeout(function () {

		var database = firebase.database();
			database.ref('users/'+username+'/'+ $routeParams.index +'/shopping/' + ind).set({
			item: $scope.objShopping.item,
			details: $scope.objShopping.details,
			quantity: $scope.objShopping.quantity
			
			 })
			/* var alertPopup = $ionicPopup.alert({
					title: 'Alert',
					template: 'Data Added Successfully !'
			}); */
			//$location.path('/tab/'+$routeParams.index);
			$location.path('/shoppingview/'+$routeParams.index+'/data/' + 5);
			})
	}
	else{
		var alertPopup = $ionicPopup.alert({
			title: 'Alert',
			template: 'Fill All Details ! '
		});
	}
	}
	$scope.cancel = function(){
		//checknwstate.checkConnection(false);

		
		/*var alertPopup = $ionicPopup.alert({
			title: 'Alert',
			template: 'Canceled !'
		});*/
		$location.path('/tab/'+$routeParams.index);
	
	}
	
	$ionicPlatform.registerBackButtonAction(function(event) {
	$timeout(function () {
	$location.path('/tab/'+$routeParams.index);	})
	}, 100);
	
	
})
.controller("showlistcontroller",function($scope,$location,$firebaseObject,$routeParams,$filter,jsonsave,$ionicPopup,$ionicPlatform,$timeout,checknwstate){
	//checknwstate.checkConnection(false);

	$scope.catind = $routeParams.ind;
	 if($scope.catind == 1){
		if(jsonsave.getProperty()[$routeParams.index].hotel!= null){
			$scope.obj = jsonsave.getProperty()[$routeParams.index].hotel
		}else {
				$scope.obj = {}
				var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'No data found !'
				});
				$location.path('/tab/'+$routeParams.index);
			}
	}else if($scope.catind == 2){
		if(jsonsave.getProperty()[$routeParams.index].thingstodo != null){
			$scope.obj = jsonsave.getProperty()[$routeParams.index].thingstodo
		}else {
			$scope.obj = {}
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'No data found !'
				});
				$location.path('/tab/'+$routeParams.index);
			}	
	}else if($scope.catind == 3){
		if(jsonsave.getProperty()[$routeParams.index].flight != null){
			$scope.obj = jsonsave.getProperty()[$routeParams.index].flight
		}else {
			$scope.obj = {}
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'No data found !'
				});
				$location.path('/tab/'+$routeParams.index);
			}
	}else if($scope.catind == 4){
		if(jsonsave.getProperty()[$routeParams.index].transport != null){
			$scope.obj = jsonsave.getProperty()[$routeParams.index].transport
		}else {
			$scope.obj = {}
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'No data found ! '
				});
				$location.path('/tab/'+$routeParams.index);
			}	
	}else{
		if(jsonsave.getProperty()[$routeParams.index].shopping != null){
			$scope.obj = jsonsave.getProperty()[$routeParams.index].shopping
		}else {
			$scope.obj = {}
			var alertPopup = $ionicPopup.alert({
				title: '',
				template: 'No data found !'
				});
				$location.path('/tab/'+$routeParams.index);
			}	
	}
	$scope.backbtnview = function(){
		$location.path('/tab/'+$routeParams.index);
		//checknwstate.checkConnection(false);

	}
	
	$scope.logout = function(){ 
		localStorage.setItem("username", "");
		$timeout(function() {
		firebase.auth().signOut().then(function() {
			console.log('Signed Out');
				}, function(error) {
			console.error('Sign Out Error', error);
			});
			
		});
	}
	$ionicPlatform.registerBackButtonAction(function(event) {
	$timeout(function () {
		//checknwstate.checkConnection(false);

		$location.path('/tab/'+$routeParams.index);
	})
	}, 100);
	
})
.config(['$routeProvider',function($routeProvider){
	$routeProvider.when('/main', {
		controller: 'appcontroller',
		templateUrl: 'main.html'
	}).when('/app', {
		controller: 'formcontroller',
		templateUrl: 'form.html'
	}).when('/tab/:index', {
		controller: 'tabcontroller',
		templateUrl: 'app.html'
	}).when('/hotelform/:index', {
		controller: 'catformcontroller',
		templateUrl: 'hotelform.html'
	}).when('/flightform/:index', {
		controller: 'catformcontroller',
		templateUrl: 'flightform.html'
	}).when('/shoppingform/:index', {
		controller: 'catformcontroller',
		templateUrl: 'shoppingform.html'
	}).when('/thingstodoform/:index', {
		controller: 'catformcontroller',
		templateUrl: 'thigstodoform.html'
	}).when('/transportform/:index', {
		controller: 'catformcontroller',
		templateUrl: 'transportform.html'
	}).when('/hotelview/:index/data/:ind', {
		controller: 'showlistcontroller',
		templateUrl: 'hotelview.html'
	}).when('/flightview/:index/data/:ind', {
		controller: 'showlistcontroller',
		templateUrl: 'flightview.html'
	}).when('/shoppingview/:index/data/:ind', {
		controller: 'showlistcontroller',
		templateUrl: 'shoppingview.html'
	}).when('/thingstodoview/:index/data/:ind', {
		controller: 'showlistcontroller',
		templateUrl: 'todolistview.html'
	}).when('/transportview/:index/data/:ind', {
		controller: 'showlistcontroller',
		templateUrl: 'transportview.html'
	}).when('/reg', {
		controller: 'regController',
		templateUrl: 'reg.html'
	}).when('/log', {
		controller: 'logcontroller',
		templateUrl: 'log.html'
	}).otherwise({ 
		 url: '/splash',
		controller: 'splashController',
		templateUrl: 'splash.html',
	});
	
	}] 
)





