Instructions / Manual

Installing softwares:

1: Your PC must have java jdk installed for more information click here --> https://www.youtube.com/watch?v=evoLlsLFn10 .
2: Please use notpade++ for opening txt files get it from here --> https://notepad-plus-plus.org/download/v7.5.html .

Directory structure:

1: Before Running your app you must have folder "caffe" in your c: drive with 1)"input" 2)"output" 3)"total" folders inside this.

Structure will be like this.
1) "caffe" --> "C:\caffe".
2) "input" --> "C:\caffe\input".
2) "output" --> "C:\caffe\output".
2) "total" --> "C:\caffe\total".

2: copy and paste input.txt inside "input" folder you just created.

input.txt -->

this file consist of your menu 

edit this with comma seperated values 1st is "index" 2nd is "name" of item and 3rd is price of item.

example --> you have an item named cold_coffee worth Rs 60 then edit input.txt with values
1,cold_coffee,60 
like this complete the menu

Run App:
double click on caffe.bat file and you will get an cmd line interface to run the app
press 1 to add transaction then add the index of item and quantity .
press 2 for generating total.
press y for continue process and n for stop the process .


every day new files are generated with their repective date.

transactions are added into "output" folder and total is generated in "total" folder.

