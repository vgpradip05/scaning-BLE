package com.example.pradipkumarv.myproject;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.Space;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;

import com.example.pradipkumarv.myproject.config.Config;

import java.util.Locale;

public class SplashActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferencesObj;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);

        final String langData = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY, null);
     if(langData==null){
        new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if(isStoragePermissionGranted()){
                        Toast.makeText(SplashActivity.this,"Thanks :-)",Toast.LENGTH_LONG).show();
                    }else{
                        ActivityCompat.requestPermissions(SplashActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                        Toast.makeText(SplashActivity.this,"Some function may not work properly",Toast.LENGTH_LONG).show();
                    }

                    startActivity(new Intent(SplashActivity.this,ChangeInLanguage.class));
                }
            },3000);
        }

        else{
         setLocale(langData);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    //setLocale(langData);
                    startActivity(new Intent(SplashActivity.this,MainActivity.class));
                    finish();
                }
            },3000);
        }

    }
    public void setLocale(String lang) {
        Resources res = SplashActivity.this.getResources();
        // Change locale settings in the app.
        DisplayMetrics dm = res.getDisplayMetrics();
        android.content.res.Configuration conf = res.getConfiguration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            setSystemLocale(conf, new Locale(lang.toLowerCase()));
        }else{
            setSystemLocaleLegacy(conf, new Locale(lang.toLowerCase()));
        }
        res.updateConfiguration(conf, dm);
        //startActivity(new Intent(this,MainActivity.class));
        //finish();
        //this.setContentView(R.layout.activity_main);
    }

   /* @Override
    protected void onPause() {
        super.onPause();
        finish();
    }*/
    public  boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.v("Permission","Permission is granted");
                return true;
            } else {

                Log.v("Permission","Permission is revoked");
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        }
        else { //permission is automatically granted on sdk<23 upon installation
            Log.v("Permission","Permission is granted");
            return true;
        }
    }

    @SuppressWarnings("deprecation")
    public Locale getSystemLocaleLegacy(Configuration config){
        return config.locale;
    }

    @TargetApi(Build.VERSION_CODES.N)
    public Locale getSystemLocale(Configuration config){
        return config.getLocales().get(0);
    }

    @SuppressWarnings("deprecation")
    public void setSystemLocaleLegacy(Configuration config, Locale locale){
        config.locale = locale;
    }

    @TargetApi(Build.VERSION_CODES.N)
    public void setSystemLocale(Configuration config, Locale locale){
        config.setLocale(locale);
    }


}
