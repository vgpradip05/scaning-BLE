package com.example.pradipkumarv.myproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.example.pradipkumarv.myproject.config.Config;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class ShowDetails extends AppCompatActivity {


    SwipeFlingAdapterView flingContainer ;
    List<DataModel> detailList;
    List<DataModel> offLineList;
    SDCustomAdapter sdCustomAdapter;
    DataModel dataModelSp;
    private SharedPreferences sharedPreferencesObj;
    Gson myGson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Config.changeTheme(ShowDetails.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_details);
        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
*/
        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);

        flingContainer = (SwipeFlingAdapterView) findViewById(R.id.frame);
        Gson gson = new Gson();
        DataModel tempdataModel ;
        detailList = new ArrayList<>();
        int position;
        Bundle bundle = getIntent().getExtras();

        String data = bundle.getString("data");
        String array = bundle.getString("array");
        String pos = bundle.getString("pos");

        Type dataType = new TypeToken<DataModel>(){}.getType();
        tempdataModel = gson.fromJson(data, dataType);

        Type arrayType = new TypeToken<List<DataModel>>(){}.getType();
        detailList = gson.fromJson(array, arrayType);

        Type posType = new TypeToken<Integer>(){}.getType();
        position = gson.fromJson(pos, posType);


        detailList.remove(position);
        detailList.add(0,tempdataModel);

        sdCustomAdapter = new SDCustomAdapter(ShowDetails.this,detailList);




        flingContainer.setAdapter(sdCustomAdapter);




       flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
           @Override
           public void removeFirstObjectInAdapter() {
               detailList.remove(0);
               sdCustomAdapter.notifyDataSetChanged();
           }

           @Override
           public void onLeftCardExit(Object o) {

           }

           @Override
           public void onRightCardExit(Object o) {

           }

           @Override
           public void onAdapterAboutToEmpty(int i) {

           }

           @Override
           public void onScroll(float v) {
              /* View view = flingContainer.getSelectedView();
               view.findViewById(R.id.item_swipe_right_indicator).setAlpha(scrollProgressPercent < 0 ? -scrollProgressPercent : 0);
               view.findViewById(R.id.item_swipe_left_indicator).setAlpha(scrollProgressPercent > 0 ? scrollProgressPercent : 0);*/
           }
       });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_download) {

            //Toast.makeText(this,"Download",Toast.LENGTH_LONG).show();
            dataModelSp = new DataModel();
            dataModelSp = detailList.get(0);
            ImageLoader imageLoader = AppController.getInstance().getImageLoader();
            // If you are using normal ImageView
            imageLoader.get(dataModelSp.getImgSrc(), new ImageLoader.ImageListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("VOLLEY IMAGE", "Image Load Error: " + error.getMessage());
                }

                @Override
                public void onResponse(ImageLoader.ImageContainer response, boolean arg1) {
                    if (response.getBitmap() != null) {
                        // load image into imageview

                        Gson gson2 = new Gson();
                        Type typeOfT = new TypeToken<List<DataModel>>() {}.getType();
                        String root = Environment.getExternalStorageDirectory().toString();
                        File myDir = new File(root + "/saved_images");
                        myDir.mkdirs();
                        String fname = dataModelSp.getNewsTitle() +".jpg";
                        File file = new File (myDir, fname);
                        if (file.exists ()) file.delete ();

                        try {
                            FileOutputStream out = new FileOutputStream(file);
                            response.getBitmap().compress(Bitmap.CompressFormat.JPEG, 90, out);
                            out.flush();
                            out.close();

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    dataModelSp.setImgSrc(dataModelSp.getNewsTitle()+".jpg");
                        String liststring = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_OFFLINE, null);
                        if(liststring==null){
                            offLineList=new ArrayList<>();
                        }else {
                            offLineList = gson2.fromJson(liststring, typeOfT);
                        }
                        SharedPreferences.Editor editor = sharedPreferencesObj.edit();

                        offLineList.add(dataModelSp);

                        myGson = new Gson();
                        String todo = myGson.toJson(offLineList);
                        editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_OFFLINE, todo);
                        editor.commit();
                        Toast.makeText(getBaseContext(),"Page is saved offline",Toast.LENGTH_LONG).show();
                    }
                }
            });

        }
        else if (id == R.id.action_share){

            dataModelSp = new DataModel();
            dataModelSp = detailList.get(0);
            String shareBody = dataModelSp.getNewsUrl();
            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, dataModelSp.getNewsTitle());
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share Using?"));

        }


        return super.onOptionsItemSelected(item);
    }


}
