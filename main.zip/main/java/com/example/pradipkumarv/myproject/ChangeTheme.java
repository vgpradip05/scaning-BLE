package com.example.pradipkumarv.myproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

import com.example.pradipkumarv.myproject.config.Config;

public class ChangeTheme extends AppCompatActivity {

    Switch swNightMode;
    private SharedPreferences sharedPreferencesObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);
        final String themeName = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_THEME, getString(R.string.app_theme));
        if (themeName.equals(getString(R.string.dark_theme))) {
            setTheme(R.style.DarkTheme);
        } else {
            setTheme(R.style.AppTheme);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_theme);
        swNightMode = (Switch) findViewById(R.id.sw_night_mode);


        if (themeName.equals("NIGHT")) {
            swNightMode.setChecked(true);
        } else {
            swNightMode.setChecked(false);
        }

        swNightMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    SharedPreferences.Editor editor = sharedPreferencesObj.edit();
                    editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_THEME, "NIGHT");
                    editor.commit();

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChangeTheme.this);

                    LayoutInflater inflater = ChangeTheme.this.getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.alert_layout, null);
                    alertDialogBuilder.setView(dialogView);

                    Button bYes = (Button) dialogView.findViewById(R.id.byes);
                    Button bNo = (Button) dialogView.findViewById(R.id.bno);

                    bYes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            recreateActivity();
                        }
                    });

                    bNo.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            finish();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                } else if (!isChecked) {
                    SharedPreferences.Editor editor = sharedPreferencesObj.edit();
                    editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_THEME, "DAY");
                    editor.commit();
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChangeTheme.this);

                    LayoutInflater inflater = ChangeTheme.this.getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.alert_layout, null);
                    alertDialogBuilder.setView(dialogView);

                    Button bYes = (Button) dialogView.findViewById(R.id.byes);
                    Button bNo = (Button) dialogView.findViewById(R.id.bno);

                    bYes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            recreateActivity();
                        }
                    });

                    bNo.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            finish();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
    }
    public void recreateActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        finish();
        startActivity(intent);
    }
}
