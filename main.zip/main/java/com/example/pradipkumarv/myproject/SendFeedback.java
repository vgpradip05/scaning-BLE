package com.example.pradipkumarv.myproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pradipkumarv.myproject.config.Config;

public class SendFeedback extends AppCompatActivity {

    EditText etEmail,etDesc,etSub;
    Button bSend,bCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Config.changeTheme(SendFeedback.this);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_send_feedback);

        etEmail = (EditText) findViewById(R.id.etEmail);
        etDesc = (EditText) findViewById(R.id.etDesc);
        etSub = (EditText) findViewById(R.id.etSub);

        bSend = (Button)findViewById(R.id.bSend);
        bCancel = (Button)findViewById(R.id.bCancel);

        bSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"pradipkumar.vishwakarma@paramatrix.co.in"});
                i.putExtra(Intent.EXTRA_SUBJECT, etSub.getText().toString());
                i.putExtra(Intent.EXTRA_TEXT   , etDesc.getText().toString());
                try {
                    startActivity(Intent.createChooser(i, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(SendFeedback.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                }

            }
        });
        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
