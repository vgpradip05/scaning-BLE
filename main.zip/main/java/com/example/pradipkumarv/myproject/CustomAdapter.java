package com.example.pradipkumarv.myproject;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by pradipkumarv on 04-11-2016.
 */
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.example.pradipkumarv.myproject.tab.fragment.HeadLines;

import java.util.List;

public class CustomAdapter extends BaseAdapter {
    Activity context;
    List<DataModel> dataArray;

    public CustomAdapter(Activity context, List<DataModel> dataArray) {
        this.context = context;
        this.dataArray = dataArray;

    }

    @Override
    public int getCount() {
        return dataArray.size();
    }

    @Override
    public Object getItem(int position) {
        return dataArray.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater anInflater = context.getLayoutInflater();
        final ViewGroup myViewGp = (ViewGroup) anInflater.inflate(R.layout.cardview_layout, null);
        TextView newsTitle = (TextView) myViewGp.findViewById(R.id.tv_newsTitle);
        TextView newsSrc = (TextView) myViewGp.findViewById(R.id.tv_newsSrc);
        NetworkImageView newsImg = (NetworkImageView) myViewGp.findViewById(R.id.iv_newsImage);

        newsTitle.setText(dataArray.get(position).getNewsTitle());
        newsSrc.setText(dataArray.get(position).getNewsAuthor());
        ImageLoader imageLoader = AppController.getInstance().getImageLoader();

        //newsImg.setImageResource(R.drawable.logo);
        String imgUrl = dataArray.get(position).getImgSrc();
        if (imgUrl != null)
            newsImg.setImageUrl(imgUrl, imageLoader);
        return myViewGp;
    }
}
