package com.example.pradipkumarv.myproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.pradipkumarv.myproject.config.Config;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class ChangeInNewsLanguage extends AppCompatActivity {
    List<String> langArray;
    private SharedPreferences sharedPreferencesObj;
    ListView langListView;
    ArrayAdapter<String> arrayAdapter;
    String langObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //------------------------------------Check at the start which theme to load------------------------
        Config.changeTheme(ChangeInNewsLanguage.this);
        //---------------------------------------------------------------------------------------------------
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_in_langauge);
        langListView = (ListView) findViewById(R.id.langListView);
        langArray = new ArrayList<>();
        langArray.add(getString(R.string.English));
        langArray.add(getString(R.string.Hindi));
        langArray.add(getString(R.string.Malayalam));
        langArray.add(getString(R.string.Tamil));
        langArray.add(getString(R.string.Bengali));
        langArray.add(getString(R.string.Punjabi));
        langArray.add(getString(R.string.Urdu));

        arrayAdapter = new ArrayAdapter<>(this, R.layout.layout_arrayadapter, R.id.adapter_text, langArray);

        langListView.setAdapter(arrayAdapter);

        langListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                langObj = langArray.get(position);

                if (langObj.equals(getString(R.string.English))) {
                    saveAtFile("english");
                } else if (langObj.equals(getString(R.string.Tamil))) {
                    saveAtFile("tamil");
                } else if (langObj.equals(getString(R.string.Bengali))) {
                    saveAtFile("bengali");
                } else if (langObj.equals(getString(R.string.Hindi))) {
                    saveAtFile("hindi");
                } else if (langObj.equals(getString(R.string.Malayalam))) {
                    saveAtFile("malayalam");
                } else if (langObj.equals(getString(R.string.Urdu))) {
                    saveAtFile("urdu");
                } else if (langObj.equals(getString(R.string.Punjabi))) {
                    saveAtFile("punjabi");
                }
            }
        });


    }

    public void saveAtFile(String lang) {

        //---------------Storing the language in Shared Prefernces-------------

        SharedPreferences.Editor editor = sharedPreferencesObj.edit();

        //myGson = new Gson();
        // String todo = myGson.toJson(lang);
        editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_NEWS_LANG, lang);
        editor.commit();

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        finish();
        startActivity(intent);
        //-----------------------------------------------------------------------------------
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
