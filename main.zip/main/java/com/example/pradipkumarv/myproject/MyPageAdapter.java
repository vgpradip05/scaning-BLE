package com.example.pradipkumarv.myproject;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.pradipkumarv.myproject.tab.fragment.HeadLines;

/**
 * Created by pradipkumarv on 28-10-2016.
 */
public class MyPageAdapter extends FragmentPagerAdapter {
    int mNumOfTabs;
    MainActivity mainActivity;

    public MyPageAdapter(FragmentManager fm, int NumOfTabs, MainActivity mainActivity) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
        this.mainActivity = mainActivity;
    }

    @Override
    public Fragment getItem(int position) {

        return HeadLines.newInstance(position,mainActivity);
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return mainActivity.getString(R.string.Headlines);
            case 1:
                return mainActivity.getString(R.string.Entertainment);
            case 2:
                return mainActivity.getString(R.string.Technology);
            case 3:
                return mainActivity.getString(R.string.Sports);
            case 4:
                return mainActivity.getString(R.string.World);
        }
        return null;
    }
}
