package com.example.pradipkumarv.myproject;

import android.app.Activity;
import android.content.Context;

import android.content.Intent;
import android.content.SharedPreferences;


import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;

import android.support.annotation.RequiresApi;

import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;


import android.support.v7.app.ActionBar;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;


import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;


import com.example.pradipkumarv.myproject.config.Config;

import com.mxn.soul.flowingdrawer_core.FlowingView;
import com.mxn.soul.flowingdrawer_core.LeftDrawerLayout;


public class MainActivity extends AppCompatActivity {

    TextView tv_NetworkError;

    public Activity mainActivity;
    private SharedPreferences sharedPreferencesObj;
    ActionBar actionBar;
    LeftDrawerLayout mLeftDrawerLayout;
    public static boolean OPEN = true;
    public static boolean CLOSE = false;
    public static boolean isOpen = CLOSE;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        changeAppTheme();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Config.init("pradipkumarv", "Pradip@123");
        mainActivity = this;

        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);

        checkConnectivity();
        initInstances();

        //------------------------------Custom drawer layout---------------------------------
        //https://github.com/mxn21/FlowingDrawer --------------------- github link for documentation
        mLeftDrawerLayout = (LeftDrawerLayout) findViewById(R.id.flowingDrawerLayout);
        FragmentManager fm = getSupportFragmentManager();
        MyMenuFragment mMenuFragment = (MyMenuFragment) fm.findFragmentById(R.id.id_container_menu);
        FlowingView mFlowingView = (FlowingView) findViewById(R.id.flowingView);
        if (mMenuFragment == null) {
            fm.beginTransaction().add(R.id.id_container_menu, mMenuFragment = new MyMenuFragment()).commit();
        }
        mLeftDrawerLayout.setFluidView(mFlowingView);
        mLeftDrawerLayout.setMenuFragment(mMenuFragment);
        //--------------------------------------------------------------------------------------------
        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);

        //------------------------ set up tabLayout with viewpager------------------------------------
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
        //--------------------------------------------------------------------------------------------
        final MyPageAdapter adapter = new MyPageAdapter(getSupportFragmentManager(), 5, MainActivity.this);
        viewPager.setOffscreenPageLimit(5);//sets limit that how many pages should load in advance
        viewPager.setAdapter(adapter);

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void changeAppTheme() {
        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);
        final String themeName = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_THEME, getString(R.string.app_theme));
        if (themeName.equals(getString(R.string.dark_theme))) {
            setTheme(R.style.DarkTheme);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                getWindow().setStatusBarColor(getResources().getColor(R.color.primaryi));
            }
        } else if (themeName.equals(getString(R.string.app_theme))) {
            setTheme(R.style.AppTheme);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                getWindow().setStatusBarColor(getResources().getColor(R.color.primary));
            }
        }
    }


    //-------------------------------------- To check network connectivity---------------------------
    public void checkConnectivity() {
        //tv_NetworkError = (TextView) findViewById(R.id.tv_netWorkError);
        //tv_NetworkError.setVisibility(View.GONE);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
        if (netInfo == null) {
           // tv_NetworkError.setVisibility(View.VISIBLE);
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);

            LayoutInflater inflater = MainActivity.this.getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.alert_layout, null);
            alertDialogBuilder.setView(dialogView);

            TextView tvTitle = (TextView)dialogView.findViewById(R.id.tvAlertTitle);
            Button bYes = (Button) dialogView.findViewById(R.id.byes);
            Button bNo = (Button) dialogView.findViewById(R.id.bno);

            bNo.setVisibility(View.INVISIBLE);
            bYes.setText("OK");
            tvTitle.setText(getString(R.string.Network_error));
            final AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();

            bYes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });










        }

    }

    //----------------------------------------------------------------------------------------------
    private void initInstances() {
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayUseLogoEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(false);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowHomeEnabled(false);


        ActionBar.LayoutParams lp1 = new ActionBar.LayoutParams(android.app.ActionBar.LayoutParams.MATCH_PARENT, android.app.ActionBar.LayoutParams.MATCH_PARENT);
        View customNav = LayoutInflater.from(this).inflate(R.layout.layout_actionbar, null); // layout which contains your button.

        final Button actionB = (Button) customNav.findViewById(R.id.baction);
        actionB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isOpen){
                    mLeftDrawerLayout.openDrawer();
                    isOpen = OPEN;
                    actionB.setBackground(getResources().getDrawable(R.drawable.menuback));
                }
                else{
                    mLeftDrawerLayout.closeDrawer();
                    isOpen = CLOSE;
                    actionB.setBackground(getResources().getDrawable(R.drawable.menu));
                }
            }
        });
        actionBar.setCustomView(customNav, lp1);





        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);
        final String State = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_NOTF, "ENABLE");

        if (State.equals("ENABLE")) {
            Intent serviceStart = new Intent(MainActivity.this, MorningNews.class);
            startService(serviceStart);//start a service
        } else {
            AppController.getInstance().stopService();
            //At first you have to unbind the service from the previous activity in onStop().
            // Otherwise you may met a window leaked exception. hence it is defined in AppController
        }
    }
}
