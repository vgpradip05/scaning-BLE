package com.example.pradipkumarv.myproject;

/**
 * Created by pradipkumarv on 16-11-2016.
 */

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.SwitchCompat;
import android.text.SpannableString;
import android.text.style.TextAppearanceSpan;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.example.pradipkumarv.myproject.config.Config;
import com.mxn.soul.flowingdrawer_core.MenuFragment;


public class MyMenuFragment extends MenuFragment {
    NavigationView navigation;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_menu, container,
                false);
        navigation = (NavigationView) view.findViewById(R.id.navigation_view);






        Menu menu = navigation.getMenu();

        MenuItem extras= menu.findItem(R.id.navigation_view_category_1);
        MenuItem settings= menu.findItem(R.id.navigation_view_category_2);
        MenuItem help= menu.findItem(R.id.navigation_view_category_3);


        SpannableString e = new SpannableString(extras.getTitle());
        e.setSpan(new TextAppearanceSpan(getActivity(), R.style.TextAppearance44), 0, e.length(), 0);
        extras.setTitle(e);

        SpannableString s = new SpannableString(settings.getTitle());
        s.setSpan(new TextAppearanceSpan(getActivity(), R.style.TextAppearance44), 0, s.length(), 0);
        settings.setTitle(s);

        SpannableString h = new SpannableString(help.getTitle());
        h.setSpan(new TextAppearanceSpan(getActivity(), R.style.TextAppearance44), 0, h.length(), 0);
        help.setTitle(h);

        navigation.post(new Runnable() {
            @Override
            public void run() {//post method is called whenever the view is ready
                Menu menu = navigation.getMenu();
                SwitchCompat switchCompat = (SwitchCompat) MenuItemCompat.getActionView(menu.findItem(R.id.navigation_item_6)).findViewById(R.id.drawer_switch);
                //get Switch of notification
                final SharedPreferences sharedPreferencesObj = getActivity().getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, getActivity().MODE_PRIVATE);
                String State = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_NOTF, "ENABLE");

                if (State.equals("ENABLE")) {
                    switchCompat.setChecked(true);
                }
                switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (!isChecked) {
                            SharedPreferences.Editor editor = sharedPreferencesObj.edit();

                            editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_NOTF, "DISABLE");
                            editor.commit();
                            AppController.getInstance().stopService();
                        } else if (isChecked) {
                            SharedPreferences.Editor editor = sharedPreferencesObj.edit();
                            editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_NOTF, "ENABLE");
                            editor.commit();
                        }
                    }
                });
            }
        });

        navigation.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int id = menuItem.getItemId();
                switch (id) {
                    case R.id.navigation_item_1:

                        startActivity(new Intent(view.getContext(), SavedArticle.class));
                        Toast.makeText(view.getContext(), "Item 1", Toast.LENGTH_LONG).show();
                        break;
                  /*  case R.id.navigation_item_2:

                        break;*/
                    case R.id.navigation_item_3:

                        startActivity(new Intent(view.getContext(), ChangeInNewsLanguage.class));

                        break;
                    case R.id.navigation_item_4:

                        startActivity(new Intent(view.getContext(),ChangeInLanguage.class));

                        break;
                    case R.id.navigation_item_5:

                        startActivity(new Intent(view.getContext(), ChangeTheme.class));

                        break;
                    case R.id.navigation_item_6:
                        //do nothing
                        break;
                    case R.id.navigation_item_7:
                        startActivity(new Intent(view.getContext(),SendFeedback.class));
                        break;
                    case R.id.navigation_item_8:
                        Intent i = new Intent(android.content.Intent.ACTION_VIEW);
                        i.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.example.pradipkumarv.myproject"));
                        startActivity(i);
                        break;
                    case R.id.navigation_item_9:

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(view.getContext());

                        LayoutInflater inflater = getActivity().getLayoutInflater();
                        View dialogView = inflater.inflate(R.layout.about_us_layout, null);
                        alertDialogBuilder.setView(dialogView);

                        final Button bOk = (Button) dialogView.findViewById(R.id.bOk);


                        final AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();

                        bOk.setOnClickListener(new View.OnClickListener() {
                           @Override
                           public void onClick(View v) {
                               alertDialog.dismiss();
                           }
                       });

                        break;
                }
                return false;
            }
        });
        return setupReveal(view);
    }

    public void onOpenMenu() {
        //Toast.makeText(getActivity(),"onOpenMenu",Toast.LENGTH_SHORT).show();
    }

    public void onCloseMenu() {
        //Toast.makeText(getActivity(),"onCloseMenu",Toast.LENGTH_SHORT).show();
    }
}