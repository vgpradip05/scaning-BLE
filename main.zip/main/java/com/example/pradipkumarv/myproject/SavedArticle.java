package com.example.pradipkumarv.myproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.pradipkumarv.myproject.config.Config;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class SavedArticle extends AppCompatActivity {
    List<DataModel> offLineList;
    CustomAdapterSaved customAdapterSaved;
    DataModel dataModelSp;
    private SharedPreferences sharedPreferencesObj;
    Gson myGson;
    int positionToRemove;
    ListView listviewSaved;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==619)
        {
            //String message=data.getStringExtra("MESSAGE");
            //textView1.setText(message);

            if(data != null) {
                positionToRemove = data.getExtras().getInt("pos");

                offLineList.remove(positionToRemove);


                SharedPreferences.Editor editor = sharedPreferencesObj.edit();

                myGson = new Gson();
                String todo = myGson.toJson(offLineList);
                editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY_OFFLINE, todo);
                editor.commit();


                customAdapterSaved.notifyDataSetChanged();
            }
            else{
                //do nothing
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Config.changeTheme(SavedArticle.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_article);
        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, MODE_PRIVATE);
        String liststring = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_OFFLINE, null);
        Type typeOfT = new TypeToken<List<DataModel>>() {}.getType();

        myGson = new Gson();
        listviewSaved = (ListView) findViewById(R.id.listviewSaved);

        if(liststring==null){
            offLineList=new ArrayList<>();
        }else {
            offLineList = myGson.fromJson(liststring, typeOfT);
        }

        customAdapterSaved = new CustomAdapterSaved(SavedArticle.this,offLineList);

        listviewSaved.setAdapter(customAdapterSaved);


        listviewSaved.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(SavedArticle.this,ShowSavedData.class);
                dataModelSp = offLineList.get(position);
                Gson gson = new Gson();
                String Model;
                Model = gson.toJson(dataModelSp);

                Bundle bundle = new Bundle();

                bundle.putString("Model",Model);
                bundle.putInt("pos",position);
                intent.putExtras(bundle);
                startActivityForResult(intent,619);
            }
        });


    }
}
