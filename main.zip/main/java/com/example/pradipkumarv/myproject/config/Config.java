package com.example.pradipkumarv.myproject.config;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.pradipkumarv.myproject.R;

import org.json.JSONObject;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/**
 * Created by pradipkumarv on 08-11-2016.
 */
public class Config {
    public static final String MY_SHARED_PREFERENCE_FILE = "mySharedPreferenceFile";
    public static final String SHARED_PREF_FILE_OBJ_KEY = "langData";
    public static final String SHARED_PREF_FILE_OBJ_KEY_THEME = "themeData";
    public static final String SHARED_PREF_FILE_OBJ_KEY_OFFLINE = "offlineData";
    public static final String SHARED_PREF_FILE_OBJ_KEY_NEWS_LANG = "newsLang";
    public static final String SHARED_PREF_FILE_OBJ_KEY_NOTF = "notification";
    public static JSONObject COMPLETE_JSON_OBJ;
    public static String TAG_JSON_OBJ = "json_obj_req";
    public static String NEWS_URL = "https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20thread.country%3AIN%20(site_type%3Anews)";


    static class ProxyAuthenticator extends Authenticator {

        private String user, password;


        public ProxyAuthenticator(String user, String password) {
            this.user = user;
            this.password = password;
        }

        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(user, password.toCharArray());
        }

    }
    public static void init(String username, String password) {
        System.setProperty("http.proxySet", "true");
        System.setProperty("java.net.useSystemProxies", "true");
        Log.i("AUTH","Authenticated");
        Authenticator.setDefault(new ProxyAuthenticator(username, password));
    }
    public static void changeTheme(Context context){

        SharedPreferences sharedPreferencesObj = context.getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, context.MODE_PRIVATE);
        final String themeName = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_THEME, context.getString(R.string.app_theme));
        if(themeName.equals(context.getString(R.string.dark_theme))){
            context.setTheme(R.style.DarkTheme);
        }
        else {
            context.setTheme(R.style.AppTheme);
        }
    }


}
