package com.example.pradipkumarv.myproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.List;

/**
 * Created by pradipkumarv on 17-11-2016.
 */

public class SDCustomAdapter extends BaseAdapter{
    ShowDetails showDetails;
    List<DataModel> detailList;


    public SDCustomAdapter(ShowDetails showDetails, List<DataModel> detailList) {
        this.showDetails = showDetails;
        this.detailList = detailList;
    }

    @Override
    public int getCount() {
        return detailList.size();
    }

    @Override
    public Object getItem(int position) {
        return detailList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //LayoutInflater anInflater = showDetails.getLayoutInflater();


        LayoutInflater aninflater = (LayoutInflater) showDetails.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = aninflater.inflate(R.layout.show_det_adapter, parent, false);

        //final ViewGroup myViewGp = (ViewGroup) anInflater.inflate(R.layout.show_det_adapter, null);
        NetworkImageView networkImageView = (NetworkImageView) convertView.findViewById(R.id.iv_newsImage);
        TextView title = (TextView) convertView.findViewById(R.id.title);
        TextView desc = (TextView) convertView.findViewById(R.id.desc);
        TextView pub = (TextView) convertView.findViewById(R.id.pub);

        ImageLoader imageLoader = AppController.getInstance().getImageLoader();
        String imgUrl = detailList.get(position).getImgSrc();
        networkImageView.setImageUrl(imgUrl, imageLoader);

        title.setText(detailList.get(position).getNewsTitle());
        desc.setText(detailList.get(position).getNewsText());
        pub.setText(detailList.get(position).getNewsAuthor());


        return convertView;
    }

}
