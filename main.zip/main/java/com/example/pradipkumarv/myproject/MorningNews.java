package com.example.pradipkumarv.myproject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.pradipkumarv.myproject.config.Config;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MorningNews extends Service {
    public MorningNews() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        //throw new UnsupportedOperationException("Not yet implemented");
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //return super.onStartCommand(intent, flags, startId);

        final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
                if (netInfo == null) {
                    //do nothing
                } else {

                    //---------------------------volley Json object request-------------------------------
                    JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                            Config.NEWS_URL, null,
                            new Response.Listener<JSONObject>() {

                                @Override
                                public void onResponse(JSONObject response) {
                                    Log.d("volleyResponse", response + "");
                                    //Toast.makeText(getContext(), response + "", Toast.LENGTH_LONG).show();
                                    Config.COMPLETE_JSON_OBJ = response;
                                    notifyUser();
                                }
                                private void notifyUser() {

                                    JSONArray posts_Array = new JSONArray();
                                    try {
                                        posts_Array = (JSONArray) Config.COMPLETE_JSON_OBJ.get("posts");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    for (int i = 0; i < 3; i++) {//show 3 notifications
                                        JSONObject single_post = null;
                                        try {
                                            single_post = (JSONObject) posts_Array.get(i);
                                            JSONObject thread_JSon_Obj = (JSONObject) single_post.get("thread");

                                            DataModel dataModel = new DataModel();
                                            dataModel.setImgSrc((String) thread_JSon_Obj.get("main_image"));
                                            dataModel.setNewsTitle((String) thread_JSon_Obj.get("title_full"));
                                            dataModel.setNewsAuthor((String) thread_JSon_Obj.get("site"));
                                            dataModel.setNewsText((String) single_post.get("text"));
                                            dataModel.setNewsUrl((String) single_post.get("url"));
                                            dataModel.setNewsTime((String) thread_JSon_Obj.get("published"));
                                            Intent intent = new Intent(MorningNews.this, com.example.pradipkumarv.myproject.ShowDetails.class);
                                            Gson gson = new Gson();
                                            String data = gson.toJson(dataModel);

                                            Bundle bundle = new Bundle();
                                            bundle.putString("data", data);

                                            PendingIntent pIntent = PendingIntent.getActivity(MorningNews.this, 0, intent, 0);
                                            Notification mNotification = new Notification.Builder(getBaseContext())
                                                    .setContentTitle((String) thread_JSon_Obj.get("title_full"))

                                                    .setSmallIcon(R.drawable.logo)
                                                    .setContentIntent(pIntent)
                                                    //.setSound(soundUri)

                                                    .build();
                                            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                                            notificationManager.notify(i, mNotification);

                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            VolleyLog.d("volleyError", "Error: " + error.getMessage());
                            // hide the progress dialog
                        }
                    });
                    // Adding request to request queue
                    AppController.getInstance().addToRequestQueue(jsonObjReq, Config.TAG_JSON_OBJ);

                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(receiver, filter);

        return START_STICKY;
    }
}
