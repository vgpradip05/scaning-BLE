package com.example.pradipkumarv.myproject;

/**
 * Created by pradipkumarv on 04-11-2016.
 */
public class DataModel {

    String newsTitle, newsAuthor,imgSrc,newsText,newsTime,newsUrl;

    public void setNewsTitle(String newsTitle) {
        this.newsTitle = newsTitle;
    }

    public void setNewsAuthor(String newsAuther) {
        this.newsAuthor = newsAuther;
    }

    public String getNewsTitle() {
        return newsTitle;
    }

    public String getNewsAuthor() {
        return newsAuthor;
    }

    public String getImgSrc() {
        return imgSrc;
    }
    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getNewsText() {
        return newsText;
    }

    public String getNewsTime() {
        return newsTime;
    }

    public void setNewsText(String newsText) {
        this.newsText = newsText;
    }

    public void setNewsTime(String newsTime) {
        this.newsTime = newsTime;
    }

    public String getNewsUrl() {
        return newsUrl;
    }

    public void setNewsUrl(String newsUrl) {
        this.newsUrl = newsUrl;
    }

}






