package com.example.pradipkumarv.myproject;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.pradipkumarv.myproject.config.Config;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class ChangeInLanguage extends AppCompatActivity {

    List<String> langArray;
    private SharedPreferences sharedPreferencesObj;
    ListView langListView;
    ArrayAdapter<String> arrayAdapter;
    String langObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //------------------------------------Check at the start which theme to load------------------------
        Config.changeTheme(ChangeInLanguage.this);
        //--------------------------------------------------------------------------------------------------
        super.onCreate(savedInstanceState);
        sharedPreferencesObj = getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE,MODE_PRIVATE);
        setContentView(R.layout.activity_change_in_langauge);
        langListView = (ListView) findViewById(R.id.langListView);
        langArray = new ArrayList<>();
        langArray.add(getString(R.string.English));
        langArray.add(getString(R.string.Marathi));
        langArray.add(getString(R.string.Gujrati));
        langArray.add(getString(R.string.Hindi));
        langArray.add(getString(R.string.Malayalam));
        langArray.add(getString(R.string.Tamil));
        langArray.add(getString(R.string.Bengali));
        langArray.add(getString(R.string.Punjabi));
        langArray.add(getString(R.string.Urdu));

        arrayAdapter = new ArrayAdapter<>(this, R.layout.layout_arrayadapter, R.id.adapter_text, langArray);

        langListView.setAdapter(arrayAdapter);

        langListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                langObj = langArray.get(position);

                if (langObj.equals(getString(R.string.English))) {
                    setLocale("en");
                } else if (langObj.equals(getString(R.string.Tamil))) {
                    setLocale("ta");
                } else if (langObj.equals(getString(R.string.Gujrati))) {
                    setLocale("gu");
                } else if (langObj.equals(getString(R.string.Bengali))) {
                    setLocale("bn");
                } else if (langObj.equals(getString(R.string.Hindi))) {
                    setLocale("hi");
                } else if (langObj.equals(getString(R.string.Malayalam))) {
                    setLocale("ml");
                } else if (langObj.equals(getString(R.string.Marathi))) {
                    setLocale("mr");
                } else if (langObj.equals(getString(R.string.Urdu))) {
                    setLocale("ur");
                } else if (langObj.equals(getString(R.string.Punjabi))) {
                    setLocale("pa");
                }
            }
        });
    }

    public void setLocale(String lang) {

        //---------------Storing the language in Shared Prefernces-------------

        SharedPreferences.Editor editor = sharedPreferencesObj.edit();
        editor.putString(Config.SHARED_PREF_FILE_OBJ_KEY, lang);
        editor.commit();

        //---------------------------------------------------------------------
        Resources res = ChangeInLanguage.this.getResources();

        //----------------Change locale settings in the app.------------------
        DisplayMetrics dm = res.getDisplayMetrics();
        android.content.res.Configuration conf = res.getConfiguration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            setSystemLocale(conf, new Locale(lang.toLowerCase()));
        }else{
            setSystemLocaleLegacy(conf, new Locale(lang.toLowerCase()));
        }
        res.updateConfiguration(conf, dm);
        //--------------------------------------------------------------------
        //-----------------restarting Application-----------------------------
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);//clears the stack of activities
        finish();
        startActivity(intent);
        //---------------------------------------------------------------------
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }


    @SuppressWarnings("deprecation")
    public Locale getSystemLocaleLegacy(Configuration config){
        return config.locale;
    }

    @TargetApi(Build.VERSION_CODES.N)
    public Locale getSystemLocale(Configuration config){
        return config.getLocales().get(0);
    }

    @SuppressWarnings("deprecation")
    public void setSystemLocaleLegacy(Configuration config, Locale locale){
        config.locale = locale;
    }

    @TargetApi(Build.VERSION_CODES.N)
    public void setSystemLocale(Configuration config, Locale locale){
        config.setLocale(locale);
    }

}
