package com.example.pradipkumarv.myproject.tab.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.baoyz.widget.PullRefreshLayout;
import com.example.pradipkumarv.myproject.AppController;
import com.example.pradipkumarv.myproject.CustomAdapter;
import com.example.pradipkumarv.myproject.DataModel;
import com.example.pradipkumarv.myproject.MainActivity;
import com.example.pradipkumarv.myproject.R;
import com.example.pradipkumarv.myproject.ShowDetails;
import com.example.pradipkumarv.myproject.config.Config;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by pradipkumarv on 28-10-2016.
 */

public class  HeadLines extends Fragment {
    private  ListView listView;
    private  List<DataModel> dataArray;
    DataModel dataModel;
    CustomAdapter customAdapter;
    private final String TAG = "Headlines";
    private SharedPreferences sharedPreferencesObj;
    int itemCount = 0;
    RelativeLayout bLoad;
    static MainActivity mainActivityObj;
    //PullRefreshLayout layout ;


    static String URLforData="https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20thread.country%3AIN%20(site_type%3Anews)";
    // private static ArrayList<Integer> removedItems;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        sharedPreferencesObj = getActivity().getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, getActivity().MODE_PRIVATE);
        final String themeName = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_THEME, "AppTheme");
        // create ContextThemeWrapper from the original Activity Context with the custom theme
        final Context contextThemeWrapper;
        if(themeName.equals("NIGHT")){
            contextThemeWrapper = new ContextThemeWrapper(getActivity(), R.style.DarkTheme);
        }
        else
        {
            contextThemeWrapper = new ContextThemeWrapper(getActivity(), R.style.AppTheme);
        }


        // clone the inflater using the ContextThemeWrapper
        LayoutInflater localInflater = inflater.cloneInContext(contextThemeWrapper);



        final View rootView = localInflater.inflate(R.layout.tab_fragment_1, container, false);
        initVars(rootView);


        URLforData = getArguments().getString("URL");


        sharedPreferencesObj = getActivity().getSharedPreferences(Config.MY_SHARED_PREFERENCE_FILE, getActivity().MODE_PRIVATE);
        final String langData = sharedPreferencesObj.getString(Config.SHARED_PREF_FILE_OBJ_KEY_NEWS_LANG, "english");

        String tempUrl = URLforData;

        URLforData = tempUrl.substring(0,tempUrl.indexOf("(")+1)+langData+tempUrl.substring(tempUrl.indexOf(")"));


        jsonRequest(URLforData);
        bLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                jsonRequest(URLforData);
                mainActivityObj.checkConnectivity();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DataModel tempdataModel ;
                tempdataModel = dataArray.get(position);
                Gson gson = new Gson();
                String data = gson.toJson(tempdataModel);
                String array = gson.toJson(dataArray);
                String pos = gson.toJson(position);
                Bundle bundle = new Bundle();
                bundle.putString("data",data);
                bundle.putString("array",array);
                bundle.putString("pos",pos);

                Intent intent = new Intent(getContext(),ShowDetails.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        return rootView;
    }

    private void jsonRequest(final String URLforData) {
        //-------------------------------Requesting data-------------------------


        final ProgressDialog pDialog = new ProgressDialog(getContext());
        pDialog.setMessage("Loading...");
        pDialog.show();

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                URLforData, null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, URLforData + "");
                        //Toast.makeText(getContext(), response + "", Toast.LENGTH_LONG).show();

                        Config.COMPLETE_JSON_OBJ = response;
                        addData();
                        pDialog.hide();

                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                // hide the progress dialog
                pDialog.hide();
            }
        });

// Adding request to request queue
        AppController.getInstance().addToRequestQueue(jsonObjReq, Config.TAG_JSON_OBJ);
//--------------------------------------------------------------------------


    }

    private void addData() {
        JSONArray posts_Array = new JSONArray();
        try {
            posts_Array = (JSONArray) Config.COMPLETE_JSON_OBJ.get("posts");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        for (itemCount = 0; itemCount < 10; itemCount++) {
            JSONObject single_post = null;
            try {
                single_post = (JSONObject) posts_Array.get(itemCount);
                JSONObject thread_JSon_Obj = (JSONObject) single_post.get("thread");

                dataModel = new DataModel();
                dataModel.setImgSrc((String) thread_JSon_Obj.get("main_image"));
                dataModel.setNewsTitle((String) thread_JSon_Obj.get("title_full"));
                dataModel.setNewsAuthor((String) thread_JSon_Obj.get("site"));
                dataModel.setNewsText((String) single_post.get("text"));
                dataModel.setNewsUrl((String) single_post.get("url"));
                dataModel.setNewsTime((String) thread_JSon_Obj.get("published"));

                dataArray.add(dataModel);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        customAdapter = new CustomAdapter(getActivity(), dataArray);
        listView.setAdapter(customAdapter);
    }




   /* private void newRefresher() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                layout.setRefreshing(false);
            }
        },5000);
    }*/
    private void initVars(View rootView) {
        listView = (ListView) rootView.findViewById(R.id.listView);
        dataArray = new ArrayList<>();
        bLoad = (RelativeLayout) rootView.findViewById(R.id.b_load);
        //layout= (PullRefreshLayout) rootView.findViewById(R.id.swipeRefreshLayout);
    }

   /* @Override
    public void onRefresh() {
        layout.setRefreshing(true);
        newRefresher();
    }*/
    public static HeadLines newInstance(int sectionNumber ,MainActivity mainActivity) {
        HeadLines fragment = new HeadLines();

        switch (sectionNumber){
            case 0 :
                URLforData = "https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20thread.country%3AIN%20(site_type%3Anews)";
                break;
            case 1 :
                URLforData = "https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20thread.country%3AIN%20site_category%3Aentertainment%20(site_type%3Anews)";
                break;
            case 2 :
                URLforData = "https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20thread.country%3AIN%20site_category%3Atech%20(site_type%3Anews)";
                break;
            case 3 :
                URLforData = "https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20thread.country%3AIN%20site_category%3Asports%20(site_type%3Anews)";
                break;
            case 4 :
                URLforData = "https://webhose.io/search?token=5db4bb30-5893-4379-9369-9457e008d4be&format=json&q=language%3A(english)%20site%3Acnn.com%20(site_type%3Anews)";
                break;
        }

        mainActivityObj = mainActivity;
        Bundle args = new Bundle();
        args.putString("URL", URLforData);
        fragment.setArguments(args);
        return fragment;
    }
}