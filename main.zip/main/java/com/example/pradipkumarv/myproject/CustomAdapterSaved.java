package com.example.pradipkumarv.myproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by pradipkumarv on 21-11-2016.
 */
public class CustomAdapterSaved extends BaseAdapter {
    SavedArticle savedArticle;
    List<DataModel> offLineList;

    public CustomAdapterSaved(SavedArticle savedArticle, List<DataModel> offLineList) {
        this.savedArticle = savedArticle;
        this.offLineList = offLineList;
    }

    @Override
    public int getCount() {
        return offLineList.size();
    }

    @Override
    public Object getItem(int position) {
        return offLineList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater anInflater = savedArticle.getLayoutInflater();
        final ViewGroup myViewGp = (ViewGroup) anInflater.inflate(R.layout.saved_custom_layout, null);
        TextView title_news = (TextView) myViewGp.findViewById(R.id.title_news);

        title_news.setText(offLineList.get(position).getNewsTitle());

        return myViewGp;
    }
}
