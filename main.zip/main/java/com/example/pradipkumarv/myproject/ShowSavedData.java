package com.example.pradipkumarv.myproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.pradipkumarv.myproject.config.Config;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class ShowSavedData extends AppCompatActivity {

    DataModel dataModel;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Config.changeTheme(ShowSavedData.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_saved_data);

        Bundle bundle = getIntent().getExtras();

        Type typeOfT = new TypeToken<DataModel>() {
        }.getType();

        String model = bundle.getString("Model");

        position = bundle.getInt("pos");
        Gson gson = new Gson();

        dataModel = gson.fromJson(model, typeOfT);

        ImageView iv = (ImageView) findViewById(R.id.ivImage);
        TextView Title = (TextView) findViewById(R.id.tvTitle);
        TextView Story = (TextView) findViewById(R.id.tvStory);
        TextView Src = (TextView) findViewById(R.id.tvSrc);


        String root = Environment.getExternalStorageDirectory().toString();

        root = root + "/saved_images/" + dataModel.getImgSrc();
        Bitmap bmp = BitmapFactory.decodeFile(root);

        iv.setImageBitmap(bmp);
        Title.setText(dataModel.getNewsTitle());
        Story.setText(dataModel.getNewsText());
        Src.setText(dataModel.getNewsAuthor());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_saved_data, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_delete) {
            Intent intent = new Intent();

            intent.putExtra("pos", position);
            setResult(619, intent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
