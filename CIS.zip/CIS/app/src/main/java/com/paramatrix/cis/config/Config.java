package com.paramatrix.cis.config;

import org.json.JSONArray;

/**
 * Created by pradipkumarv on 27-02-2017.
 */

public class Config {
    static JSONArray ExemptionDetails;
    public static final String DECLARATION_DETAILS = "Declaration Details";
    public static final String SUB_EXEMPTION_LIST = "SubExemptionList";
    public static final String EXEMPTION_NAME = "ExemptionName";
    public static final String EXEMPTION_ID = "ExemptionId";
    public static final String URL_GET_EXEMPTION_DETAILS = "http://10.1.1.207/esp_qa/api/Exemptions/GetExemptionDetails/";
    public static final String URL_SAVE_INVESTMENT_DETAILS = "http://10.1.1.207/esp_qa/api/InvestmentDetails/SaveInvestmentDetails";
    public static final String URL_SEND_FOR_APPROVAL = "http://10.1.1.207/esp_qa/api/InvestmentDetails/UpdateInvestmentStatus";
    public static final String URL_INVESTMENT_STATUS = "http://10.1.1.207/esp_qa/api/InvestmentDetails/GetInvestmentStatus/";
    public static final String ASSESSMENT_YEAR = "AssessmentYear";
    public static final String LIMIT = "Limit";

    public static JSONArray getExemptionDetails() {
        return ExemptionDetails;
    }

    public static void setExemptionDetails(JSONArray exemptionDetails) {
        ExemptionDetails = exemptionDetails;
    }
    public static String REQUIRED = "Required";

    public static final String DECLAREDAMOUNT = "DeclaredAmount";
    public static final String ACTUALAMOUNT = "ActualAmount";
    public static final String RECEIPTNO = "ReceiptNo";
    public static final String DOCUMENTNAME = "DocumentName";
    public static final String DOCUMENTDATE = "DocumentDate";
    public static final String DOCUMENTAMOUNT = "Amount";
    public static final String COMMENT = "Comment";
    public static final String PARENTEXEMPTIONID = "ParentExemptionId";
    public static final String INSTRUCTION = "Instruction";
    public static final String CLEAREDAMOUNT = "ClearedAmount";

    public static final String STATUS = "Status";
    public static final String ASSESSMENTYEARID = "AssessmentYearId";
    public static final String CREATEDBY = "CreatedBy";
    public static final String CREATEDDATE = "CreatedDate";
    public static final String DOCUMENTLIST = "DocumentList";
    public static final String POSITION = "position";
    public static final String TOKEN = "token";
    public static final String EXEMPTIONS = "Exemptions";
    public static final String SCHEDULE = "schedule";
    public static final String EMPLOYEE_NO = "empNo";
    public static final String SUB_EXEMPTION_POSITION = "SubcategoryPosition";

    public static final String NO_INTERNET_CONDITION = "Not connected to Internet";
    public static final String WIFI_ENABLE_CONDITION = "Wifi enabled";
    public static final String MOBILE_DATA_ENABLE_CONDITION = "Mobile data enabled";
    public static final String URL_ASSESSMENT_YEAR = "http://10.1.1.207/esp_qa/api/ESPHome/GetAssessmentYearByUserId/";
    public static final String URL_EMPLOYEE_LIST = "http://10.1.1.207/esp_qa/api/ESPHome/GetRequests/";

}

