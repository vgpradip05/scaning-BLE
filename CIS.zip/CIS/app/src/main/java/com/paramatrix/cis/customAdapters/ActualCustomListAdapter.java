package com.paramatrix.cis.customAdapters;

import android.app.Activity;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by pradipkumarv on 08-02-2017.
 */
public class ActualCustomListAdapter extends BaseAdapter {

    Activity newActivity;
    JSONArray declarationInformationList;
    JSONObject singleException = null;

    public ActualCustomListAdapter(Activity newActivity, JSONArray declarationInformationList) {
        this.newActivity = newActivity;
        this.declarationInformationList = declarationInformationList;
    }

    @Override
    public int getCount() {
        return declarationInformationList.length();
    }

    @Override
    public Object getItem(int position) {
        JSONObject objToRet = null;
        try {

            objToRet = declarationInformationList.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return objToRet;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater anInflater = newActivity.getLayoutInflater();
        View mViewGp = anInflater.inflate(R.layout.layout_exemptions_list, null);

        ImageView icInfo = (ImageView) mViewGp.findViewById(R.id.ic_info);
        TextView tvTotalDeclaredAmount = (TextView) mViewGp.findViewById(R.id.tv_declared_amount);
        try {
            singleException = declarationInformationList.getJSONObject(position);
            JSONArray subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);
            Double totalAmount = 0.0;
            for (int pos = 0; pos < subExemptionList.length(); pos++) {
                if (!subExemptionList.getJSONObject(pos).get(Config.ACTUALAMOUNT).equals(null)) {
                    totalAmount = totalAmount + Double.parseDouble(subExemptionList.getJSONObject(pos).get(Config.ACTUALAMOUNT).toString());
                }
            }
            tvTotalDeclaredAmount.setText(totalAmount.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        icInfo.setVisibility(View.GONE);
        JSONObject subExemption = null;
        try {
            subExemption = declarationInformationList.getJSONObject(position);
            final TextView textView = (TextView) mViewGp.findViewById(R.id.tv_exemption_heading);
            textView.setText(subExemption.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
            if (declarationInformationList.getJSONObject(position).getJSONArray(Config.INSTRUCTION).length() > 0) {
                icInfo.setVisibility(View.VISIBLE);
            }
            icInfo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(newActivity);
                        View viewTitle = newActivity.getLayoutInflater().inflate(R.layout.custom_title, null);
                        TextView tvAlertTitle = (TextView) viewTitle.findViewById(R.id.exemptionSubHeading);
                        tvAlertTitle.setText("Instructions");
                        dialogBuilder.setCustomTitle(viewTitle);
                        dialogBuilder.setPositiveButton("OK", null);
                        String instruction = "\n\n";
                        for (int itemCount = 0; itemCount < declarationInformationList.getJSONObject(position).getJSONArray(Config.INSTRUCTION).length(); itemCount++) {
                            instruction = instruction + "(" + (itemCount + 1) + ") " + declarationInformationList.getJSONObject(position).getJSONArray(Config.INSTRUCTION).get(itemCount) + "\n\n\r";
                        }
                        dialogBuilder.setMessage(instruction);
                        final AlertDialog instructionsDialog = dialogBuilder.create();
                        instructionsDialog.show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return mViewGp;
    }
}
