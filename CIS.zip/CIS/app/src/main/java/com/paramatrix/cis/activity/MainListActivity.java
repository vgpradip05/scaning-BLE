package com.paramatrix.cis.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.paramatrix.cis.ClearanceActivity;
import com.paramatrix.cis.R;
import com.paramatrix.cis.broadcastReceiver.NetworkStateReceiver;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;
import com.paramatrix.cis.customAdapters.CustomListAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pradipkumarv on 08-02-2017.
 */
public class MainListActivity extends AppCompatActivity {
    public static final String POSITION = "position";
    public static final String INVALID_AMOUNT = "Invalid Amount";
    public static final String INVALID_COMMENT = "Invalid Comment";
    public static final String CSP_MODULE_DATA = "CSPModuleData";
    public static final String TOKEN = "token";
    public static final String URL_ASSESSMENT_YEAR = "http://10.1.1.207/esp_qa/api/ESPHome/GetAssessmentYearByUserId/";
    public static NetworkStateReceiver networkStateReceiver = new NetworkStateReceiver();
    ListView lvMainList;
    JSONObject singleSubException, singleException;
    ArrayAdapter arrayAdapter;
    String token;
    CustomListAdapter customListAdapter;
    ProgressDialog pDialog;
    SharedPreferences sharedPreferences;
    private MenuItem mSearchAction;
    private boolean isSearchOpened = false;
    private EditText edtSeach;
    String status;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_list);
        lvMainList = (ListView) findViewById(R.id.lvMainList);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkStateReceiver, filter);
        sharedPreferences = getSharedPreferences(CSP_MODULE_DATA, 0);
        token = sharedPreferences.getString(TOKEN, null);
        status = sharedPreferences.getString("UserStatus", "");
        showInitialAlert();
        //volley requests
        invalidateOptionsMenu();

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);
        pDialog.show();


        selectAssessmentYear();

        //makeJsonRequest(Config.URL_GET_EXEMPTION_DETAILS);
        getSupportActionBar().setTitle(Config.DECLARATION_DETAILS);

       // Button btSendForApproval = (Button) findViewById(R.id.btSendForApproval);
        FloatingActionButton fbtSendForApproval = (FloatingActionButton) findViewById(R.id.fbtSendForApproval);
        if (status.equals("SENDED")) {
            fbtSendForApproval.setVisibility(View.GONE);
        }
        fbtSendForApproval.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(MainListActivity.this,DeclareActualInvestment.class));
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainListActivity.this);
                alertDialogBuilder.setMessage("Are You Sure You want to Send For Approval ? This can't be Undone !");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                sendForApproval();
                            }
                        });

                alertDialogBuilder.setNegativeButton("No", null);
                final AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.show();

            }
        });

        lvMainList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                JSONArray subExemptionList = null;
                try {
                    singleException = Config.getExemptionDetails().getJSONObject(position);
                    subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (subExemptionList.length() == 1) {
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainListActivity.this);
                    LayoutInflater inflater = MainListActivity.this.getLayoutInflater();
                    final View dialogView = inflater.inflate(R.layout.layout_exemption_details, null);
                    final AlertDialog alertDialog = dialogBuilder.create();
                    View titleView = inflater.inflate(R.layout.custom_title, null);
                    TextView tvAlertTitle = (TextView) titleView.findViewById(R.id.exemptionSubHeading);

                    final EditText etAmount = (EditText) dialogView.findViewById(R.id.etAmount);
                    final EditText etComments = (EditText) dialogView.findViewById(R.id.etComments);

                    try {
                        if (!singleException.get("DeclaredAmount").toString().equals("0")) {
                            etAmount.setText(singleException.get("DeclaredAmount").toString());
                        }
                        if (subExemptionList.getJSONObject(0).get("Comment").toString() != "null") {
                            etComments.setText(subExemptionList.getJSONObject(0).get("Comment").toString());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    try {
                        singleSubException = subExemptionList.getJSONObject(0);
                        tvAlertTitle.setText(singleSubException.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Button btOk = (Button) dialogView.findViewById(R.id.btSave);
                    Button btCancel = (Button) dialogView.findViewById(R.id.btCancel);
                    if (status.equals("SENDED")) {
                        etAmount.setEnabled(false);
                        etComments.setEnabled(false);
                        btCancel.setText("Ok");
                        btOk.setVisibility(View.GONE);
                        alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                    }
                    alertDialog.setCustomTitle(titleView);
                    alertDialog.setView(dialogView);

                    alertDialog.show();

                    btOk.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String comments = etComments.getText().toString();
                            int limitAmount = 0;
                            try {
                                String limitValue = singleException.get("Limit").toString().replace("\n", "").replace("\r", "");
                                if (limitValue.equals("null")) {
                                    limitValue = "10000000";
                                }
                                limitAmount = Integer.parseInt(limitValue);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            int amount;
                            if (TextUtils.isEmpty(etAmount.getText().toString())) {
                                etAmount.setError(INVALID_AMOUNT);
                                etAmount.requestFocus();
                                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                            } else if (!isValidComments(comments)) {
                                etComments.setError(INVALID_COMMENT);
                                etComments.requestFocus();
                                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                            } else {
                                amount = (int) Double.parseDouble(etAmount.getText().toString());
                                if (amount > limitAmount || amount < 0) {
                                    etAmount.setError("Value is greater than limit");
                                    etAmount.requestFocus();
                                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                                } else {
                                    try {
                                        sendPostRequest(etAmount.getText().toString(), etComments.getText().toString(), singleException);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    alertDialog.dismiss();
                                }
                            }
                        }
                    });

                    btCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                } else {
                    Bundle dataBundle = new Bundle();
                    dataBundle.putInt(POSITION, position);
                    Intent intent = new Intent(MainListActivity.this, SubListActivity.class);
                    intent.putExtras(dataBundle);
                    startActivity(intent);
                }
            }
        });
    }

    private void showInitialAlert() {
        String msg = getIntent().getStringExtra("MESSAGE");
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        if(msg != null) {
            alertDialogBuilder.setMessage(msg);
            alertDialogBuilder.setPositiveButton("Ok", null);
            final AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }

    private void sendForApproval() {
        String assessmentYearId = sharedPreferences.getString(Config.ASSESSMENTYEARID, null);

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("assessmentYear", assessmentYearId);
            jsonObject.put("status", "SA");
            jsonObject.put("token", token);
            jsonObject.put("empNo", "empty");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_SEND_FOR_APPROVAL, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String stringResponse = response.body().string();
                                Log.i("JSON", stringResponse + "");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("UserStatus", "SENDED");
        editor.commit();


        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Data Send for Approval !");
        alertDialogBuilder.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent intent = getIntent();
                        unregisterReceiver(networkStateReceiver);
                        finish();
                        startActivity(intent);
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();


    }

    private void selectAssessmentYear() {
        final Spinner spAssessYear = (Spinner) findViewById(R.id.spAssessYear);
        final List<String> assessmentYear = new ArrayList<>();
        final JsonArrayRequest jsonObjReq1 = new
                JsonArrayRequest(URL_ASSESSMENT_YEAR + token,
                        new com.android.volley.Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                Log.d("SUCCESS", response.toString());
                                try {
                                    assessmentYear.add(response.getJSONObject(0).get(Config.ASSESSMENT_YEAR).toString());
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString(Config.ASSESSMENTYEARID, response.getJSONObject(0).get(Config.ASSESSMENTYEARID).toString());
                                    editor.commit();

                                    arrayAdapter = new ArrayAdapter(MainListActivity.this, R.layout.support_simple_spinner_dropdown_item, assessmentYear);
                                    spAssessYear.setAdapter(arrayAdapter);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("TAG", "Error: " + error.getMessage());
                    }
                }) {
                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }
                };
        RequestQueue requestQueue = Volley.newRequestQueue(MainListActivity.this);
        requestQueue.add(jsonObjReq1);
        jsonArrayRequest(token);
    }

    private void jsonArrayRequest(final String token) {
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("assesmentYearId", "3");
            jsonObject.put("empNo", "empty");
            jsonObject.put("token", token);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_GET_EXEMPTION_DETAILS, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String stringResponse = response.body().string();
                                Log.i("JSON", stringResponse + "");
                                final JSONArray exemptionDetailsList = new JSONArray(stringResponse);
                                Config.setExemptionDetails(exemptionDetailsList);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //stuff that updates ui
                                        addData(exemptionDetailsList);
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void addData(JSONArray exemptionDetailsList) {
        customListAdapter = new CustomListAdapter(MainListActivity.this, exemptionDetailsList, 1);
        lvMainList.setAdapter(customListAdapter);
        pDialog.hide();

    }

    private void sendPostRequest(String etAmount, String etComments, JSONObject singleException) throws JSONException {

        JSONArray subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);

        JSONObject mSingleSubException = subExemptionList.getJSONObject(0);

        JSONArray jsonArrayExemptions = new JSONArray();
        JSONObject mSingleException = new JSONObject();
        mSingleException.put(Config.EXEMPTION_ID, singleException.get(Config.EXEMPTION_ID));
        mSingleException.put("ParentExemptionId", null);
        mSingleException.put(Config.EXEMPTION_NAME, singleException.get(Config.EXEMPTION_NAME));
        mSingleException.put(Config.LIMIT, singleException.get(Config.LIMIT));
        mSingleException.put("Instruction", new JSONArray());
        mSingleException.put("DeclaredAmount", 0);
        mSingleException.put("ActualAmount", 0);
        mSingleException.put("ClearedAmount", 0);
        mSingleException.put("Comment", null);
        String investmentStatus = sharedPreferences.getString("investmentStatus", "");
        if(investmentStatus.equals("\"N\"")){
            mSingleException.put("Status", "N");
        }else{
            mSingleException.put("Status", "DP");
        }
        mSingleException.put("AssessmentYearId", singleException.get("AssessmentYearId"));
        mSingleException.put("CreatedBy", 1);
        mSingleException.put("CreatedDate", "2017-02-28T00:00:00");
        mSingleException.put("DocumentList", null);
        JSONArray mSubExemptionList = new JSONArray();
        JSONObject subExemptionJsonObj = new JSONObject();
        subExemptionJsonObj.put(Config.EXEMPTION_ID, mSingleSubException.get(Config.EXEMPTION_ID));
        subExemptionJsonObj.put("ParentExemptionId", singleException.get(Config.EXEMPTION_ID));
        subExemptionJsonObj.put(Config.EXEMPTION_NAME, mSingleSubException.get(Config.EXEMPTION_NAME));
        subExemptionJsonObj.put(Config.LIMIT, null);
        subExemptionJsonObj.put("Instruction", null);
        subExemptionJsonObj.put("DeclaredAmount", Double.parseDouble(etAmount));//
        subExemptionJsonObj.put("ActualAmount", 0);
        subExemptionJsonObj.put("ClearedAmount", 0);
        subExemptionJsonObj.put("Comment", etComments);//
        //String investmentStatus1 = sharedPreferences.getString("investmentStatus", "");
        if(investmentStatus.equals("\"N\"")){
            subExemptionJsonObj.put("Status", "N");
        }else{
            subExemptionJsonObj.put("Status", "DP");
        }
        subExemptionJsonObj.put("AssessmentYearId", singleException.get("AssessmentYearId"));
        subExemptionJsonObj.put("CreatedBy", 1);
        subExemptionJsonObj.put("CreatedDate", "2017-02-28T00:00:00");
        subExemptionJsonObj.put("DocumentList", null);
        subExemptionJsonObj.put("SubExemptionList", new JSONArray());
        subExemptionJsonObj.put("$$hashKey", "object:25");
        mSubExemptionList.put(subExemptionJsonObj);
        mSingleException.put("SubExemptionList", mSubExemptionList);

        jsonArrayExemptions.put(mSingleException);


        JSONObject dataToStore = new JSONObject();
        dataToStore.put("Exemptions", jsonArrayExemptions);
        dataToStore.put("token", token);
        dataToStore.put("schedule", "Planned");
        dataToStore.put("empNo", "empty");
        Log.i("dataToStore", dataToStore.toString());
        HTTPClient postReq = new HTTPClient(Config.URL_SAVE_INVESTMENT_DETAILS, dataToStore, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Log.i("RESPONSE", response.body().string());
                            jsonArrayRequest(token);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                thread.start();
            }
        });
    }

    private boolean isValidComments(String comments) {
        boolean toReturn;
        if (comments.length() == 0 || comments.equals("") || comments.equals(null)) {
            toReturn = false;
        } else {
            toReturn = true;
        }
        return toReturn;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        //mSearchAction = menu.findItem(R.id.action_search);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        String role = sharedPreferences.getString("userRole", "");
        MenuItem item = menu.findItem(R.id.clearance);
        if (role.equals("User")) {
            item.setVisible(false);
            //Log.i("I WAS HERE","BRO");
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /*if (id == R.id.action_search) {
            searchFields();
        }*/ if (id == R.id.logout) {


            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("Are You Sure You want to Logout ?");
            alertDialogBuilder.setPositiveButton("yes",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            Intent intent = new Intent(MainListActivity.this, LoginModule.class);
                            finishAffinity();
                            startActivity(intent);
                        }
                    });

            alertDialogBuilder.setNegativeButton("No", null);
            final AlertDialog alertDialog = alertDialogBuilder.create();

            alertDialog.show();


        } else if (id == R.id.clearance) {
            startActivity(new Intent(MainListActivity.this, ClearanceActivity.class));
        }

        return true;
    }

    private void searchFields() {
        ActionBar action = getSupportActionBar(); //get the actionbar

        if (isSearchOpened) { //test if the search is open

            action.setDisplayShowCustomEnabled(false); //disable a custom view inside the actionbar
            action.setDisplayShowTitleEnabled(true); //show the title in the action bar

            //hides the keyboard
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(edtSeach.getWindowToken(), 0);

            //add the search icon in the action bar
            mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_search));

            isSearchOpened = false;
        } else { //open the search entry

            action.setDisplayShowCustomEnabled(true); //enable it to display a
            // custom view in the action bar.
            action.setCustomView(R.layout.search_layout);//add the custom view
            action.setDisplayShowTitleEnabled(false); //hide the title

            edtSeach = (EditText) action.getCustomView().findViewById(R.id.edtSearch); //the text editor

            //edtSeach.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
            //this is a listener to do a search when the user clicks on search button
            edtSeach.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        doSearch(edtSeach.getText().toString());
                        return true;
                    }
                    return false;
                }
            });


            edtSeach.requestFocus();

            //open the keyboard focused in the edtSearch
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(edtSeach, InputMethodManager.SHOW_IMPLICIT);


            //add the close icon
            mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_close));

            isSearchOpened = true;
        }
    }

    private void doSearch(String text) {
        Log.i("Text", text);
    }
}
