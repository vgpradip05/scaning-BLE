package com.paramatrix.cis.activity;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.paramatrix.cis.R;
import com.paramatrix.cis.broadcastReceiver.NetworkStateReceiver;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

/**
 * Created by sruthir on 06-02-2017.
 */

public class LoginModule extends AppCompatActivity {

    public static NetworkStateReceiver networkStateReceiver = new NetworkStateReceiver();
    /**
     * userName & password
     * used to take input for userName and password from user respectively
     */


    EditText userName, password;
    /**
     * login
     * onclick of the button  authentication functionality is been performed
     */


    Button login;
    /**
     * errorText
     * textView used to display error message
     */
    //TextView errorText;
    /**
     * userNameValue & passwordValue
     * variables to store the username and password entered by user
     */
    String userNameValue, passwordValue;
    /**
     * userNameFlag & passwordFlag
     * flags to check userName and password entered by user is valid
     */
    Boolean usernameFlag = false, passwordFlag = false;
    /**
     * JsonArray to store the list of applications for which the user has access
     */
    JSONArray applicationArray;
    /**
     * instance of SharedPreferences to store the values in app storage
     */
    SharedPreferences sharedPreferences;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.login_module);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkStateReceiver, filter);

        /**
         * Loader to block the UI till authentication is performed
         */
        final ProgressDialog pDialog = new ProgressDialog(LoginModule.this);
        pDialog.setMessage("Loading...");


        userName = (EditText) findViewById(R.id.userName);
        password = (EditText) findViewById(R.id.password);
        //errorText = (TextView) findViewById(R.id.errorText);

        login = (Button) findViewById(R.id.login);
        //errorText.setVisibility(View.INVISIBLE);

        /**
         * authentication is performed on click of login
         */

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(userName.getWindowToken(),
                        InputMethodManager.RESULT_UNCHANGED_SHOWN);
                imm.hideSoftInputFromWindow(password.getWindowToken(),
                        InputMethodManager.RESULT_UNCHANGED_SHOWN);

                userNameValue = userName.getText().toString();
                passwordValue = password.getText().toString();
                //errorText.setVisibility(View.INVISIBLE);


                pDialog.show();

                if (userNameValue.isEmpty()) {
                    userName.setError("Required");
                    usernameFlag = false;
                    pDialog.hide();

                } else {
                    usernameFlag = true;
                }
                if (passwordValue.isEmpty()) {
                    password.setError("Required");
                    passwordFlag = false;
                    pDialog.hide();
                } else {
                    passwordFlag = true;
                }
                if (usernameFlag && passwordFlag) {
                    Toast.makeText(LoginModule.this, "Success", Toast.LENGTH_LONG).show();
                    /**
                     * url
                     * used to store authentication Url
                     */
                    String url = "http://10.1.1.207/CSPService_QA/CSPService.svc/authentication/UserLogin";


                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("UserName", userNameValue);
                        jsonObject.put("Password", passwordValue);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        pDialog.hide();
                    }

                    /**
                     * httpClient
                     * used to call Api for authentication
                     * @params: jsonObject consisting of userName and password in key value pairs
                     * @return: http response
                     */
                    HTTPClient httpClient = new HTTPClient(url, jsonObject, new HTTPClient.AsyncResponse() {
                        @Override
                        public void onResponseGot(okhttp3.Response response) {

                            try {

                                System.out.println(response.code());
                                if (response.code() == 200) {


                                    JSONObject token = new JSONObject(response.body().string());
                                    Log.i("MAIN TOKEN ", token.toString());
                                    sharedPreferences = getSharedPreferences("CSPModuleData", 0);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("token", (String) token.get("UserLoginResult"));
                                    editor.commit();

                                    /**
                                     * applicationUrl
                                     * used to store the url to get the application list according to token
                                     */
                                    String applcationUrl = "http://10.1.1.207/CSPService_QA/CSPService.svc/authorization/GetApplicationByToken";
                                    final JSONObject applicationBody = new JSONObject();
                                    applicationBody.put("token", token.get("UserLoginResult"));

                                    System.out.println(sharedPreferences.getString("token", null));

                                    /**
                                     * applicationClient
                                     * used to call api to get the list of application user has access to
                                     * @params: JsonObject consisting of user token in key value pair
                                     * @return: http response
                                     */
                                    HTTPClient applicationClient = new HTTPClient(applcationUrl, applicationBody, new HTTPClient.AsyncResponse() {
                                        @Override
                                        public void onResponseGot(okhttp3.Response response) {
                                            try {
                                                if (response.code() == 200) {


                                                    JSONObject applications = new JSONObject(response.body().string());
                                                    applicationArray = applications.getJSONArray("GetApplicationByTokenResult");
                                                    /**
                                                     * roleUrl
                                                     * used to store the url to get the role by token
                                                     */
                                                    String roleUrl = "http://10.1.1.207/CSPService_QA/CSPService.svc/authorization/GetUserRoleById";

                                                    /**
                                                     * roleClient
                                                     * used to call the api to get the user role
                                                     * @params: JsonObject consisting of user token in key value pair
                                                     * @return: http response
                                                     */
                                                    HTTPClient roleClient = new HTTPClient(roleUrl, applicationBody, new HTTPClient.AsyncResponse() {
                                                        @Override
                                                        public void onResponseGot(okhttp3.Response response) {
                                                            try {


                                                                JSONObject roleObject = new JSONObject(response.body().string());
                                                                System.out.println(roleObject);
                                                                JSONArray role = roleObject.getJSONArray("GetUserRoleByIdResult");
                                                                System.out.println(role.getString(0));
                                                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                                                editor.putString("userRole", role.getString(0));
                                                                editor.commit();
                                                                pDialog.hide();


                                                            } catch (JSONException e) {
                                                                e.printStackTrace();
                                                                pDialog.hide();
                                                            } catch (IOException e) {
                                                                e.printStackTrace();
                                                                pDialog.hide();
                                                            }

                                                            if (applicationArray.length() > 1) {
                                                                Intent intent = new Intent(LoginModule.this, AppSelectionActivity.class);
                                                                startActivity(intent);

                                                            } else {
                                                                try {
                                                                    if (applicationArray.getString(0).equalsIgnoreCase("STS")) {
                                                                        Intent intent = new Intent(LoginModule.this, ESPAtivity.class);
                                                                        startActivity(intent);
                                                                    } else if (applicationArray.getString(0).equalsIgnoreCase("esp")) {
                                                                        //Intent intent = new Intent(LoginModule.this, MainListActivity.class);
                                                                        //startActivity(intent);
                                                                        checkSchedule();
                                                                    }
                                                                } catch (JSONException e) {
                                                                    e.printStackTrace();
                                                                    pDialog.hide();

                                                                }
                                                            }
                                                        }
                                                    });


                                                    System.out.println(applications);
                                                } else {
                                                    //errorText.setVisibility(View.VISIBLE);
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                pDialog.hide();
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                                pDialog.hide();
                                            }
                                        }
                                    });
                                } else {
                                    pDialog.hide();
                                    //errorText.setVisibility(View.VISIBLE);
                                    ScrollView coordinatorLayout = (ScrollView) findViewById(R.id.login_form);
                                    Snackbar snackbar = Snackbar
                                            .make(coordinatorLayout, "InValid Username or Password", Snackbar.LENGTH_LONG);

                                    snackbar.show();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
    }

    private void checkSchedule() {




        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("assesmentYearId", "3");
            jsonObject.put("token", sharedPreferences.getString(Config.TOKEN, ""));
            jsonObject.put("empNo", "empty");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_INVESTMENT_STATUS, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String schedule = response.body().string().trim();
                                Log.i("STATUS", schedule + "");
                                SharedPreferences.Editor editor1 = sharedPreferences.edit();
                                editor1.putString("investmentStatus", schedule);
                                editor1.commit();
                                if (schedule.equals("\"N\"") || schedule.equals("\"DP\"")) {

                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "NOTSENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, MainListActivity.class);
                                    intent.putExtra("MESSAGE", "Welcome to Declaration Page. Please fill details carefully by reading Instructions !");
                                    startActivity(intent);


                                } else if (schedule.equals("\"DR\"")) {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "NOTSENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, MainListActivity.class);
                                    intent.putExtra("MESSAGE", "Your Declaration is Rejected. Please fill valid details only !");
                                    startActivity(intent);


                                } else if (schedule.equals("\"D\"")) {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "SENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, MainListActivity.class);
                                    intent.putExtra("MESSAGE", "Your Declaration Pending for Approval !");
                                    startActivity(intent);


                                } else if (schedule.equals("\"P\"")) {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "NOTSENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, DeclareActualInvestment.class);
                                    intent.putExtra("MESSAGE", "Welcome to Actual Page. Please fill details carefully by reading Instructions !");

                                    startActivity(intent);
                                } else if (schedule.equals("\"R\"")) {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "NOTSENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, DeclareActualInvestment.class);
                                    intent.putExtra("MESSAGE", "Your Actual is Rejected. Please fill valid details only !");
                                    startActivity(intent);


                                } else if (schedule.equals("\"DC\"")) {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "NOTSENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, DeclareActualInvestment.class);
                                    intent.putExtra("MESSAGE", "Your Declaration is Cleared !");
                                    startActivity(intent);


                                } else if (schedule.equals("\"C\"")) {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "CLEARED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, DeclareActualInvestment.class);
                                    intent.putExtra("MESSAGE", "Your Actual Declaration is Cleared !");
                                    startActivity(intent);
                                } else {
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("UserStatus", "SENDED");
                                    editor.commit();
                                    Intent intent = new Intent(LoginModule.this, DeclareActualInvestment.class);
                                    intent.putExtra("MESSAGE", "Actual is pending for Approval !");
                                    startActivity(intent);
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
