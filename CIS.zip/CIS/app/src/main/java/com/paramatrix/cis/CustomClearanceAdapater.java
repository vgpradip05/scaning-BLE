package com.paramatrix.cis;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by pradipkumarv on 14-03-2017.
 */

class CustomClearanceAdapater extends BaseAdapter {
    Activity clearanceActivity;
    JSONArray empDetailsList;

    public CustomClearanceAdapater(Activity clearanceActivity, JSONArray empDetailsList) {
        this.clearanceActivity = clearanceActivity;
        this.empDetailsList = empDetailsList;
    }

    @Override
    public int getCount() {
        return empDetailsList.length();
    }

    @Override
    public Object getItem(int position) {
        JSONObject objToRet = null;
        try {

            objToRet = empDetailsList.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return objToRet;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater anInflater = clearanceActivity.getLayoutInflater();
        View mViewGp = anInflater.inflate(R.layout.clearance_list_item, null);
        JSONObject singleEmployee = null;
        TextView tvEmpId = (TextView) mViewGp.findViewById(R.id.tvEmpId);
        TextView tvEmpName = (TextView) mViewGp.findViewById(R.id.tvEmpName);
        TextView tvStatus = (TextView) mViewGp.findViewById(R.id.tvStatus);
        TextView tvDate = (TextView) mViewGp.findViewById(R.id.tvDate);
        try {
            singleEmployee = empDetailsList.getJSONObject(position);
            tvEmpId.setText(singleEmployee.get("EmployeeNo").toString());
            tvEmpName.setText(singleEmployee.get("EmployeeName").toString());
            if (singleEmployee.get("EmployeeInvestmentStatus").toString().trim().equals("C")) {
                tvStatus.setText("Cleared (Actual)");
            } else if (singleEmployee.get("EmployeeInvestmentStatus").toString().trim().equals("D")) {
                tvStatus.setText("Declared (Planned)");
            } else if (singleEmployee.get("EmployeeInvestmentStatus").toString().trim().equals("A")) {
                tvStatus.setText("Declared (Actual)");
            } else if (singleEmployee.get("EmployeeInvestmentStatus").toString().trim().equals("DC")) {
                tvStatus.setText("Cleared (Planned)");
            }else if (singleEmployee.get("EmployeeInvestmentStatus").toString().trim().equals("R")) {
                tvStatus.setText("Rejected (Actual)");
            }else if (singleEmployee.get("EmployeeInvestmentStatus").toString().trim().equals("DR")) {
                tvStatus.setText("Rejected (Planned)");
            } else {
                tvStatus.setText("Partial Cleared");
            }
            tvDate.setText(singleEmployee.get("RequestDate").toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }


        return mViewGp;
    }
}
