package com.paramatrix.cis.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.paramatrix.cis.R;

/**
 * Created by sruthir on 16-02-2017.
 */

public class ESPAtivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.esp_activity);

        Toolbar toolbar = new Toolbar(this);
        toolbar = (Toolbar) findViewById(R.id.espToolbar);
        toolbar.setTitle("ESP");
        toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_chevron_left_black_24dp));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ESPAtivity.this, LoginModule.class);
                startActivity(intent);
            }
        });


    }
}
