package com.paramatrix.cis.customAdapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by pradipkumarv on 10-02-2017.
 */

public class CustomSubListAdapter extends BaseAdapter {

    Activity newActivity;
    JSONArray list;
    int id;

    public CustomSubListAdapter(Activity newActivity, JSONArray list, int id) {
        this.newActivity = newActivity;
        this.list = list;
        this.id = id;
    }

    @Override
    public int getCount() {
        return list.length();
    }

    @Override
    public Object getItem(int position) {
        JSONObject objToRet = null;
        try {
            objToRet = list.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return objToRet;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater anInflater = newActivity.getLayoutInflater();
        View mViewGp = anInflater.inflate(R.layout.sub_list_item, null);

        TextView tvTotal = (TextView) mViewGp.findViewById(R.id.tvTotal);
        try {
            Double totalAmount = 0.0;
            if (id == 1) {

                totalAmount = Double.parseDouble(list.getJSONObject(position).get("DeclaredAmount").toString());
            } else {
                totalAmount = Double.parseDouble(list.getJSONObject(position).get("ClearedAmount").toString());
            }
            tvTotal.setText(totalAmount.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }


        JSONObject singleSubException;
        try {
            TextView textView = (TextView) mViewGp.findViewById(R.id.exemptionSubHead);
            singleSubException = (JSONObject) list.get(position);
            textView.setText(singleSubException.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return mViewGp;
    }

}

