package com.paramatrix.cis.objectModels;

import java.util.Date;
import java.util.List;

/**
 * Created by pradipkumarv on 27-02-2017.
 */

public class ExemptionsViewModel {
    public long ExemptionId;
    public long ParentExemptionId;
    public String ExemptionName;
    public String Limit ;
    public List<String> Instruction ;

    public int DeclaredAmount ;
    public int ActualAmount ;
    public String Comment ;
    public int Sequence ;
    public String Status ;
    public long AssessmentYearId ;
    public long CreatedBy ;
    public Date CreatedDate ;
    public List<ExemptionsViewModel> SubExemptionList;


    public String getExemptionName() {
        return ExemptionName;
    }

    public void setExemptionName(String exemptionName) {
        ExemptionName = exemptionName;
    }

    public long getExemptionId() {
        return ExemptionId;
    }

    public void setExemptionId(long exemptionId) {
        ExemptionId = exemptionId;
    }

    public String getComment() {
        return Comment;
    }

    public void setComment(String comment) {
        Comment = comment;
    }

    public int getDeclaredAmount() {
        return DeclaredAmount;
    }

    public void setDeclaredAmount(int declaredAmount) {
        DeclaredAmount = declaredAmount;
    }
}
