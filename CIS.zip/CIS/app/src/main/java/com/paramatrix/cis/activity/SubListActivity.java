package com.paramatrix.cis.activity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;
import com.paramatrix.cis.customAdapters.CustomSubListAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class SubListActivity extends AppCompatActivity {
    JSONArray subExemptionList;
    String token;
    JSONObject singleException;
    ListView lvSubList;
    CustomSubListAdapter customListAdapter;
    int position;
    SharedPreferences sharedPreferences;
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Bundle dataBundle = getIntent().getExtras();

        sharedPreferences = getSharedPreferences(MainListActivity.CSP_MODULE_DATA, 0);
        token = sharedPreferences.getString(MainListActivity.TOKEN, null);


        position = dataBundle.getInt(MainListActivity.POSITION);
        try {
            singleException = Config.getExemptionDetails().getJSONObject(position);
            subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        customListAdapter = new CustomSubListAdapter(SubListActivity.this, subExemptionList, 2);


        lvSubList = (ListView) findViewById(R.id.lvSubList);

        lvSubList.setAdapter(customListAdapter);

        lvSubList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(SubListActivity.this);
                LayoutInflater inflater = SubListActivity.this.getLayoutInflater();

                final View dialogView = inflater.inflate(R.layout.layout_exemption_details, null);
                View titleView = inflater.inflate(R.layout.custom_title, null);
                final AlertDialog alertDialog = dialogBuilder.create();
                TextView tvAlertTitle = (TextView) titleView.findViewById(R.id.exemptionSubHeading);
                JSONObject singleSubException = null;


                final EditText etAmount = (EditText) dialogView.findViewById(R.id.etAmount);
                final EditText etComments = (EditText) dialogView.findViewById(R.id.etComments);
                try {
                    singleSubException = subExemptionList.getJSONObject(position);
                    if (!singleSubException.get("DeclaredAmount").toString().equals("0.0")) {
                        etAmount.setText(singleSubException.get("DeclaredAmount").toString());
                    }
                    if (singleSubException.get("Comment").toString() != "null") {
                        etComments.setText(singleSubException.get("Comment").toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                try {

                    singleSubException = subExemptionList.getJSONObject(position);
                    tvAlertTitle.setText(singleSubException.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String status = sharedPreferences.getString("UserStatus", "");
                Button btOk = (Button) dialogView.findViewById(R.id.btSave);
                Button btCancel = (Button) dialogView.findViewById(R.id.btCancel);
                if (status.equals("SENDED")) {
                    etAmount.setEnabled(false);
                    etComments.setEnabled(false);
                    btCancel.setText("Ok");
                    btOk.setVisibility(View.GONE);
                    alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                }
                alertDialog.setCustomTitle(titleView);
                alertDialog.setView(dialogView);



                alertDialog.show();


                btOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                       /* int limitAmount = 0;
                        try {
                            limitAmount = (int) singleException.get("Limit");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }*/

                        String comments = etComments.getText().toString();
                        int amount;

                        if (TextUtils.isEmpty(etAmount.getText().toString())) {
                            etAmount.setError(MainListActivity.INVALID_AMOUNT);
                            etAmount.requestFocus();
                            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                        } else if (!isValidComments(comments)) {
                            etComments.setError(MainListActivity.INVALID_COMMENT);
                            etComments.requestFocus();
                            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                        }/*else if ( amount > limitAmount ) {
                            etComments.setError("Value is greater than limit");
                        }*/ else {
                            amount = (int) Double.parseDouble(etAmount.getText().toString());
                            if (amount < 0) {
                                etAmount.setError("Value is greater than limit");
                                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                            } else {
                                try {
                                    sendPostRequest(etAmount.getText().toString(), etComments.getText().toString(), singleException, position);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                alertDialog.dismiss();
                            }
                        }

                    }
                });


                btCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }
        });
    }

    private boolean isValidComments(String comments) {
        boolean toReturn;
        if (comments.length() == 0 || comments.equals("")) {
            toReturn = false;
        } else {
            toReturn = true;
        }
        return toReturn;
    }

    private void sendPostRequest(String etAmount, String etComments, JSONObject singleException, int position) throws JSONException {

        JSONArray subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);

        JSONObject mSingleSubException = subExemptionList.getJSONObject(position);

        JSONArray jsonArrayExemptions = new JSONArray();
        JSONObject mSingleException = new JSONObject();
        mSingleException.put(Config.EXEMPTION_ID, singleException.get(Config.EXEMPTION_ID));
        mSingleException.put("ParentExemptionId", null);
        mSingleException.put(Config.EXEMPTION_NAME, singleException.get(Config.EXEMPTION_NAME));
        mSingleException.put(Config.LIMIT, singleException.get(Config.LIMIT));
        mSingleException.put("Instruction", new JSONArray());
        mSingleException.put("DeclaredAmount", 0);
        mSingleException.put("ActualAmount", 0);
        mSingleException.put("ClearedAmount", 0);
        mSingleException.put("Comment", null);
        mSingleException.put("Status", "DP");
        mSingleException.put("AssessmentYearId", singleException.get("AssessmentYearId"));
        mSingleException.put("CreatedBy", 1);
        mSingleException.put("CreatedDate", "2017-02-28T00:00:00");
        mSingleException.put("DocumentList", null);
        JSONArray mSubExemptionList = new JSONArray();
        JSONObject subExemptionJsonObj = new JSONObject();
        subExemptionJsonObj.put(Config.EXEMPTION_ID, mSingleSubException.get(Config.EXEMPTION_ID));
        subExemptionJsonObj.put("ParentExemptionId", singleException.get(Config.EXEMPTION_ID));
        subExemptionJsonObj.put(Config.EXEMPTION_NAME, mSingleSubException.get(Config.EXEMPTION_NAME));
        subExemptionJsonObj.put(Config.LIMIT, null);
        subExemptionJsonObj.put("Instruction", null);
        subExemptionJsonObj.put("DeclaredAmount", Double.parseDouble(etAmount));//
        subExemptionJsonObj.put("ActualAmount", 0);
        subExemptionJsonObj.put("ClearedAmount", 0);
        subExemptionJsonObj.put("Comment", etComments);//
        subExemptionJsonObj.put("Status", "DP");
        subExemptionJsonObj.put("AssessmentYearId", singleException.get("AssessmentYearId"));
        subExemptionJsonObj.put("CreatedBy", 1);
        subExemptionJsonObj.put("CreatedDate", "2017-02-28T00:00:00");
        subExemptionJsonObj.put("DocumentList", null);
        subExemptionJsonObj.put("SubExemptionList", new JSONArray());
        subExemptionJsonObj.put("$$hashKey", "object:25");
        mSubExemptionList.put(subExemptionJsonObj);
        mSingleException.put("SubExemptionList", mSubExemptionList);

        jsonArrayExemptions.put(mSingleException);

        JSONObject dataToStore = new JSONObject();
        dataToStore.put("Exemptions", jsonArrayExemptions);
        dataToStore.put("token", token);
        dataToStore.put("schedule", "Planned");
        dataToStore.put("empNo", "empty");
        Log.i("dataToStore", dataToStore.toString());
        HTTPClient postReq = new HTTPClient(Config.URL_SAVE_INVESTMENT_DETAILS, dataToStore, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Log.i("RESPONSE", response.body().string());
                            jsonArrayRequest(token);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                thread.start();
            }
        });
    }

    private void jsonArrayRequest(final String token) {
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("assesmentYearId", "3");
            jsonObject.put("empNo", "empty");
            jsonObject.put("token", token);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_GET_EXEMPTION_DETAILS, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String stringResponse = response.body().string();
                                Log.i("JSON", stringResponse + "");
                                final JSONArray exemptionDetailsList = new JSONArray(stringResponse);
                                Config.setExemptionDetails(exemptionDetailsList);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            try {
                                subExemptionList = (JSONArray) Config.getExemptionDetails().getJSONObject(position).get(Config.SUB_EXEMPTION_LIST);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //stuff that updates ui
                                    addData(subExemptionList);
                                }
                            });
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void addData(JSONArray subExemptionList) {
        CustomSubListAdapter customListAdapter = new CustomSubListAdapter(SubListActivity.this, subExemptionList, 1);
        //lvSubList.setAdapter(customListAdapter);
        customListAdapter.notifyDataSetChanged();
        lvSubList.setAdapter(customListAdapter);
    }
}
