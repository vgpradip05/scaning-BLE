package com.paramatrix.cis.customAdapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by pradipkumarv on 08-02-2017.
 */
public class CustomListAdapter extends BaseAdapter {
    Activity newActivity;
    JSONArray list;
    JSONObject singleException = null;
    int id;

    public CustomListAdapter(Activity newActivity, JSONArray list, int id) {
        this.newActivity = newActivity;
        this.list = list;
        this.id = id;
    }

    @Override
    public int getCount() {
        return list.length();
    }

    @Override
    public Object getItem(int position) {
        //createIndexTable(list);
        JSONObject objToRet = null;
        try {
            objToRet = list.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return objToRet;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater anInflater = newActivity.getLayoutInflater();
        View mViewGp = anInflater.inflate(R.layout.main_list_item, null);
        try {
            singleException = list.getJSONObject(position);
            TextView exemptionHead = (TextView) mViewGp.findViewById(R.id.exemptionHead);
            exemptionHead.setText(singleException.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
            TextView tvTotal = (TextView) mViewGp.findViewById(R.id.tvTotal);

            JSONArray subExemptionList = (JSONArray) singleException.get("SubExemptionList");
            Double totalAmount = 0.0;
            for (int pos = 0; pos < subExemptionList.length(); pos++) {
                if (id == 1) {
                    totalAmount = totalAmount + Double.parseDouble(subExemptionList.getJSONObject(pos).get("DeclaredAmount").toString());
                } else {
                    totalAmount = totalAmount + Double.parseDouble(subExemptionList.getJSONObject(pos).get("ClearedAmount").toString());
                }
            }

            tvTotal.setText(totalAmount.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ImageButton ibInfo = (ImageButton) mViewGp.findViewById(R.id.ibInfo);
        ibInfo.setVisibility(View.GONE);
        try {
            if (list.getJSONObject(position).getJSONArray("Instruction").length() > 0) {
                ibInfo.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ibInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(newActivity);
                alertDialogBuilder.setPositiveButton("Ok", null);
                View viewTitle = newActivity.getLayoutInflater().inflate(R.layout.custom_title, null);
                TextView tvAlertTitle = (TextView) viewTitle.findViewById(R.id.exemptionSubHeading);
                tvAlertTitle.setText("Instructions");
                alertDialogBuilder.setCustomTitle(viewTitle);
                try {
                    JSONArray insrtuctionList;
                    insrtuctionList = (JSONArray) list.getJSONObject(position).get("Instruction");
                    String instruction = "\n\n";
                    for (int pos = 0; pos < insrtuctionList.length(); pos++) {
                        instruction = instruction + "(" + (pos + 1) + ") " + insrtuctionList.get(pos) + "\n\n\r";
                    }
                    alertDialogBuilder.setMessage(instruction);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });
        return mViewGp;
    }
}