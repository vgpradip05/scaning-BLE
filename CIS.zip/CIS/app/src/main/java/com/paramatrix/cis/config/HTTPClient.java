package com.paramatrix.cis.config;

import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by sruthir on 15-02-2017.
 */

/**
 * class used to call api using OkHttp3
 */

public class HTTPClient {
    private String url;
    private JSONObject jsonObject;
    private Response response;
    private AsyncResponse asyncResponse;
    MediaType type=MediaType.parse("application/json; charset=utf-8");

    /**
     * interface used to sent the httpResponse
     * @return: http response
     */

    public interface AsyncResponse{
        void onResponseGot(Response response);
    }

    /**
     * constructor of {@link HTTPClient}
     * @param url to store the url that is to be called
     * @param jsonObject to store the parameters that is to be attached to the body of the http request
     * @param asyncResponse instance of the interface
     */

    public HTTPClient(String url, JSONObject jsonObject, AsyncResponse asyncResponse){
        this.url=url;
        this.jsonObject=jsonObject;
        this.asyncResponse=asyncResponse;
        executeRequest();


    }

    /**
     * function to call the execute of {@link OkHttpRequest}
     */
    public void executeRequest(){

        new OkHttpRequest().execute();
    }

    /**
     * class extending {@link AsyncTask} to crate other thread for api call
     * @return: http response in onPostExecute
     */
    private class  OkHttpRequest extends AsyncTask<Void,Void,Response>{


        @Override
        protected Response doInBackground(Void... voids) {

            OkHttpClient client=new OkHttpClient();
            RequestBody body=RequestBody.create(type,jsonObject.toString());
            Request request=new Request.Builder().url(url).post(body).build();
            try {
                response=client.newCall(request).execute();

            } catch (IOException e) {
                e.printStackTrace();
            }

            return response;
        }

        @Override
        protected void onPostExecute(Response response) {
            super.onPostExecute(response);
            asyncResponse.onResponseGot(response);
        }
    }
}
