package com.paramatrix.cis.activity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.paramatrix.cis.ClearanceActivity;
import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;
import com.paramatrix.cis.customAdapters.ProofDocumentListAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by pradipkumarv on 21-03-2017.
 */

public class ClearanceDetails extends AppCompatActivity{

        public static final String CSP_MODULE_DATA = "CSPModuleData";
        ProofDocumentListAdapter proofDocumentListAdapter;
        String token;
        JSONObject singleException = null;
        ProgressDialog uploadDialog;
        private int position;
        private ImageView ivAddProofDocumentDetails;
        private EditText edtDocumentDate;
        private int day, month, year;
        private Button btnCancel;
        private ListView lstvDocumentDetails;
        private JSONArray jsonArray;
        private JSONObject proofDocumentDetailsObject;
        private int subCategoryPosition;
        private JSONArray proofDocumentDetailsArray = new JSONArray();
        String empNo;
        String status;
        private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {

            // when dialog box is closed, below method will be called.
            public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                DatePicker date_picker = null;
                date_picker = (DatePicker) view.findViewById(view.getId());
                year = selectedYear;
                month = selectedMonth;
                day = selectedDay;

                // set selected date into Text View
                edtDocumentDate.setText(new StringBuilder().append(month + 1).append("/").append(day)
                        .append("/").append(year).append(" "));

                //set selected date into Date Picker
                date_picker.init(year, month, day, null);
            }

        };

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_investment_details);
            SharedPreferences sharedPreferences = getSharedPreferences(CSP_MODULE_DATA, 0);
            token = sharedPreferences.getString(Config.TOKEN, null);
            TextView tvExemptionSubheading = (TextView) findViewById(R.id.tv_exemption_subheading);
            TextView tvDeclredAmount = (TextView) findViewById(R.id.tv_amount_declared);
            final EditText edtActualAmount = (EditText) findViewById(R.id.edt_actual_amount);
            final EditText edtComment = (EditText) findViewById(R.id.edt_investment_comment);
            final EditText etCleared = (EditText) findViewById(R.id.et_cleared_amount);
            ivAddProofDocumentDetails = (ImageView) findViewById(R.id.iv_add_proof);
            this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            status = sharedPreferences.getString("UserStatus", "");
            Button btnCancelInvestmentDeclaration = (Button) findViewById(R.id.btn_cancel_investment_declaration);
            Button btnSaveInvestmenrDetails = (Button) findViewById(R.id.btn_add_doc_details);
            //if (status.equals("SENDED")) {
                edtActualAmount.setEnabled(false);
                edtComment.setEnabled(false);
                ivAddProofDocumentDetails.setVisibility(View.GONE);
                etCleared.setVisibility(View.VISIBLE);
                //btnCancelInvestmentDeclaration.setVisibility(View.GONE);
                //btnSaveInvestmenrDetails.setVisibility(View.GONE);
                //this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
           // }
            empNo = getIntent().getExtras().getString("EMPNO");
            uploadDialog = new ProgressDialog(this);
            uploadDialog.setMessage("Uploading data....");
            uploadDialog.setCancelable(false);
            Bundle dataBundle = getIntent().getExtras();

            position = dataBundle.getInt(Config.POSITION);
            subCategoryPosition = dataBundle.getInt(Config.SUB_EXEMPTION_POSITION);

            JSONArray subExemptionList = null;
            try {
                lstvDocumentDetails = (ListView) findViewById(R.id.lstv_document_details);
                singleException = Config.getExemptionDetails().getJSONObject(position);
                subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);
                if (subExemptionList.getJSONObject(subCategoryPosition).getJSONArray(Config.DOCUMENTLIST).length() != 0) {
                    proofDocumentDetailsArray = (JSONArray) subExemptionList.getJSONObject(subCategoryPosition).get(Config.DOCUMENTLIST);
                    proofDocumentListAdapter = new ProofDocumentListAdapter(ClearanceDetails.this, proofDocumentDetailsArray);
                    lstvDocumentDetails.setAdapter(proofDocumentListAdapter);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                jsonArray = (JSONArray) Config.getExemptionDetails().getJSONObject(position).get(Config.SUB_EXEMPTION_LIST);
                tvExemptionSubheading.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
                tvDeclredAmount.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.DECLAREDAMOUNT).toString().replace("\n", "").replace("\r", ""));
                if (!subExemptionList.getJSONObject(subCategoryPosition).get(Config.COMMENT).equals(null)) {
                    edtComment.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.COMMENT).toString().replace("\n", "").replace("\r", ""));
                }
                if (!subExemptionList.getJSONObject(subCategoryPosition).get(Config.ACTUALAMOUNT).toString().equals("0") && !subExemptionList.getJSONObject(subCategoryPosition).get(Config.ACTUALAMOUNT).equals(null)) {
                    edtActualAmount.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.ACTUALAMOUNT).toString().replace("\n", "").replace("\r", ""));
                }
                if (!subExemptionList.getJSONObject(subCategoryPosition).get(Config.CLEAREDAMOUNT).toString().equals("0") && !subExemptionList.getJSONObject(subCategoryPosition).get(Config.ACTUALAMOUNT).equals(null)) {
                    etCleared.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.CLEAREDAMOUNT).toString().replace("\n", "").replace("\r", ""));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            lstvDocumentDetails.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                    ClearanceDetails.this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ClearanceDetails.this);
                    LayoutInflater inflater = ClearanceDetails.this.getLayoutInflater();
                    View alertDialogView = inflater.inflate(R.layout.layout_actual_exemption_details, null);
                    dialogBuilder.setView(alertDialogView);
                    dialogBuilder.setCancelable(false);
                    TextView tvExemptionSubheading = (TextView) alertDialogView.findViewById(R.id.tv_exemption_subheading);
                    try {
                        tvExemptionSubheading.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    final AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();
                    final EditText edtDocumentNumber = (EditText) alertDialogView.findViewById(R.id.edt_proof_document_number);
                    final EditText edtDocumentName = (EditText) alertDialogView.findViewById(R.id.edt_proof_document_name);
                    final EditText edtDocumentAmount = (EditText) alertDialogView.findViewById(R.id.edt_proof_document_amount);
                    edtDocumentDate = (EditText) alertDialogView.findViewById(R.id.edt_proof_document_date);

                    Button btnAddDocDetails = (Button) alertDialogView.findViewById(R.id.btn_add_doc_details);
                    btnCancel = (Button) alertDialogView.findViewById(R.id.btn_cancel);
                    //if (status.equals("SENDED")) {
                        edtDocumentNumber.setEnabled(false);
                        edtDocumentName.setEnabled(false);
                        edtDocumentAmount.setEnabled(false);
                        edtDocumentDate.setEnabled(false);
                        btnAddDocDetails.setVisibility(View.GONE);
                        btnCancel.setText("Ok");
                        alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                   // }

                    try {
                        edtDocumentNumber.setText(proofDocumentDetailsArray.getJSONObject(i).get(Config.RECEIPTNO).toString());
                        edtDocumentName.setText(proofDocumentDetailsArray.getJSONObject(i).get(Config.DOCUMENTNAME).toString());
                        String documentDate = proofDocumentDetailsArray.getJSONObject(i).get(Config.DOCUMENTDATE).toString();
                        documentDate = documentDate.substring(0, documentDate.indexOf("T"));
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
                        Date testDate = null;
                        try {
                            testDate = sdf.parse(documentDate);
                        } catch(Exception ex){
                            ex.printStackTrace();
                        }
                        SimpleDateFormat formatter = new SimpleDateFormat("mm/dd/yyyy");
                        documentDate = formatter.format(testDate);
                        edtDocumentDate.setText(documentDate.trim());
                        edtDocumentAmount.setText(proofDocumentDetailsArray.getJSONObject(i).get(Config.DOCUMENTAMOUNT).toString());

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    edtDocumentDate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            onCreateDialog(999);
                        }
                    });

                    btnAddDocDetails.setText("Update");
                    btnAddDocDetails.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (TextUtils.isEmpty(edtDocumentNumber.getText().toString().trim())) {
                                edtDocumentNumber.setError(Config.REQUIRED);
                                edtDocumentNumber.requestFocus();
                                getKeyboard();
                                return;
                            } else if (TextUtils.isEmpty(edtDocumentName.getText().toString().trim())) {
                                edtDocumentName.setError(Config.REQUIRED);
                                edtDocumentName.requestFocus();
                                getKeyboard();
                                return;
                            } else if (TextUtils.isEmpty(edtDocumentDate.getText().toString().trim())) {
                                edtDocumentDate.setError(Config.REQUIRED);
                                edtDocumentDate.requestFocus();
                                getKeyboard();
                                return;
                            } else if (TextUtils.isEmpty(edtDocumentAmount.getText().toString().trim())) {
                                edtDocumentAmount.setError(Config.REQUIRED);
                                edtDocumentAmount.requestFocus();
                                getKeyboard();
                                return;
                            } else {
                                proofDocumentDetailsObject = new JSONObject();
                                try {
                                    proofDocumentDetailsObject.put(Config.RECEIPTNO, edtDocumentNumber.getText().toString().trim());
                                    proofDocumentDetailsObject.put(Config.DOCUMENTNAME, edtDocumentName.getText().toString().trim());
                                    proofDocumentDetailsObject.put(Config.DOCUMENTDATE, edtDocumentDate.getText().toString().trim());
                                    proofDocumentDetailsObject.put(Config.DOCUMENTAMOUNT, edtDocumentAmount.getText().toString().trim());
                                    proofDocumentDetailsArray.put(i, proofDocumentDetailsObject);
                                    proofDocumentListAdapter.notifyDataSetChanged();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                alertDialog.dismiss();
                            }
                        }
                    });

                    btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                }
            });
            btnSaveInvestmenrDetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (TextUtils.isEmpty(etCleared.getText().toString().trim())) {
                        etCleared.setError(Config.REQUIRED);
                        etCleared.requestFocus();
                        getKeyboard();
                        return;
                    }  else {
                        try {
                            sendPostRequest(etCleared.getText().toString(), singleException, subCategoryPosition);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

            btnCancelInvestmentDeclaration.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });

            ivAddProofDocumentDetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ClearanceDetails.this);
                    LayoutInflater inflater = ClearanceDetails.this.getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.layout_actual_exemption_details, null);
                    dialogBuilder.setView(dialogView);
                    dialogBuilder.setCancelable(false);

                    TextView tvExemptionSubheading = (TextView) dialogView.findViewById(R.id.tv_exemption_subheading);
                    try {
                        tvExemptionSubheading.setText(jsonArray.getJSONObject(subCategoryPosition).get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    final EditText edtDocumentNumber = (EditText) dialogView.findViewById(R.id.edt_proof_document_number);
                    final EditText edtDocumentName = (EditText) dialogView.findViewById(R.id.edt_proof_document_name);
                    final EditText edtDocumentAmount = (EditText) dialogView.findViewById(R.id.edt_proof_document_amount);
                    edtDocumentDate = (EditText) dialogView.findViewById(R.id.edt_proof_document_date);


                    final AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();
                    edtDocumentDate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            onCreateDialog(999);
                        }
                    });
                    Button btnAddDocDetails = (Button) dialogView.findViewById(R.id.btn_add_doc_details);
                    btnAddDocDetails.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (TextUtils.isEmpty(edtDocumentNumber.getText().toString().trim())) {
                                edtDocumentNumber.setError(Config.REQUIRED);
                                edtDocumentNumber.requestFocus();
                                getKeyboard();
                                return;
                            } else if (TextUtils.isEmpty(edtDocumentName.getText().toString().trim())) {
                                edtDocumentName.setError(Config.REQUIRED);
                                edtDocumentName.requestFocus();
                                getKeyboard();
                                return;
                            } else if (TextUtils.isEmpty(edtDocumentDate.getText().toString().trim())) {
                                edtDocumentDate.setError(Config.REQUIRED);
                                edtDocumentDate.requestFocus();
                                getKeyboard();
                                return;
                            } else if (TextUtils.isEmpty(edtDocumentAmount.getText().toString().trim())) {
                                edtDocumentAmount.setError(Config.REQUIRED);
                                edtDocumentAmount.requestFocus();
                                getKeyboard();
                                return;
                            } else {
                                try {
                                    proofDocumentDetailsObject = new JSONObject();
                                    proofDocumentDetailsObject.put(Config.RECEIPTNO, edtDocumentNumber.getText().toString().trim());
                                    proofDocumentDetailsObject.put(Config.DOCUMENTNAME, edtDocumentName.getText().toString().trim());
                                    proofDocumentDetailsObject.put(Config.DOCUMENTDATE, edtDocumentDate.getText().toString().trim());
                                    proofDocumentDetailsObject.put(Config.DOCUMENTAMOUNT, edtDocumentAmount.getText().toString().trim());

                                    proofDocumentDetailsArray.put(proofDocumentDetailsObject);

                                    proofDocumentListAdapter = new ProofDocumentListAdapter(ClearanceDetails.this, proofDocumentDetailsArray);
                                    lstvDocumentDetails.setAdapter(proofDocumentListAdapter);
                                    alertDialog.dismiss();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });

                    btnCancel = (Button) dialogView.findViewById(R.id.btn_cancel);

                    btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });

                }
            });

        }

        @Override
        protected Dialog onCreateDialog(int id) {

            switch (id) {
                case 999:
                    // set date picker as current date
                    Calendar calendar = Calendar.getInstance();
                    year = calendar.get(Calendar.YEAR);
                    month = calendar.get(Calendar.MONTH);
                    day = calendar.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog dialog =
                            new DatePickerDialog(this, datePickerListener, year, month, day);
                    dialog.show();
            }
            return null;
        }

        private void sendPostRequest(String etCleared, JSONObject singleException, int subExemptionPosition) throws JSONException {
            uploadDialog.show();
            JSONArray subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);
            JSONObject mSingleSubException = subExemptionList.getJSONObject(subExemptionPosition);

            JSONArray jsonArrayExemptions = new JSONArray();
            JSONObject mSingleException = new JSONObject();
            mSingleException.put(Config.EXEMPTION_ID, singleException.get(Config.EXEMPTION_ID));
            mSingleException.put(Config.PARENTEXEMPTIONID, null);
            mSingleException.put(Config.EXEMPTION_NAME, singleException.get(Config.EXEMPTION_NAME));
            mSingleException.put(Config.LIMIT, singleException.get(Config.LIMIT));
            mSingleException.put(Config.INSTRUCTION, new JSONArray());
            mSingleException.put(Config.DECLAREDAMOUNT, 0);
            mSingleException.put(Config.ACTUALAMOUNT, 0);
            mSingleException.put(Config.CLEAREDAMOUNT, 0);
            mSingleException.put(Config.COMMENT, null);
            SharedPreferences sharedPreferences = getSharedPreferences(CSP_MODULE_DATA, 0);
            String investmentStatus = sharedPreferences.getString("investmentStatus", "");
            if(investmentStatus.equals("\"DC\"")){
                mSingleException.put("Status", "DC");
            } else {
                mSingleException.put("Status", "P");
            }
            mSingleException.put(Config.ASSESSMENTYEARID, singleException.get(Config.ASSESSMENTYEARID));
            mSingleException.put(Config.CREATEDBY, 1);
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.US);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            mSingleException.put(Config.CREATEDDATE, dateFormat.format(new Date()) + "T" + timeFormat.format(new Date()));
            mSingleException.put(Config.DOCUMENTLIST, null);
            JSONArray mSubExemptionList = new JSONArray();
            JSONObject subExemptionJsonObj = new JSONObject();
            subExemptionJsonObj.put(Config.EXEMPTION_ID, mSingleSubException.get(Config.EXEMPTION_ID));
            subExemptionJsonObj.put(Config.PARENTEXEMPTIONID, singleException.get(Config.EXEMPTION_ID));
            subExemptionJsonObj.put(Config.EXEMPTION_NAME, mSingleSubException.get(Config.EXEMPTION_NAME));
            subExemptionJsonObj.put(Config.LIMIT, null);
            subExemptionJsonObj.put(Config.INSTRUCTION, null);
            subExemptionJsonObj.put(Config.DECLAREDAMOUNT, mSingleSubException.get(Config.DECLAREDAMOUNT));//
            subExemptionJsonObj.put(Config.ACTUALAMOUNT, 0);
            subExemptionJsonObj.put(Config.CLEAREDAMOUNT,Float.parseFloat(etCleared));
            subExemptionJsonObj.put(Config.COMMENT, "");//
            if(investmentStatus.equals("\"DC\"")){
                subExemptionJsonObj.put("Status", "DC");
            }else{
                subExemptionJsonObj.put("Status", "P");
            }
            subExemptionJsonObj.put(Config.ASSESSMENTYEARID, singleException.get(Config.ASSESSMENTYEARID));
            subExemptionJsonObj.put(Config.CREATEDBY, 1);
            subExemptionJsonObj.put(Config.CREATEDDATE, dateFormat.format(new Date()) + "T" + timeFormat.format(new Date()));
            subExemptionJsonObj.put(Config.DOCUMENTLIST, proofDocumentDetailsArray);
            subExemptionJsonObj.put(Config.SUB_EXEMPTION_LIST, new JSONArray());
            subExemptionJsonObj.put("$$hashKey", "object:25");
            mSubExemptionList.put(subExemptionJsonObj);
            mSingleException.put(Config.SUB_EXEMPTION_LIST, mSubExemptionList);

            jsonArrayExemptions.put(mSingleException);

            JSONObject dataToStore = new JSONObject();
            dataToStore.put(Config.EXEMPTIONS, jsonArrayExemptions);
            dataToStore.put(Config.TOKEN, token);
            dataToStore.put(Config.SCHEDULE, "Planned");
            dataToStore.put(Config.EMPLOYEE_NO, empNo);

            HTTPClient postReq = new HTTPClient(Config.URL_SAVE_INVESTMENT_DETAILS, dataToStore, new HTTPClient.AsyncResponse() {
                @Override
                public void onResponseGot(final okhttp3.Response response) {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Log.i("RESPONSE", response.body().string());
                            /*AlertDialog.Builder successDialogBuilder = new AlertDialog.Builder(InvestmentDetailsActivity.this);
                            successDialogBuilder.setTitle("Success");
                            successDialogBuilder.setMessage("Investment Information Saved Successfully");
                            successDialogBuilder.setPositiveButton("OK",null);
                            AlertDialog alertDialog = successDialogBuilder.create();
                            alertDialog.show();*/
                                uploadDialog.dismiss();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //stuff that updates ui
                                        AlertDialog.Builder successDialogBuilder = new AlertDialog.Builder(ClearanceDetails.this);
                                        successDialogBuilder.setTitle("Success");
                                        successDialogBuilder.setMessage("Cleared amount saved successfully");
                                        successDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                startActivity(new Intent(ClearanceDetails.this, ClearanceActivity.class));
                                                finish();
                                            }
                                        });
                                        AlertDialog alertDialog = successDialogBuilder.create();
                                        alertDialog.show();
                                    }
                                });
                            } catch (IOException e) {
                                e.printStackTrace();
                                uploadDialog.dismiss();
                            }
                        }
                    });
                    thread.start();
                }
            });
        }
        private void getKeyboard() {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }


