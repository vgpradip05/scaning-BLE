package com.paramatrix.cis.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.paramatrix.cis.ClearanceActivity;
import com.paramatrix.cis.R;
import com.paramatrix.cis.broadcastReceiver.NetworkStateReceiver;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;
import com.paramatrix.cis.customAdapters.ActualCustomListAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DeclareActualInvestment extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    JSONArray exemptionDetailsList = null;
    SharedPreferences sharedPreferences;
    private MenuItem mSearchAction;
    private boolean isSearchOpened = false;
    private EditText edtSeach;
    private ListView lstvExemptionsList;
    ArrayAdapter arrayAdapter;
    String loginToken;
    ProgressDialog loaderDialog;
    //Button btn_send_for_approval ;
    FloatingActionButton fbtSendForApproval;
    public static NetworkStateReceiver networkStateReceiver= new NetworkStateReceiver();
    String status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_declare_actual_investment);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkStateReceiver, filter);

        invalidateOptionsMenu();

        loaderDialog=new ProgressDialog(this);
        loaderDialog.setMessage("Loading....");
        loaderDialog.setCancelable(false);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Actual Investment Declaration");

        sharedPreferences = getSharedPreferences("CSPModuleData", 0);
        loginToken = sharedPreferences.getString(Config.TOKEN, null);
        selectAssessmentYear();
        status = sharedPreferences.getString("UserStatus", "");

        fbtSendForApproval =(FloatingActionButton)findViewById(R.id.fbtSendForApproval);
        if (status.equals("SENDED")|| status.equals("CLEARED")) {
            fbtSendForApproval.setVisibility(View.GONE);
        }
        fbtSendForApproval.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DeclareActualInvestment.this);
                alertDialogBuilder.setMessage("Are You Sure You want to Send For Approval ? This can't be Undone !");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                sendForApproval();
                            }
                        });

                alertDialogBuilder.setNegativeButton("No", null);
                final AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.show();
            }
        });

        lstvExemptionsList = (ListView) findViewById(R.id.lstv_exemption_list);

        lstvExemptionsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                JSONObject exemptionSubListObject;
                JSONArray subExemptionList = null;
                try {
                    exemptionSubListObject = Config.getExemptionDetails().getJSONObject(position);
                    subExemptionList = (JSONArray) exemptionSubListObject.get(Config.SUB_EXEMPTION_LIST);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (subExemptionList.length() == 1) {
                    Bundle dataBundle = new Bundle();
                    dataBundle.putInt(Config.POSITION, position);
                    dataBundle.putInt(Config.SUB_EXEMPTION_POSITION, 0);
                    Intent intent = new Intent(DeclareActualInvestment.this, InvestmentDetailsActivity.class);
                    intent.putExtras(dataBundle);
                    startActivity(intent);
                } else {
                    Context context = null;
                    Bundle dataBundle = new Bundle();
                    dataBundle.putInt(Config.POSITION, position);
                    Intent intent = new Intent(DeclareActualInvestment.this, SubCategoryActivity.class);
                    intent.putExtras(dataBundle);
                    intent.getComponent().getClassName();
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        String role = sharedPreferences.getString("userRole","");
        MenuItem item = menu.findItem(R.id.clearance);
        if(role.equals("User")) {
            item.setVisible(false);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        //mSearchAction = menu.findItem(R.id.action_search);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        /*if (id == R.id.action_search) {
            handleMenuSearch();
        }*/
        if (id == R.id.logout) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("Are You Sure You want to Logout ?");
            alertDialogBuilder.setPositiveButton("yes",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            Intent intent = new Intent(DeclareActualInvestment.this, LoginModule.class);
                            finishAffinity();
                            startActivity(intent);
                        }
                    });

            alertDialogBuilder.setNegativeButton("No", null);
            final AlertDialog alertDialog = alertDialogBuilder.create();

            alertDialog.show();
        }
        if(id == R.id.clearance){
            startActivity(new Intent(DeclareActualInvestment.this, ClearanceActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

    protected void handleMenuSearch() {
        ActionBar action = getSupportActionBar(); //get the actionbar

        if (isSearchOpened) { //test if the search is open

            action.setDisplayShowCustomEnabled(false); //disable a custom view inside the actionbar
            action.setDisplayShowTitleEnabled(true); //show the title in the action bar

            //hides the keyboard
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(edtSeach.getWindowToken(), 0);

            //add the search icon in the action bar
            mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_search));

            isSearchOpened = false;
        } else { //open the search entry

            action.setDisplayShowCustomEnabled(true); //enable it to display a
            // custom view in the action bar.
            action.setCustomView(R.layout.layout_search);//add the custom view
            action.setDisplayShowTitleEnabled(false); //hide the title

            edtSeach = (EditText) action.getCustomView().findViewById(R.id.edtSearch); //the text editor

            //this is a listener to do a search when the user clicks on search button
            edtSeach.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        doSearch(edtSeach.getText().toString().trim());
                        return true;
                    }
                    return false;
                }
            });


            edtSeach.requestFocus();

            //open the keyboard focused in the edtSearch
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(edtSeach, InputMethodManager.SHOW_IMPLICIT);


            //add the close icon
            mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_close));

            isSearchOpened = true;
        }
    }

    private void doSearch(String searchQuery) {
        Toast.makeText(DeclareActualInvestment.this, searchQuery, Toast.LENGTH_SHORT).show();
    }

    private void makeJsonRequest() {
        loaderDialog.show();
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("assesmentYearId", 3);
            jsonObject.put(Config.EMPLOYEE_NO, "empty");
            jsonObject.put(Config.TOKEN, sharedPreferences.getString(Config.TOKEN, null));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_GET_EXEMPTION_DETAILS, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {

                        @Override
                        public void run() {
                            try {
                                //Your code goes here
                                String stringResponse = response.body().string();
                                //Log.i("JSONSTRING", stringResponse + "");
                                exemptionDetailsList = new JSONArray(stringResponse);
                                Config.setExemptionDetails(exemptionDetailsList);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //stuff that updates ui
                                        addData(exemptionDetailsList);
                                        loaderDialog.dismiss();
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                                loaderDialog.dismiss();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                    loaderDialog.dismiss();
                }
            }
        });
    }

    private void addData(JSONArray exemptionDetailsList) {
        ActualCustomListAdapter customListAdapter = new ActualCustomListAdapter(DeclareActualInvestment.this, exemptionDetailsList);
        lstvExemptionsList.setAdapter(customListAdapter);

    }
    private void showInitialAlert() {
        String msg = getIntent().getStringExtra("MESSAGE");
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        if(msg != null) {
            alertDialogBuilder.setMessage(msg);
            alertDialogBuilder.setPositiveButton("Ok", null);
            final AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }

    }
    private void sendForApproval() {
        String assessmentYearId = sharedPreferences.getString(Config.ASSESSMENTYEARID, null);
        String status = "SA";
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("assessmentYear", assessmentYearId);
            jsonObject.put("status", status);
            jsonObject.put("token", sharedPreferences.getString(Config.TOKEN,""));
            jsonObject.put("empNo", "empty");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_SEND_FOR_APPROVAL, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String stringResponse = response.body().string();
                                Log.i("JSON", stringResponse + "");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("UserStatus", "SENDED");
        editor.commit();
        unregisterReceiver(networkStateReceiver);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Data Send for Approval !");
        alertDialogBuilder.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent intent = getIntent();
                        finish();
                        startActivity(intent);
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();


    }

    private void selectAssessmentYear() {
        loaderDialog.show();
        final Spinner spnrAssessmentYear = (Spinner) findViewById(R.id.spnr_assessment_year);
        final List<String> assessmentYear = new ArrayList<>();
        final JsonArrayRequest jsonObjReq1 = new
                JsonArrayRequest(Config.URL_ASSESSMENT_YEAR + loginToken,
                        new com.android.volley.Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                Log.d("SUCCESS", response.toString());
                                try {
                                    assessmentYear.add(response.getJSONObject(0).get(Config.ASSESSMENT_YEAR).toString());
                                    arrayAdapter = new ArrayAdapter(DeclareActualInvestment.this, R.layout.support_simple_spinner_dropdown_item, assessmentYear);
                                    spnrAssessmentYear.setAdapter(arrayAdapter);
                                    loaderDialog.dismiss();
                                    showInitialAlert();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    loaderDialog.dismiss();
                                }
                            }
                        }, new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loaderDialog.dismiss();
                        AlertDialog.Builder successDialogBuilder = new AlertDialog.Builder(DeclareActualInvestment.this);
                        successDialogBuilder.setTitle("Error");
                        successDialogBuilder.setMessage("Server Error");
                        successDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finishAffinity();
                                loaderDialog.dismiss();
                            }
                        });
                        AlertDialog alertDialog = successDialogBuilder.create();
                        alertDialog.show();
                    }
                }) {
                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }
                };
        RequestQueue requestQueue = Volley.newRequestQueue(DeclareActualInvestment.this);
        requestQueue.add(jsonObjReq1);
        makeJsonRequest();
    }
}
