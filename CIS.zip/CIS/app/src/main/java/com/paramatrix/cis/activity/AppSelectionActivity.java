package com.paramatrix.cis.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.paramatrix.cis.R;


/**
 * Created by sruthir on 08-02-2017.
 */

public class AppSelectionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_selection);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("AppSelectionActivity");
        toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_chevron_left_black_24dp));
        Button sts = (Button) findViewById(R.id.sts);
        Button esp = (Button) findViewById(R.id.esp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(AppSelectionActivity.this, LoginModule.class);
                startActivity(intent);
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences("CSPModuleData", 0);
        String token = sharedPreferences.getString("token", null);
        String role = sharedPreferences.getString("userRole", null);
        System.out.println(token);
        System.out.println(role);

        sts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AppSelectionActivity.this, "STS", Toast.LENGTH_LONG).show();
            }
        });
        esp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AppSelectionActivity.this, "ESP", Toast.LENGTH_LONG).show();
                startActivity(new Intent(AppSelectionActivity.this, MainListActivity.class));
            }
        });
    }


}
