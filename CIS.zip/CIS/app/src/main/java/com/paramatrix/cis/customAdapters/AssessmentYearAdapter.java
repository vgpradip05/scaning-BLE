package com.paramatrix.cis.customAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.paramatrix.cis.R;

import java.util.List;

/**
 * Created by lalitj on 04-02-2017.
 */
public class AssessmentYearAdapter extends BaseAdapter {
    Context context;
    List<String> yearList;
    LayoutInflater inflater;

    public AssessmentYearAdapter(Context applicationContext, List<String> AssessmentYearList) {
        this.context = applicationContext;
        this.yearList = AssessmentYearList;
        inflater = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return yearList.size();
    }

    @Override
    public Object getItem(int position) {
        return yearList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.assessment_year_spinner_layout, null);
        TextView itemName = (TextView) convertView.findViewById(R.id.tv_spinner_item);
        itemName.setText(yearList.get(position));
        return convertView;
    }

}
