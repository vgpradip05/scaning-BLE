package com.paramatrix.cis.broadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.paramatrix.cis.activity.AlertDialogActivity;
import com.paramatrix.cis.config.Config;

public class NetworkStateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context context, final Intent intent) {
        String status = NetworkUtil.getConnectivityStatusString(context);
        if(status.equals(Config.NO_INTERNET_CONDITION)){
            Intent i = new Intent(context, AlertDialogActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
               /* STSConfig.showErrorMessage((Activity) context,STSConfig.NO_INTERNET_CONNECTION_FOUND,STSConfig.CLOSE_APPLICATION);*/
        }
    }
}
