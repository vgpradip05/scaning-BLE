package com.paramatrix.cis;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import com.paramatrix.cis.activity.ClearanceListActivity;
import com.paramatrix.cis.activity.MainListActivity;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ClearanceActivity extends AppCompatActivity {
    Spinner spAssessmentYear, spStatus;
    ListView lvEmpList;
    SharedPreferences sharedPreferences;
    List<String> lAssessmentYear, lStatus;
    String AssessmentYearId;
    CustomClearanceAdapater customClearanceAdapater;
    JSONArray empDetailsList;
    ArrayAdapter arrayAdapterStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_clearance_main);
        sharedPreferences = getSharedPreferences(MainListActivity.CSP_MODULE_DATA, 0);

        AssessmentYearId = sharedPreferences.getString(Config.ASSESSMENTYEARID, null);
        getSupportActionBar().setTitle("Clearance");
        lAssessmentYear = new ArrayList<>();
        lStatus = new ArrayList<>();
        lAssessmentYear.add("2017-18");
        lStatus.add("Pending");
        lStatus.add("All");
        lStatus.add("Accepted");
        lStatus.add("Rejected");
        spAssessmentYear = (Spinner) findViewById(R.id.spnr_assessment_year);
        spStatus = (Spinner) findViewById(R.id.spnr_status);
        lvEmpList = (ListView) findViewById(R.id.lstv_employee_list);
        //makeEmployeeListRequest(AssessmentYearId);


        ArrayAdapter arrayAdapterAssYear = new ArrayAdapter(ClearanceActivity.this, R.layout.support_simple_spinner_dropdown_item, lAssessmentYear);
        spAssessmentYear.setAdapter(arrayAdapterAssYear);

        arrayAdapterStatus = new ArrayAdapter(ClearanceActivity.this, R.layout.support_simple_spinner_dropdown_item, lStatus);
        spStatus.setAdapter(arrayAdapterStatus);
        spStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                makeEmployeeListRequest(AssessmentYearId, lStatus.get(position));

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        lvEmpList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                try {
                    bundle.putString("EMPNO", empDetailsList.getJSONObject(position).get("EmployeeNo").toString());
                    bundle.putString("STATUS", empDetailsList.getJSONObject(position).get("EmployeeInvestmentStatus").toString().trim());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Intent intent = new Intent(ClearanceActivity.this, ClearanceListActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }


    private void makeEmployeeListRequest(String assessmentYearId, final String status) {
        JSONObject dataToSend = new JSONObject();
        try {
            dataToSend.put("assessmentYear", assessmentYearId);
            dataToSend.put("status", status);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        HTTPClient applicationClient = new HTTPClient(Config.URL_EMPLOYEE_LIST, dataToSend, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(okhttp3.Response response) {
                try {
                    String stringResponse = response.body().string();
                    Log.i("JSON", stringResponse + "");
                    if(stringResponse.equals("\"Requests not found\"")){
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ClearanceActivity.this);

                            alertDialogBuilder.setMessage("No Employee With Status :"+status);
                            alertDialogBuilder.setPositiveButton("Ok", null);
                            final AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();
                            arrayAdapterStatus.notifyDataSetChanged();
                            empDetailsList = new JSONArray();
                            customClearanceAdapater = new CustomClearanceAdapater(ClearanceActivity.this, empDetailsList);
                            lvEmpList.setAdapter(customClearanceAdapater);
                    }
                    empDetailsList = new JSONArray(stringResponse);
                    customClearanceAdapater = new CustomClearanceAdapater(ClearanceActivity.this, empDetailsList);
                    lvEmpList.setAdapter(customClearanceAdapater);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
