package com.paramatrix.cis.customAdapters;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.paramatrix.cis.R;
import com.paramatrix.cis.activity.DeclareActualInvestment;
import com.paramatrix.cis.activity.LoginModule;
import com.paramatrix.cis.config.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.paramatrix.cis.R.string.status;

/**
 * Created by lalitj on 06-02-2017.
 */
public class ProofDocumentListAdapter extends BaseAdapter {
    Activity parentActivity;
    JSONArray proofDocumentDetailsArray = new JSONArray();

    public ProofDocumentListAdapter(Activity activityContext, JSONArray proofDocumentDetailsArray) {
        this.parentActivity = activityContext;
        this.proofDocumentDetailsArray = proofDocumentDetailsArray;
    }

    @Override
    public int getCount() {
        return proofDocumentDetailsArray.length();
    }

    @Override
    public Object getItem(int i) {
        JSONObject proofDocumentJsonObject = null;
        try {
            proofDocumentJsonObject = proofDocumentDetailsArray.getJSONObject(i);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return proofDocumentJsonObject;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        LayoutInflater anInflater = parentActivity.getLayoutInflater();
        View mViewGp = anInflater.inflate(R.layout.layout_subheading_item, null);
        /*JSONArray documentListItemArray = new JSONArray();
        documentListItemArray = proofDocumentList.get(i);*/
        TextView tvDocumentName = (TextView) mViewGp.findViewById(R.id.tv_exemption_subheading);
        TextView tvDocumentAmount = (TextView) mViewGp.findViewById(R.id.tv_declared_amount);

        try {
            String documentName = proofDocumentDetailsArray.getJSONObject(i).get(Config.DOCUMENTNAME).toString();
            String amount = proofDocumentDetailsArray.getJSONObject(i).get(Config.DOCUMENTAMOUNT).toString();
            tvDocumentName.setText(documentName);
            tvDocumentAmount.setText(amount);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ImageButton ibDeleteProofDetails = (ImageButton) mViewGp.findViewById(R.id.ib_delete_proof);
        SharedPreferences sharedPreferences = parentActivity.getSharedPreferences("CSPModuleData", 0);
        String status = sharedPreferences.getString("UserStatus","");
        if (status.equals("SENDED")) {
            ibDeleteProofDetails.setVisibility(View.GONE);
        }
        ibDeleteProofDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int id = 0;
                try {
                    id = Integer.parseInt(proofDocumentDetailsArray.getJSONObject(i).get("DocumentId").toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(parentActivity);
                alertDialogBuilder.setMessage("Are you sure you want to Delete this document ?");
                final int finalId = id;
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                deleteDocumentDetails(finalId);
                                proofDocumentDetailsArray.remove(i);
                                ProofDocumentListAdapter.this.notifyDataSetChanged();
                            }
                        });

                alertDialogBuilder.setNegativeButton("No", null);
                final AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });
        return mViewGp;
    }

    private void deleteDocumentDetails(int documentId) {
        try {
            Toast.makeText(parentActivity, proofDocumentDetailsArray.getJSONObject(documentId).get("DocumentId").toString(), Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        final JsonArrayRequest jsonObjReq1 = new
                JsonArrayRequest("http://10.1.1.207/esp_qa/api/Exemptions/Delete/" + documentId,
                        new com.android.volley.Response.Listener<JSONArray>() {

                            @Override
                            public void onResponse(JSONArray response) {
                                Log.d("SUCCESSTAG", response.toString());

                               /* try {

                                    Log.d("JsonArray", response.toString());
                                    for (int i = 0; i < response.length(); i++) {
                                        JSONObject jresponse = response.getJSONObject(i);
                                        Log.i("USERDATA", "" + response.getJSONObject(i));
                                        String nickname = jresponse.getString("AssessmentYear");
                                        Log.d("AssessmentYear", nickname);
                                        Log.i("ASSESS ID", jresponse.getString("AssessmentYearId"));
                                        Config.assessmentYearList.add(jresponse.getString("AssessmentYear"));
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }*/
                                //pDialog.dismiss();
                            }
                        }, new com.android.volley.Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("ERRORTAG", "Error: " + error.getMessage());
                        //pDialog.dismiss();
                    }
                }) {

                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }

                };
        RequestQueue requestQueue = Volley.newRequestQueue(parentActivity);
        requestQueue.add(jsonObjReq1);
    }
}
