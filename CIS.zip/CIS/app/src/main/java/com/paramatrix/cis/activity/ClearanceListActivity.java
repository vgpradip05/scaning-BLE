package com.paramatrix.cis.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.paramatrix.cis.R;
import com.paramatrix.cis.broadcastReceiver.NetworkStateReceiver;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.config.HTTPClient;
import com.paramatrix.cis.customAdapters.CustomListAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pradipkumarv on 16-03-2017.
 */

public class ClearanceListActivity extends AppCompatActivity {
    public static final String POSITION = "position";
    public static final String INVALID_AMOUNT = "Invalid Amount";
    public static final String CSP_MODULE_DATA = "CSPModuleData";
    public static final String TOKEN = "token";
    public static final String URL_ASSESSMENT_YEAR = "http://10.1.1.207/esp_qa/api/ESPHome/GetAssessmentYearByUserId/";
    public static NetworkStateReceiver networkStateReceiver = new NetworkStateReceiver();
    public static String empNo;
    ListView lvMainList;
    JSONObject singleSubException, singleException;
    ArrayAdapter arrayAdapter;
    String token;
    CustomListAdapter customListAdapter;
    ProgressDialog pDialog;
    SharedPreferences sharedPreferences;
    private MenuItem mSearchAction;
    private boolean isSearchOpened = false;
    private EditText edtSeach;
    String status;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clearance_list);
        lvMainList = (ListView) findViewById(R.id.lvMainList);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkStateReceiver, filter);
        sharedPreferences = getSharedPreferences(CSP_MODULE_DATA, 0);
        token = sharedPreferences.getString(TOKEN, null);
        //volley requests

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);
        pDialog.show();
        empNo = getIntent().getExtras().getString("EMPNO");
        status = getIntent().getExtras().getString("STATUS");

        TextView tvEmpId = (TextView) findViewById(R.id.tvEmpId);
        tvEmpId.setText(empNo);
        selectAssessmentYear();

        //makeJsonRequest(Config.URL_GET_EXEMPTION_DETAILS);
        getSupportActionBar().setTitle("Clearance Details");

        Button btAccept = (Button) findViewById(R.id.btAccept);
        Button btReject = (Button) findViewById(R.id.btReject);
        Button btCancel = (Button) findViewById(R.id.btCancel);
        if(status.equals("DC")||status.equals("C")){
            btAccept.setVisibility(View.GONE);
            btReject.setVisibility(View.GONE);
            btCancel.setVisibility(View.GONE);
        }
        if(status.equals("DR")||status.equals("R")){
            btReject.setVisibility(View.GONE);
        }
        btAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(ClearanceListActivity.this,DeclareActualInvestment.class));
                //finish();
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ClearanceListActivity.this);
                alertDialogBuilder.setMessage("Are You Sure You want to Accept ? This can be Undone !");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                makeClearanceCall(status,"ACCEPT");
                            }
                        });

                alertDialogBuilder.setNegativeButton("No", null);
                final AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.show();

            }
        });
        btReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //finish();

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ClearanceListActivity.this);
                alertDialogBuilder.setMessage("Are You Sure You want to Accept ? This can be Undone !");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                makeClearanceCall(status,"REJECT");
                            }
                        });

                alertDialogBuilder.setNegativeButton("No", null);
                final AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.show();
            }
        });
        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        lvMainList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                JSONArray subExemptionList = null;
                try {
                    singleException = Config.getExemptionDetails().getJSONObject(position);
                    subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (subExemptionList.length() == 1) {
                  /*  AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ClearanceListActivity.this);
                    LayoutInflater inflater = ClearanceListActivity.this.getLayoutInflater();
                    final View dialogView = inflater.inflate(R.layout.clearance_details_list_item, null);
                    View titleView = inflater.inflate(R.layout.custom_title, null);
                    TextView tvAlertTitle = (TextView) titleView.findViewById(R.id.exemptionSubHeading);

                    final TextView tvDeclaredAmount = (TextView) dialogView.findViewById(R.id.tvDeclaredAmount);
                    final TextView tvActualAmount = (TextView) dialogView.findViewById(R.id.tvActualAmount);
                    final EditText etClearedAmount = (EditText) dialogView.findViewById(R.id.etClearedAmount);
                    try {
                        tvDeclaredAmount.setText(singleException.get("DeclaredAmount").toString());
                        tvActualAmount.setText(singleException.get("ActualAmount").toString());
                        if (!singleException.get("ClearedAmount").toString().equals("0") || !singleException.get("ClearedAmount").toString().equals("0")) {
                            etClearedAmount.setText(singleException.get("ClearedAmount").toString());
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    try {
                        singleSubException = subExemptionList.getJSONObject(0);
                        tvAlertTitle.setText(singleSubException.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Button btOk = (Button) dialogView.findViewById(R.id.btSave);
                    Button btCancel = (Button) dialogView.findViewById(R.id.btCancel);
                    LinearLayout llClearedLayout = (LinearLayout) dialogView.findViewById(R.id.llClearedLayout);
                    if(status.equals("D")||status.equals("DC")){
                        btOk.setVisibility(View.GONE);
                        llClearedLayout.setVisibility(View.GONE);
                        btCancel.setText("Ok");
                    }else if(status.equals("C")){
                        etClearedAmount.setEnabled(false);
                        btOk.setVisibility(View.GONE);
                        btCancel.setText("Ok");
                    }


                    dialogBuilder.setCustomTitle(titleView);
                    dialogBuilder.setView(dialogView);
                    final AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();

                    btOk.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            //String comments = etComments.getText().toString();
                            int limitAmount = 0;
                            try {
                                String limitValue = singleException.get("Limit").toString().replace("\n", "").replace("\r", "");
                                if (limitValue.equals("null")) {
                                    limitValue = "10000000";
                                }
                                limitAmount = Integer.parseInt(limitValue);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            int amount;
                            if (TextUtils.isEmpty(etClearedAmount.getText().toString())) {
                                etClearedAmount.setError(INVALID_AMOUNT);
                                etClearedAmount.requestFocus();
                                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                            } else {
                                amount = (int) Double.parseDouble(etClearedAmount.getText().toString());
                                if (amount > limitAmount || amount < 0) {
                                    etClearedAmount.setError("Value is greater than limit");
                                    etClearedAmount.requestFocus();
                                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                                } else {
                                    try {
                                        sendPostRequest(etClearedAmount.getText().toString(), "Cleared", singleException);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    alertDialog.dismiss();
                                }
                            }
                        }
                    });

                    btCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });*/
                    Bundle dataBundle = new Bundle();
                    dataBundle.putInt(Config.POSITION, position);
                    dataBundle.putInt(Config.SUB_EXEMPTION_POSITION, 0);
                    dataBundle.putString("EMPNO",empNo);
                    Intent intent = new Intent(ClearanceListActivity.this, ClearanceDetails.class);
                    intent.putExtras(dataBundle);
                    startActivity(intent);
                } else {
                    Bundle dataBundle = new Bundle();
                    dataBundle.putInt(POSITION, position);
                    dataBundle.putString("STATUS", status);
                    dataBundle.putString("EMPNO",empNo);
                    Intent intent = new Intent(ClearanceListActivity.this, ClearanceSubListActivity.class);
                    intent.putExtras(dataBundle);
                    startActivity(intent);
                }
            }
        });
    }

    private void makeClearanceCall(String statusForApprove, String btIdentity) {
            String assessmentYearId = sharedPreferences.getString(Config.ASSESSMENTYEARID, null);
            //String status = "SA";
            String statusToChange = "";
            if(btIdentity.equals("ACCEPT")){
                if(statusForApprove.equals("PC")||statusForApprove.equals("A")){
                    statusToChange = "A";
                }
                else if(statusForApprove.equals("D")){
                    statusToChange = "DA";
                }
            }
            else{
                if(statusForApprove.equals("PC")||statusForApprove.equals("A")){
                    statusToChange = "R";
                }
                else if(statusForApprove.equals("D")){
                    statusToChange = "DR";
                }
            }
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("assessmentYear", assessmentYearId);
                jsonObject.put("status", statusToChange);
                jsonObject.put("token", token);
                jsonObject.put("empNo", empNo);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            HTTPClient applicationClient = new HTTPClient(Config.URL_SEND_FOR_APPROVAL, jsonObject, new HTTPClient.AsyncResponse() {
                @Override
                public void onResponseGot(final okhttp3.Response response) {
                    try {
                        Thread thread = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    String stringResponse = response.body().string();
                                    Log.i("JSON", stringResponse + "");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        thread.start();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("Data Send for Approval !");
            alertDialogBuilder.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }
                    });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();



    }

    private void selectAssessmentYear() {
        final Spinner spAssessYear = (Spinner) findViewById(R.id.spAssessYear);
        final List<String> assessmentYear = new ArrayList<>();
        final JsonArrayRequest jsonObjReq1 = new
                JsonArrayRequest(URL_ASSESSMENT_YEAR + token,
                        new com.android.volley.Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                Log.d("SUCCESS", response.toString());
                                try {
                                    assessmentYear.add(response.getJSONObject(0).get(Config.ASSESSMENT_YEAR).toString());
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString(Config.ASSESSMENTYEARID, response.getJSONObject(0).get(Config.ASSESSMENTYEARID).toString());
                                    editor.commit();
                                    arrayAdapter = new ArrayAdapter(ClearanceListActivity.this, R.layout.support_simple_spinner_dropdown_item, assessmentYear);
                                    spAssessYear.setAdapter(arrayAdapter);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("TAG", "Error: " + error.getMessage());
                    }
                }) {
                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }
                };
        RequestQueue requestQueue = Volley.newRequestQueue(ClearanceListActivity.this);
        requestQueue.add(jsonObjReq1);
        jsonArrayRequest(token);
    }

    private void jsonArrayRequest(final String token) {
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("assesmentYearId", "3");
            jsonObject.put("empNo", empNo);
            jsonObject.put("token", token);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HTTPClient applicationClient = new HTTPClient(Config.URL_GET_EXEMPTION_DETAILS, jsonObject, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                try {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String stringResponse = response.body().string();
                                Log.i("JSON", stringResponse + "");
                                final JSONArray exemptionDetailsList = new JSONArray(stringResponse);
                                Config.setExemptionDetails(exemptionDetailsList);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //stuff that updates ui
                                        addData(exemptionDetailsList);
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void addData(JSONArray exemptionDetailsList) {
        customListAdapter = new CustomListAdapter(ClearanceListActivity.this, exemptionDetailsList, 2);
        lvMainList.setAdapter(customListAdapter);
        pDialog.hide();
    }

    private void sendPostRequest(String etAmount, String etComments, JSONObject singleException) throws JSONException {

        JSONArray subExemptionList = (JSONArray) singleException.get(Config.SUB_EXEMPTION_LIST);

        JSONObject mSingleSubException = subExemptionList.getJSONObject(0);

        JSONArray jsonArrayExemptions = new JSONArray();
        JSONObject mSingleException = new JSONObject();
        mSingleException.put(Config.EXEMPTION_ID, singleException.get(Config.EXEMPTION_ID));
        mSingleException.put("ParentExemptionId", null);
        mSingleException.put(Config.EXEMPTION_NAME, singleException.get(Config.EXEMPTION_NAME));
        mSingleException.put(Config.LIMIT, singleException.get(Config.LIMIT));
        mSingleException.put("Instruction", new JSONArray());
        mSingleException.put("DeclaredAmount", 0);
        mSingleException.put("ActualAmount", 0);
        mSingleException.put("ClearedAmount", 0);
        mSingleException.put("Comment", null);
        mSingleException.put("Status", "DP");
        mSingleException.put("AssessmentYearId", singleException.get("AssessmentYearId"));
        mSingleException.put("CreatedBy", 1);
        mSingleException.put("CreatedDate", "2017-02-28T00:00:00");
        mSingleException.put("DocumentList", null);
        JSONArray mSubExemptionList = new JSONArray();
        JSONObject subExemptionJsonObj = new JSONObject();
        subExemptionJsonObj.put(Config.EXEMPTION_ID, mSingleSubException.get(Config.EXEMPTION_ID));
        subExemptionJsonObj.put("ParentExemptionId", singleException.get(Config.EXEMPTION_ID));
        subExemptionJsonObj.put(Config.EXEMPTION_NAME, mSingleSubException.get(Config.EXEMPTION_NAME));
        subExemptionJsonObj.put(Config.LIMIT, null);
        subExemptionJsonObj.put("Instruction", null);
        subExemptionJsonObj.put("DeclaredAmount", 0);//
        subExemptionJsonObj.put("ActualAmount", 0);
        subExemptionJsonObj.put("ClearedAmount", Double.parseDouble(etAmount));
        subExemptionJsonObj.put("Comment", etComments);//
        subExemptionJsonObj.put("Status", "DP");
        subExemptionJsonObj.put("AssessmentYearId", singleException.get("AssessmentYearId"));
        subExemptionJsonObj.put("CreatedBy", 1);
        subExemptionJsonObj.put("CreatedDate", "2017-02-28T00:00:00");
        subExemptionJsonObj.put("DocumentList", null);
        subExemptionJsonObj.put("SubExemptionList", new JSONArray());
        subExemptionJsonObj.put("$$hashKey", "object:25");
        mSubExemptionList.put(subExemptionJsonObj);
        mSingleException.put("SubExemptionList", mSubExemptionList);

        jsonArrayExemptions.put(mSingleException);


        JSONObject dataToStore = new JSONObject();
        dataToStore.put("Exemptions", jsonArrayExemptions);
        dataToStore.put("token", token);
        dataToStore.put("schedule", "Planned");
        dataToStore.put("empNo", empNo);
        Log.i("dataToStore", dataToStore.toString());
        HTTPClient postReq = new HTTPClient(Config.URL_SAVE_INVESTMENT_DETAILS, dataToStore, new HTTPClient.AsyncResponse() {
            @Override
            public void onResponseGot(final okhttp3.Response response) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Log.i("RESPONSE", response.body().string());
                            jsonArrayRequest(token);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                thread.start();
            }
        });
    }

    private boolean isValidComments(String comments) {
        boolean toReturn;
        if (comments.length() == 0 || comments.equals("") || comments.equals(null)) {
            toReturn = false;
        } else {
            toReturn = true;
        }
        return toReturn;
    }

   /* @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        //mSearchAction = menu.findItem(R.id.action_search);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       *//* if (id == R.id.action_search) {
            searchFields();
        }*//*
        return true;
    }

    private void searchFields() {
        ActionBar action = getSupportActionBar(); //get the actionbar

        if (isSearchOpened) { //test if the search is open

            action.setDisplayShowCustomEnabled(false); //disable a custom view inside the actionbar
            action.setDisplayShowTitleEnabled(true); //show the title in the action bar

            //hides the keyboard
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(edtSeach.getWindowToken(), 0);

            //add the search icon in the action bar
            mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_search));

            isSearchOpened = false;
        } else { //open the search entry

            action.setDisplayShowCustomEnabled(true); //enable it to display a
            // custom view in the action bar.
            action.setCustomView(R.layout.search_layout);//add the custom view
            action.setDisplayShowTitleEnabled(false); //hide the title

            edtSeach = (EditText) action.getCustomView().findViewById(R.id.edtSearch); //the text editor

            //edtSeach.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
            //this is a listener to do a search when the user clicks on search button
            edtSeach.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        doSearch(edtSeach.getText().toString());
                        return true;
                    }
                    return false;
                }
            });


            edtSeach.requestFocus();

            //open the keyboard focused in the edtSearch
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(edtSeach, InputMethodManager.SHOW_IMPLICIT);


            //add the close icon
            mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_close));

            isSearchOpened = true;
        }
    }

    private void doSearch(String text) {
        Log.i("Text", text);
    }*/
}
