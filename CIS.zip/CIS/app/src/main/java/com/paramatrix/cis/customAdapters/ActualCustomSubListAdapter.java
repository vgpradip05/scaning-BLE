package com.paramatrix.cis.customAdapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by pradipkumarv on 10-02-2017.
 */

public class ActualCustomSubListAdapter extends BaseAdapter {

    Activity newActivity;
    JSONArray list;

    public ActualCustomSubListAdapter(Activity newActivity, JSONArray list) {
        this.newActivity = newActivity;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.length();
    }

    @Override
    public Object getItem(int position) {
        JSONObject objToRet = null;
        try {
            objToRet = list.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return objToRet;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater anInflater = newActivity.getLayoutInflater();
        View mViewGp = anInflater.inflate(R.layout.sub_list_item, null);
        JSONObject singleSubException;
        try {
            TextView tvSubExemptionName = (TextView) mViewGp.findViewById(R.id.exemptionSubHead);
            TextView tvActualAmount = (TextView) mViewGp.findViewById(R.id.tvTotal);
            singleSubException = (JSONObject) list.get(position);
            tvSubExemptionName.setText(singleSubException.get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
            if (!singleSubException.get(Config.ACTUALAMOUNT).equals(null)) {
                tvActualAmount.setText(singleSubException.get(Config.ACTUALAMOUNT).toString());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return mViewGp;
    }

}

