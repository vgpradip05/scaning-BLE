package com.paramatrix.cis.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.paramatrix.cis.R;
import com.paramatrix.cis.config.Config;
import com.paramatrix.cis.customAdapters.ActualCustomSubListAdapter;

import org.json.JSONArray;
import org.json.JSONException;

public class SubCategoryActivity extends AppCompatActivity {
    JSONArray subExemptionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Bundle dataBundle = getIntent().getExtras();

        final int position = dataBundle.getInt(Config.POSITION);
        try {
            subExemptionList = (JSONArray) Config.getExemptionDetails().getJSONObject(position).get(Config.SUB_EXEMPTION_LIST);
            ActionBar actionBar = getSupportActionBar();
            actionBar.setTitle(Config.getExemptionDetails().getJSONObject(position).get(Config.EXEMPTION_NAME).toString().replace("\n", "").replace("\r", ""));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final ActualCustomSubListAdapter customListAdapter = new ActualCustomSubListAdapter(SubCategoryActivity.this, subExemptionList);

        final ListView listView = (ListView) findViewById(R.id.lstv_sub_category_list);

        listView.setAdapter(customListAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                Bundle dataBundle = new Bundle();
                dataBundle.putInt(Config.POSITION, position);
                dataBundle.putInt(Config.SUB_EXEMPTION_POSITION, i);
                Intent intent = new Intent(SubCategoryActivity.this, InvestmentDetailsActivity.class);
                intent.putExtras(dataBundle);
                startActivity(intent);
            }
        });

    }
}
