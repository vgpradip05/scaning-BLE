package com.get.jersey;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import com.get.jersey.GroupCreation.MyRegParam;
import com.get.jersey.GroupCreation.contact;

@Path("/expenses")
public class CreateExpenses {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
		ObjectMapper mapper;

		public ObjectMapperProvider(){
			mapper = new ObjectMapper();
			mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		}
		@Override
		public ObjectMapper getContext(Class<?> type) {
			return mapper;
		}
	}
	@JsonIgnoreProperties

	@XmlRootElement
	public static class member {
		@XmlElement public String contactId;
		@XmlElement public String memberName;
		@XmlElement public String memberNumber;
		@XmlElement public String share;
		@XmlElement public String percentage;	   
	}

	@XmlRootElement
	public static class Params {
		@XmlElement public String groupId;
		@XmlElement public String userId;
		@XmlElement public String expensesName;
		@XmlElement public String expensesType;
		@XmlElement public String amount;
		@XmlElement public String splittingType;
		@XmlElement public List<member> members;

	}	

	@POST
	@Path("/createExpenses")


	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)

	public String writeExpenses(final Params input){
		String response = "";

		int retCode = createExpense(input.groupId, input.userId, input.expensesName,input.expensesType,input.amount,input.splittingType,input.members);
		if(retCode == 0){
			response = Utitlity.constructJSON("GroupCreation",true);
		}else if(retCode == 1){
			response = Utitlity.constructJSON("GroupCreation",false, "Already added");
		}else if(retCode == 2){
			response = Utitlity.constructJSON("GroupCreation",false, "Special Characters are not allowed");
		}else if(retCode == 3){
			response = Utitlity.constructJSON("GroupCreation",false, "Error occured");
		}
		return response;

	}

	private int createExpense(String groupId, String userId, String expensesName, String expensesType,String amount ,String splittingType,List<member> members){
		System.out.println("Inside checkCredentials");
		int result = 3;

		if(Utitlity.isNotNull(userId) && Utitlity.isNotNull(groupId) && Utitlity.isNotNull(expensesName)&& Utitlity.isNotNull(expensesType)&& Utitlity.isNotNull(amount)){
			try {
				if(DBConnection.createExpense(groupId,userId, expensesName, expensesType,amount,splittingType,members)){
					System.out.println("Insert Group");
					result = 0;
				}
			} catch(SQLException sqle){
				System.out.println("catch sqle");
				//When Primary key violation occurs that means user is already registered
				if(sqle.getErrorCode() == 1062){
					result = 1;
				} 
				//When special characters are used in name,username or password
				else if(sqle.getErrorCode() == 1064){
					System.out.println(sqle.getErrorCode());
					result = 2;
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Inside checkCredentials catch e ");
				result = 3;
			}
		}else{
			System.out.println("Inside checkCredentials else");
			result = 3;
		}
		return result;
	}

}