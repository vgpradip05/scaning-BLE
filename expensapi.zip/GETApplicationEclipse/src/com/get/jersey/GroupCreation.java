package com.get.jersey;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import com.get.jersey.PostReg.MyRegParam;
import com.sun.jersey.core.util.Base64;

@Path("/group")
public class GroupCreation {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
		ObjectMapper mapper;

		public ObjectMapperProvider(){
			mapper = new ObjectMapper();
			mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		}
		@Override
		public ObjectMapper getContext(Class<?> type) {
			return mapper;
		}
	}
	@JsonIgnoreProperties

	@XmlRootElement
	public static class contact {
		@XmlElement public String contactName;
		@XmlElement public String contactNumber;	   
	}

	@XmlRootElement
	public static class MyRegParam {
		@XmlElement public String userId;
		@XmlElement public String groupName;
		@XmlElement public String groupImage;
		@XmlElement public String status;
		@XmlElement public String createdOn;
		@XmlElement public List<contact> contacts;

	}	

	@POST
	@Path("/createGroup")


	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)

	public String doPostReg(final MyRegParam input){
		String response = "";


		String uploadedFileLocation = "c://xampp/htdocs/GET/group_images/" + input.groupName.replace(" ","")+input.createdOn.substring(0).replace(":", "").replace(",","").replace(" ", "")+".txt";

		// save it
		writeToFile(input.groupImage, uploadedFileLocation);

		int retCode = createGroup(input.userId, input.groupName, uploadedFileLocation,input.status,input.createdOn,input.contacts);
		if(retCode == 0){
			response = Utitlity.constructJSON("GroupCreation",true);
		}else if(retCode == 1){
			response = Utitlity.constructJSON("GroupCreation",false, "Already added");
		}else if(retCode == 2){
			response = Utitlity.constructJSON("GroupCreation",false, "Special Characters are not allowed");
		}else if(retCode == 3){
			response = Utitlity.constructJSON("GroupCreation",false, "Error occured");
		}
		return response;

	}


	private void writeToFile(String groupImage, String uploadedFileLocation) {
		// TODO Auto-generated method stub

		try {

			PrintWriter out = new PrintWriter( uploadedFileLocation );
			out.println( groupImage );
			out.flush();
			out.close();

		} catch (IOException e) {

			e.printStackTrace();
		}

	}


	private int createGroup(String userId, String groupName, String groupImage, String status,String createdOn ,List<contact> contacts){
		System.out.println("Inside checkCredentials");
		int result = 3;

		if(Utitlity.isNotNull(userId) && Utitlity.isNotNull(groupName) && Utitlity.isNotNull(status)){
			try {
				if(DBConnection.insertGroup(userId, groupName, groupImage,status,createdOn,contacts)){
					System.out.println("Insert Group");
					result = 0;
				}
			} catch(SQLException sqle){
				System.out.println("catch sqle");
				//When Primary key violation occurs that means user is already registered
				if(sqle.getErrorCode() == 1062){
					result = 1;
				} 
				//When special characters are used in name,username or password
				else if(sqle.getErrorCode() == 1064){
					System.out.println(sqle.getErrorCode());
					result = 2;
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Inside checkCredentials catch e ");
				result = 3;
			}
		}else{
			System.out.println("Inside checkCredentials else");
			result = 3;
		}
		return result;
	}

}
