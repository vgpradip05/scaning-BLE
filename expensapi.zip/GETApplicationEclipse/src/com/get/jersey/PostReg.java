package com.get.jersey;

import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
//Path: http://localhost/<appln-folder-name>/postreg
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
@Path("/register")

public class PostReg {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
		ObjectMapper mapper;

		public ObjectMapperProvider(){
			mapper = new ObjectMapper();
			mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		}
		@Override
		public ObjectMapper getContext(Class<?> type) {
			return mapper;
		}
	}

	@XmlRootElement
	public static class MyRegParam {
		@XmlElement public String name;
		@XmlElement public String emailId;
		@XmlElement public String password;
	}	

	@POST
	@Path("/doRegister")

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)

	public String doPostReg(final MyRegParam input){
		String response = "";
		System.out.println("Inside doLogin "+input.name+"  "+input.password);
		int retCode = registerUser(input.name, input.emailId, input.password);
		if(retCode == 0){
			response = Utitlity.constructJSON("register",true);
		}else if(retCode == 1){
			response = Utitlity.constructJSON("register",false, "You are already registered");
		}else if(retCode == 2){
			response = Utitlity.constructJSON("register",false, "Special Characters are not allowed in Username and Password");
		}else if(retCode == 3){
			response = Utitlity.constructJSON("register",false, "Error occured");
		}
		return response;

	}


	private int registerUser(String name, String emailId, String pwd){
		System.out.println("Inside checkCredentials");
		int result = 3;
		System.out.println("Inside register user"+emailId);
		if(Utitlity.isNotNull(emailId) && Utitlity.isNotNull(pwd)){
			try {
				if(DBConnection.insertUser(name, emailId, pwd)){
					System.out.println("RegisterUSer if");
					result = 0;
				}
			} catch(SQLException sqle){
				System.out.println("catch sqle");
				//When Primary key violation occurs that means user is already registered
				if(sqle.getErrorCode() == 1062){
					result = 1;
				} 
				//When special characters are used in name,username or password
				else if(sqle.getErrorCode() == 1064){
					System.out.println(sqle.getErrorCode());
					result = 2;
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Inside checkCredentials catch e ");
				result = 3;
			}
		}else{
			System.out.println("Inside checkCredentials else");
			result = 3;
		}
		return result;
	}
}
