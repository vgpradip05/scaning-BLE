package com.get.jersey;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import com.get.jersey.GroupCreation.MyRegParam;
import com.get.jersey.GroupCreation.contact;

@Path("/deleteGroup")
public class DeleteGroup {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
	   ObjectMapper mapper;

	   public ObjectMapperProvider(){
	       mapper = new ObjectMapper();
	       mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
	   }
	   @Override
	   public ObjectMapper getContext(Class<?> type) {
	       return mapper;
	   }
	}	
	@XmlRootElement
	public static class GroupDetails {
	    @XmlElement public String groupId;       
	}
	
	@POST
	@Path("/deleteGroupDetails")
	

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	
	public String updategroupdetails(final GroupDetails input){
        String response = "";
        
        int retCode = deleteGroup(input.groupId);
        if(retCode == 0){
            response = Utitlity.constructJSON("Deleted",true);
        }else if(retCode == 1){
            response = Utitlity.constructJSON("Deleted",false, "Already Deleted");
        }else if(retCode == 2){
            response = Utitlity.constructJSON("Deleted",false, "Special Characters are not allowed.");
        }else if(retCode == 3){
            response = Utitlity.constructJSON("Deleted",false, "Error occured");
        }
        return response;
 
    }
	
	
    private int deleteGroup(String groupId){
        System.out.println("Inside deleteGroup");
        int result = 3;
        
        if(Utitlity.isNotNull(groupId)){
            try {
                if(DBConnection.deleteGroup(groupId)){
                    System.out.println("Delete");
                    result = 0;
                }
            } catch(SQLException sqle){
                System.out.println("Exception Caught");
                //When Primary key violation occurs that means user is already registered
                if(sqle.getErrorCode() == 1062){
                    result = 1;
                } 
                //When special characters are used in name,username or password
                else if(sqle.getErrorCode() == 1064){
                    System.out.println(sqle.getErrorCode());
                    result = 2;
                }
            }
            catch (Exception e) {
                // TODO Auto-generated catch block
                System.out.println("Inside catch e ");
                result = 3;
            }
        }else{
            System.out.println("Inside else");
            result = 3;
        }
        return result;
    }

}