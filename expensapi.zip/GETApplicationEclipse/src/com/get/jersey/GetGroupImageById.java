package com.get.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
@Path("/groupImage")  
public class GetGroupImageById {
	
	 @GET
	    // Path: http://localhost/<appln-folder-name>/register/doregister
	    @Path("/getGroupImageById")  
	    // Produces JSON as response
	    @Produces(MediaType.APPLICATION_JSON)
	    // Query parameters are parameters: http://localhost/<appln-folder-name>/register/doregister?name=pqrs&username=abc&password=xyz
	 public String getParams(@QueryParam("imgUrl") String imgUrl){
		 System.out.println("get Image");
	        String response = "";
	        response = getGroupImageById(imgUrl);
	        return response;
	 
	    }
	 
	 private String getGroupImageById(String imgUrl){
		 JSONObject str = null;
		 try {
			 str = DBConnection.selectGroupImageById(imgUrl);
				   System.out.println("Select group Image");	 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return str.toString();
	 }

}
