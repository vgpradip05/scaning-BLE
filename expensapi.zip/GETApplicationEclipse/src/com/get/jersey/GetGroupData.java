package com.get.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
@Path("/getGroupDetails")
public class GetGroupData {
	@GET
	// Path: http://localhost/<appln-folder-name>/register/doregister
	@Path("/getGroup")  
	// Produces JSON as response
	@Produces(MediaType.APPLICATION_JSON)
	// Query parameters are parameters: http://localhost/<appln-folder-name>/register/doregister?name=pqrs&username=abc&password=xyz
	public String getParams(@QueryParam("status") String status,@QueryParam("userId") String userId){
		System.out.println("get user Details");
		String response = "";
		response = getGroupDetail(status,userId);
		return response;

	}

	private String getGroupDetail(String status,String userId){
		JSONArray jArray = null;
		try {
			jArray = DBConnection.selectGroup(status,userId);
			System.out.println("Select Group");	 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jArray.toString();
	}

}
