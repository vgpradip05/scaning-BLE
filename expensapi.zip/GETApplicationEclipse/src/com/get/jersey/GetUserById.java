package com.get.jersey;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;

@Path("/getUserId")
public class GetUserById {
	 @GET
	    // Path: http://localhost/<appln-folder-name>/register/doregister
	    @Path("/getId")  
	    // Produces JSON as response
	    @Produces(MediaType.APPLICATION_JSON)
	    // Query parameters are parameters: http://localhost/<appln-folder-name>/register/doregister?name=pqrs&username=abc&password=xyz
	 public String getParams(@QueryParam("id") String id){
		 System.out.println("get user Details");
	        String response = "";
	        response = getRegisterUserId(id);
	        return response;
	 
	    }
	 
	 private String getRegisterUserId(String id){
		 JSONArray jArray = null;
		 try {
			 jArray = DBConnection.selectUser(id);
				   System.out.println("select User");	 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return jArray.toString();
	 }

}
