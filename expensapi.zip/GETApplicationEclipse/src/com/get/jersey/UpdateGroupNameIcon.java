package com.get.jersey;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import com.get.jersey.GroupCreation.MyRegParam;
import com.get.jersey.GroupCreation.contact;

@Path("/updateGroup")
public class UpdateGroupNameIcon {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
	   ObjectMapper mapper;

	   public ObjectMapperProvider(){
	       mapper = new ObjectMapper();
	       mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
	   }
	   @Override
	   public ObjectMapper getContext(Class<?> type) {
	       return mapper;
	   }
	}	
	@XmlRootElement
	public static class GroupDetails {
	    @XmlElement public String groupName;
	    @XmlElement public String groupIcon;
	    @XmlElement public String groupId;	   
	    @XmlElement public String createdon;	   
	    @XmlElement public String identify;	   
	}
	
	@POST
	@Path("/updateGroupParmas")
	

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	
	public String updategroupdetails(final GroupDetails input){
        String response = "";
        int retCode;
        if(input.identify.equals("0")){
        	retCode = updateGroup(input.groupName,null,input.groupId,input.createdon);
        }else{
        	String uploadedFileLocation = "c://xampp/htdocs/GET/group_images/" + input.groupName.replace(" ","")+input.createdon.substring(0).replace(":", "").replace(",","").replace(" ", "")+".txt";
        	writeToFile(input.groupIcon, uploadedFileLocation);
        	retCode = updateGroup(null, uploadedFileLocation,input.groupId,input.createdon);
        }
        if(retCode == 0){
            response = Utitlity.constructJSON("Updated",true);
        }else if(retCode == 1){
            response = Utitlity.constructJSON("Updated",false, "Changes are done");
        }else if(retCode == 2){
            response = Utitlity.constructJSON("Updated",false, "Special Characters are not allowed");
        }else if(retCode == 3){
            response = Utitlity.constructJSON("Updated",false, "Error occured");
        }
        return response;
 
    }
	
	
    private int updateGroup(String groupName, String groupIcon,String groupId,String createdOn){
        System.out.println("Inside checkCredentials");
        int result = 3;
        
        if(Utitlity.isNotNull(groupName) || Utitlity.isNotNull(groupIcon)){
            try {
                if(DBConnection.updateGroup(groupName, groupIcon,groupId,createdOn)){
                    System.out.println("RegisterUSer if");
                    result = 0;
                }
            } catch(SQLException sqle){
                System.out.println("RegisterUSer catch sqle");
                //When Primary key violation occurs that means user is already registered
                if(sqle.getErrorCode() == 1062){
                    result = 1;
                } 
                //When special characters are used in name,username or password
                else if(sqle.getErrorCode() == 1064){
                    System.out.println(sqle.getErrorCode());
                    result = 2;
                }
            }
            catch (Exception e) {
                // TODO Auto-generated catch block
                System.out.println("Inside checkCredentials catch e ");
                result = 3;
            }
        }else{
            System.out.println("Inside checkCredentials else");
            result = 3;
        }
        return result;
    }
    private void writeToFile(String group_image, String uploadedFileLocation) {
		// TODO Auto-generated method stub
    	
    	try {
    	
    		PrintWriter out = new PrintWriter( uploadedFileLocation );
    		    out.println( group_image );
    		    out.flush();
    		    out.close();
    	
		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}

}