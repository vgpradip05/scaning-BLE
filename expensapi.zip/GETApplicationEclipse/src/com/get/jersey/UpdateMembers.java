package com.get.jersey;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

import com.get.jersey.GroupCreation.MyRegParam;
import com.get.jersey.GroupCreation.contact;

@Path("/members")
public class UpdateMembers {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
	   ObjectMapper mapper;

	   public ObjectMapperProvider(){
	       mapper = new ObjectMapper();
	       mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
	   }
	   @Override
	   public ObjectMapper getContext(Class<?> type) {
	       return mapper;
	   }
	}	
	
	@JsonIgnoreProperties
	
	@XmlRootElement
	public static class contact {
	    @XmlElement public String contactName;
	    @XmlElement public String contactNumber;	   
	}
	@XmlRootElement
	public static class GroupDetails {
	    @XmlElement public String userId;
	    @XmlElement public String groupId;	   
	    @XmlElement public String createdon;
	    @XmlElement public String task;
	    @XmlElement public List<contact> contacts;

	    
	}
	
	@POST
	@Path("/updateMembers")
	

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	
	public String updateGroupDetails(final GroupDetails input){
        String response = "";
        
        int retCode = addNewMembers(input.groupId,input.userId,input.createdon,input.task,input.contacts);
        if(retCode == 0){
            response = Utitlity.constructJSON("Update Members",true);
        }else if(retCode == 1){
            response = Utitlity.constructJSON("Update Members",false, "Changes are Done");
        }else if(retCode == 2){
            response = Utitlity.constructJSON("Update Members",false, "Special Characters are not allowed ");
        }else if(retCode == 3){
            response = Utitlity.constructJSON("Update Members",false, "Error occured");
        }
        return response;
 
    }
	
	
    private int addNewMembers(String groupId,String userId,String createdOn,String task,List<contact> contacts){
        System.out.println("Inside checkCredentials");
        int result = 3;
        
        if(Utitlity.isNotNull(groupId) || Utitlity.isNotNull(createdOn)){
            try {
                if(DBConnection.updateMembers(groupId,userId,createdOn,task,contacts)){
                    System.out.println("RegisterUSer if");
                    result = 0;
                }
            } catch(SQLException sqle){
                System.out.println("RegisterUSer catch sqle");
                //When Primary key violation occurs that means user is already registered
                if(sqle.getErrorCode() == 1062){
                    result = 1;
                } 
                //When special characters are used in name,username or password
                else if(sqle.getErrorCode() == 1064){
                    System.out.println(sqle.getErrorCode());
                    result = 2;
                }
            }
            catch (Exception e) {
                // TODO Auto-generated catch block
                System.out.println("Inside checkCredentials catch e ");
                result = 3;
            }
        }else{
            System.out.println("Inside checkCredentials else");
            result = 3;
        }
        return result;
    }

}