package com.get.jersey;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.get.jersey.CreateExpenses.member;
import com.get.jersey.GroupCreation.contact;


public class DBConnection {
	/**
	 * Method to create DB Connection
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("finally")
	public static Connection createConnection() throws Exception {
		Connection con = null;
		try {
			Class.forName(Constants.dbClass);
			con = DriverManager.getConnection(Constants.dbUrl, Constants.dbUser, Constants.dbPwd);
			System.out.println("connections"+con);
		} catch (Exception e) {
			throw e;
		} finally {
			return con;
		}
	}
	/**
	 * Method to check whether uname and pwd combination are correct
	 * 
	 * @param uname
	 * @param pwd
	 * @return
	 * @throws Exception
	 */
	public static boolean checkLogin(String uname, String pwd) throws Exception {
		boolean isUserAvailable = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Statement stmt = dbConn.createStatement();
			String query = "SELECT * FROM user WHERE username = '" + uname
					+ "' AND password=" + "'" + pwd + "'";
			//System.out.println(query);
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				//System.out.println(rs.getString(1) + rs.getString(2) + rs.getString(3));
				isUserAvailable = true;
			}
		} catch (SQLException sqle) {
			throw sqle;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return isUserAvailable;
	}
	/**
	 * Method to insert uname and pwd in DB
	 * 
	 * @param name
	 * @param emailId
	 * @param pwd
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public static boolean insertUser(String name, String emailId, String pwd) throws SQLException, Exception {
		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Statement stmt = dbConn.createStatement();
			String query = "INSERT into users(name, mobileNumber, password) values('"+name+ "',"+"'"
					+ emailId + "','" + pwd + "')";
			//System.out.println(query);
			int records = stmt.executeUpdate(query);
			//System.out.println(records);
			//When record is successfully inserted
			if (records > 0) {
				insertStatus = true;
			}
		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;
	}


	public static boolean createExpense(String groupId, String userId, String expensesName, String expensesType,String amount ,String splittingType,List<member> members)throws SQLException, Exception{

		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Statement statement = dbConn.createStatement();
			String query = "",query2 = "";
			String status = "Active";
			if(expensesType.equals("0")){
				query= "INSERT into expenses(userId, expensesName, expensesType,amount,splittingType,status) values('"+userId+ "',"+"'"
						+ expensesName + "','" + expensesType + "','"+amount +"','"+splittingType +"','"+status +"')";

				int records = statement.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
				if (records > 0) {
					insertStatus = true;
					ResultSet resultSet = statement.getGeneratedKeys();
					resultSet.next();
					int expensesId = resultSet.getInt(1);
					if(splittingType.equals("1")){
						query2= "INSERT into members_in_expenses(expensesId,userId, memberName, memberNumber,percentage,status) values";
						String values = "('"+expensesId+ "','"+ userId + "','" + members.get(0).memberName + "','"+members.get(0).memberNumber +"','"+members.get(0).percentage +"','"+status+"')";

						query2 = query2 + values;
						for(int iterator = 1 ;iterator < members.size();iterator++){

							values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).memberName + "','"+members.get(iterator).memberNumber +"','"+members.get(iterator).percentage +"','"+status+"')";
							if(iterator == members.size()-1){
								values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).memberName + "','"+members.get(iterator).memberNumber +"','"+members.get(iterator).percentage +"','"+status+"')";

							}
							query2 = query2 +","+values;
						}

					}
					else if(splittingType.equals("2")){
						query2= "INSERT into members_in_expenses(expensesId,userId, memberName, memberNumber,share,status) values";
						String values = "('"+expensesId+ "','"+ userId + "','" + members.get(0).memberName + "','"+members.get(0).memberNumber +"','"+members.get(0).share +"','"+status+"')";

						query2 = query2 + values;
						for(int iterator = 1 ;iterator < members.size();iterator++){

							values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).memberName + "','"+members.get(iterator).memberNumber +"','"+members.get(iterator).share +"','"+status+"')";
							if(iterator == members.size()-1){
								values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).memberName + "','"+members.get(iterator).memberNumber +"','"+members.get(iterator).share +"','"+status+"')";

							}
							query2 = query2 +","+values;
						}
					}else{
						query2= "INSERT into members_in_expenses(expensesId,userId, memberName, memberNumber,status) values";
						String values = "('"+expensesId+ "','"+ userId + "','" + members.get(0).memberName + "','"+members.get(0).memberNumber +"','"+status+"')";

						query2 = query2 + values;
						for(int iterator = 1 ;iterator < members.size();iterator++){

							values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).memberName + "','"+members.get(iterator).memberNumber +"','"+status+"')";
							if(iterator == members.size()-1){
								values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).memberName + "','"+members.get(iterator).memberNumber +"','"+status+"')";

							}
							query2 = query2 +","+values;
						}
					}
				}
			}else{
				query= "INSERT into expenses(groupId,userId, expensesName, expensesType,amount,splittingType,status) values('"+groupId+"','"+userId+ "',"+"'"
						+ expensesName + "','" + expensesType + "','"+amount +"','"+splittingType +"','"+status +"')";

				int records = statement.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
				if (records > 0) {
					insertStatus = true;
					ResultSet resultSet = statement.getGeneratedKeys();
					resultSet.next();
					int expensesId = resultSet.getInt(1);
					if(splittingType.equals("1")){
						query2= "INSERT into members_in_expenses(expensesId,userId, contactId,percentage,status) values";
						String values = "('"+expensesId+ "','"+ userId + "','" + members.get(0).contactId +"','"+members.get(0).percentage +"',,'"+status+"')";

						query2 = query2 + values;
						for(int iterator = 1 ;iterator < members.size();iterator++){

							values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).contactId +"','"+members.get(iterator).percentage +"','"+status+"')";
							if(iterator == members.size()-1){
								values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).contactId +"','"+members.get(iterator).percentage +"','"+status+"')";

							}
							query2 = query2 +","+values;
						}
					}else if (splittingType.equals("2")){
						query2= "INSERT into members_in_expenses(expensesId,userId, contactId,share,status) values";
						String values = "('"+expensesId+ "','"+ userId + "','" + members.get(0).contactId +"','"+members.get(0).share +"','"+status+"')";

						query2 = query2 + values;
						for(int iterator = 1 ;iterator < members.size();iterator++){

							values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).contactId +"','"+members.get(iterator).share +"','"+status+"')";
							if(iterator == members.size()-1){
								values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).contactId +"','"+members.get(iterator).share +"','"+status+"')";

							}
							query2 = query2 +","+values;
						}
					}else{
						query2= "INSERT into members_in_expenses(expensesId,userId, contactId,status) values";
						String values = "('"+expensesId+ "','"+ userId + "','" + members.get(0).contactId +"','"+status+"')";

						query2 = query2 + values;
						for(int iterator = 1 ;iterator < members.size();iterator++){

							values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).contactId +"','"+status+"')";
							if(iterator == members.size()-1){
								values = "('"+expensesId+ "','"+ userId + "','" + members.get(iterator).contactId +"','"+status+"')";

							}
							query2 = query2 +","+values;
						}
					}
				}
			}

			//System.out.println(query);
			int records = statement.executeUpdate(query2);
			//System.out.println(records);
			//When record is successfully inserted
			if (records > 0) {
				insertStatus = true;
			}
		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;
	}

	public static boolean updateExpense(String groupId, String userId, String expensesName, String expensesType,String amount ,String splittingType,String task,List<com.get.jersey.EditExpenses.member> members)throws SQLException, Exception{
		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String query;
			Statement stmt = dbConn.createStatement();
			if(Utitlity.isNotNull(groupName)){
				query = "UPDATE create_group_table SET "+
						"groupName="+'"'+groupName+'"'+
						" WHERE groupId="+'"'+groupId+'"'+
						" AND createdon="+'"'+createdOn+'"';
			}else{
				query ="UPDATE create_group_table SET "+
						"groupImage="+'"'+groupIcon+'"'+
						" WHERE groupId="+'"'+groupId+'"'+
						" AND createdon="+'"'+createdOn+'"';
			}
			//System.out.println(query);
			int records = stmt.executeUpdate(query);
			//System.out.println(records);
			//When record is successfully inserted
			if (records > 0) {
				insertStatus = true;
			}
		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;
	
	}
	

	public static JSONArray selectUser(String id) throws SQLException, Exception {
		Connection dbConn = null;
		JSONArray returnArray = new JSONArray();
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Statement stmt = dbConn.createStatement();
			String query = "SELECT * FROM users Where mobileNumber="+id+" OR id="+id+"";
			//System.out.println(query);
			ResultSet records = stmt.executeQuery(query);
			//System.out.println(records);
			//When record is successfully inserted

			while(records.next()){
				//Retrieve by column name
				int  userId  = records.getInt("id");
				String name  = records.getString("name");
				String mobileNo  = records.getString("mobileNumber");
				;

				//Display values
				System.out.print("ID: " + name);
				returnArray .put(new JSONObject()
						.put("id", userId)
						.put("name", name)
						.put("mobileNumber", mobileNo)
						);


			}
			records.close();

			/* Utitlity.constructJSON(returnArray.toString(),true);*/


		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return returnArray;
	}
	public static boolean insertGroup(String userId,String groupName,String groupImage,String status,String createdOn,List<contact> contacts) throws SQLException, Exception {
		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			int resultAto = -1;
			String query = "INSERT into create_group_table(userId, groupName, groupImage,status,createdon) values('"+userId+"',"+"'"
					+ groupName + "','" + groupImage + "','"+status+"','"+createdOn+"')";
			Statement statement = dbConn.createStatement();            
			//System.out.println(query);
			int records = statement.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
			System.out.println(records);
			//When record is successfully inserted

			if (records > 0) {
				//insertStatus = true;
				ResultSet resultSet = statement.getGeneratedKeys();
				resultSet.next();
				resultAto = resultSet.getInt(1);
				String sqlQ = "";
				String privilage = "Member";
				String privilage2 = "Admin";
				String sStatus = "Active";
				sqlQ ="INSERT into contact(groupId,userId,contactName, contactNumber, privilege,status) values";
				String values = "('"+resultAto+"','"+userId+"','"+contacts.get(0).contactName+"','"+contacts.get(0).contactNumber+"','"+privilage+"','"+sStatus+"')";
				sqlQ = sqlQ + values;
				for(int iterator = 1 ;iterator < contacts.size();iterator++){

					values = "('"+resultAto+"','"+userId+"','"+contacts.get(iterator).contactName+"','"+contacts.get(iterator).contactNumber+"','"+privilage+"','"+sStatus+"')";
					if(iterator == contacts.size()-1){
						values = "('"+resultAto+"','"+userId+"','"+contacts.get(iterator).contactName+"','"+contacts.get(iterator).contactNumber+"','"+privilage2+"','"+sStatus+"')";

					}
					sqlQ = sqlQ +","+values;
				}
				int rows = statement.executeUpdate(sqlQ);
				if(rows == contacts.size()){
					insertStatus = true;
				}

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			/* throw sqle;*/
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;
	}

	public static JSONArray selectGroup(String status,String userId) throws SQLException, Exception {
		Connection dbConn = null;
		JSONArray returnArray = new JSONArray();
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Statement stmt = dbConn.createStatement();
			String query = "SELECT * FROM create_group_table Where status="+status;
			//System.out.println(query);
			ResultSet records = stmt.executeQuery(query);
			//System.out.println(records);
			//When record is successfully inserted
			String statusq = "'Active'";
			String sQuery = "SELECT * FROM contact where userId="+userId+" AND status = "+statusq;
			ResultSet contacts = DBConnection.createConnection().createStatement().executeQuery(sQuery);


			while(records.next()){
				//Retrieve by column name
				int  groupTableGroupId  = records.getInt("groupId");
				int  groupTableuserId = records.getInt("userId");
				String groupName  = records.getString("groupName");
				String groupImage  = records.getString("groupImage");
				String status1  = records.getString("status");
				String createdon  = records.getString("createdon");


				//Display values
				JSONArray contactsArray = new JSONArray();

				while(contacts.next()){

					int contactTableGroupId = contacts.getInt("groupId");
					int  contactTableuserId = contacts.getInt("userId");
					String contactName  = contacts.getString("contactName");
					String contactNumber  = contacts.getString("contactNumber");
					String privilege  = contacts.getString("privilege");
					String status2  = contacts.getString("status");
					int contactId = contacts.getInt("id");

					if(contactTableGroupId == groupTableGroupId){

						contactsArray.put(new JSONObject()
								.put("groupId", contactTableGroupId)
								.put("userId", contactTableuserId)
								.put("contactName", contactName)
								.put("contactNumber", contactNumber)
								.put("privilege", privilege)
								.put("status", status2)
								.put("contactId", contactId)); 

					}


				}
				returnArray .put(new JSONObject()
						.put("groupId", groupTableGroupId)
						.put("userId", groupTableuserId)
						.put("groupName", groupName)
						.put("groupImage", groupImage)
						.put("status", status1)
						.put("createdon", createdon)
						.put("contacts", contactsArray)
						);
				contacts.beforeFirst();
			}
			records.close();

			/* Utitlity.constructJSON(returnArray.toString(),true);*/


		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return returnArray;
	}
	
	
	public static JSONArray selectExpenses(String status,String userId,String expensesType)throws SQLException, Exception {
		Connection dbConn = null;
		JSONArray returnArray = new JSONArray();
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Statement stmt = dbConn.createStatement();
			String query = "SELECT * FROM expenses Where status="+status + " AND expensesType = "+expensesType;
			//System.out.println(query);
			ResultSet records = stmt.executeQuery(query);
			//System.out.println(records);
			//When record is successfully inserted
			String statusq = "'Active'";
			String sQuery = "SELECT * FROM members_in_expenses where userId="+userId+" AND status = "+statusq;
			ResultSet members = DBConnection.createConnection().createStatement().executeQuery(sQuery);


			while(records.next()){
				//Retrieve by column name
				int  expensesTableExpensesId  = records.getInt("expensesId");
				int  expensesTableGroupId  = records.getInt("groupId");
				int  expensesTableuserId = records.getInt("userId");
				String expensesName  = records.getString("expensesName");
				int amount  = records.getInt("amount");



				//Display values
				JSONArray membersArray = new JSONArray();

				while(members.next()){

					int memberTableExpensesId = members.getInt("expensesId");
					int  memberTableuserId = members.getInt("userId");
					int  memberTableContactId = members.getInt("contactId");
					String memberName  = members.getString("memberName");
					String memberNumber  = members.getString("memberNumber");
					String percentage  = members.getString("percentage");
					String share  = members.getString("share");
					int memberId = members.getInt("memberId");

					if(memberTableExpensesId == expensesTableExpensesId){

						membersArray.put(new JSONObject()
								.put("expensesId", memberTableExpensesId)
								.put("userId", memberTableuserId)
								.put("contactId", memberTableContactId)
								.put("memberName", memberName)
								.put("memberNumber", memberNumber)
								.put("percentage", percentage)
								.put("share", share)
								.put("memberId", memberId)); 

					}


				}
				returnArray .put(new JSONObject()
						.put("expensesId", expensesTableExpensesId)
						.put("groupId", expensesTableGroupId)
						.put("userId", expensesTableuserId)
						.put("expensesName", expensesName)
						.put("amount", amount)
						.put("members", membersArray)
						);
				members.beforeFirst();
			}
			records.close();
			 Utitlity.constructJSON(returnArray.toString(),true);


		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return returnArray;
	}
	
	
	
	
	
	
	public static JSONArray selectGroupId(String userId,String groupId) throws SQLException, Exception {

		Connection dbConn = null;
		JSONArray returnArray = new JSONArray();
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Statement stmt = dbConn.createStatement();
			String query = "SELECT * FROM create_group_table Where groupId="+userId+" AND userId="+groupId+"";
			//System.out.println(query);
			ResultSet records = stmt.executeQuery(query);
			//System.out.println(records);
			//When record is successfully inserted

			while(records.next()){
				//Retrieve by column name
				String group_name  = records.getString("groupName");
				String group_image  = records.getString("groupImage");
				String status  = records.getString("status");

				//Display values

				returnArray .put(new JSONObject()
						.put("groupId", groupId)
						.put("userId", userId)
						.put("groupName", group_name)
						.put("groupImage", group_image)
						.put("status", status));


			}
			records.close();            
			/* Utitlity.constructJSON(returnArray.toString(),true);*/


		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return returnArray;
	}

	public static boolean updatePrivilege(String contactId,String task) throws SQLException, Exception {
		Connection dbConn = null;
		boolean toReturn = false ;
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Statement stmt = dbConn.createStatement();
			String query;
			String privilege1 = "\"Admin\"";
			String privilege2 = "\"Member\"";
			if(task.equals("A")){
				query = "UPDATE contact set privilege = " + privilege1 +" where id = "+contactId;
			}else{
				query = "UPDATE contact set privilege = " + privilege2 +" where id = "+contactId;
			}
			int records = stmt.executeUpdate(query);

			if(records >0){
				toReturn = true;
			}



		}catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally{
			if (dbConn != null) {
				dbConn.close();
			}
		}

		return toReturn;
	}


	public static boolean updateGroup(String groupName, String groupIcon,String groupId,String createdOn) throws SQLException {
		// TODO Auto-generated method stub
		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String query;
			Statement stmt = dbConn.createStatement();
			if(Utitlity.isNotNull(groupName)){
				query = "UPDATE create_group_table SET "+
						"groupName="+'"'+groupName+'"'+
						" WHERE groupId="+'"'+groupId+'"'+
						" AND createdon="+'"'+createdOn+'"';
			}else{
				query ="UPDATE create_group_table SET "+
						"groupImage="+'"'+groupIcon+'"'+
						" WHERE groupId="+'"'+groupId+'"'+
						" AND createdon="+'"'+createdOn+'"';
			}
			//System.out.println(query);
			int records = stmt.executeUpdate(query);
			//System.out.println(records);
			//When record is successfully inserted
			if (records > 0) {
				insertStatus = true;
			}
		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;

	}
	public static boolean updateMembers(String groupId, String userId ,String createdOn, String task,List<com.get.jersey.UpdateMembers.contact> contacts) throws SQLException {
		// TODO Auto-generated method stub
		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
				System.out.println("database connection Insert"+dbConn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Statement stmt = dbConn.createStatement();
			String sqlQ = "";
			String privilage = "None";
			String sstatus = "Active";
			if(task.equals("A")){
				sqlQ ="INSERT into contact(groupId,userId,contactName, contact_number, privilege,status) values";
				String values = "('"+groupId+"','"+userId+"','"+contacts.get(0).contactName+"','"+contacts.get(0).contactNumber+"','"+privilage+"','"+sstatus+"')";
				sqlQ = sqlQ + values;
				for(int iterator = 1 ;iterator < contacts.size();iterator++){

					values = "('"+groupId+"','"+userId+"','"+contacts.get(iterator).contactName+"','"+contacts.get(iterator).contactNumber+"','"+privilage+"','"+sstatus+"')";
					sqlQ = sqlQ +","+values;
				}
			}else{
				sqlQ ="UPDATE contact SET status =" +'"'+"Q"+'"'+ " WHERE groupId = " +'"'+groupId+'"'+ " AND" +" (" ;
				String values =	"(contactName = " +'"'+contacts.get(0).contactName+'"'+" AND" + " contactNumber = " +'"'+contacts.get(0).contactNumber+'"'+ ")";
				sqlQ = sqlQ + values;
				for(int iterator = 1 ;iterator < contacts.size();iterator++){

					values = 	"(contactName = " +'"'+contacts.get(iterator).contactName+'"'+" AND" + " contactNumber = " +'"'+contacts.get(iterator).contactNumber+'"'+ ")";
					sqlQ = sqlQ +" OR"+values;
				}
				sqlQ = sqlQ +" )";   	
			}
			//System.out.println(query);
			int records = stmt.executeUpdate(sqlQ);
			//System.out.println(records);
			//When record is successfully inserted
			if (records > 0) {
				insertStatus = true;
			}
		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;
	}
	public static boolean deleteGroup(String groupId) throws SQLException {
		// TODO Auto-generated method stub
		boolean insertStatus = false;
		Connection dbConn = null;
		try {
			try {
				dbConn = DBConnection.createConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String query;
			Statement statement = dbConn.createStatement();

			query = "UPDATE create_group_table SET "+
					"status="+'"'+"R"+'"'+
					" WHERE groupId="+'"'+groupId+'"';
			//System.out.println(query);
			int records = statement.executeUpdate(query);
			//System.out.println(records);
			//When record is successfully inserted
			if (records > 0) {
				insertStatus = true;
			}
		} catch (SQLException sqle) {
			//sqle.printStackTrace();
			throw sqle;
		} catch (Exception e) {
			//e.printStackTrace();
			// TODO Auto-generated catch block
			if (dbConn != null) {
				dbConn.close();
			}
			throw e;
		} finally {
			if (dbConn != null) {
				dbConn.close();
			}
		}
		return insertStatus;

	}
	public static JSONObject selectGroupImageById(String imgUrl) {
		// TODO Auto-generated method stub
		BufferedReader bufferedReader = null;
		String imgString = "";
		try {

			String sCurrentLine;

			bufferedReader = new BufferedReader(new FileReader(imgUrl));

			while ((sCurrentLine = bufferedReader.readLine()) != null) {
				imgString = imgString + sCurrentLine;			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bufferedReader != null)
					bufferedReader.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		JSONObject objToRet = null;
		try {
			objToRet = new JSONObject().put("imgString", imgString);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objToRet;
	}
}
