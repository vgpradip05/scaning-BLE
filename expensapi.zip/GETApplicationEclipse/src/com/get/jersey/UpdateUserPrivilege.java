package com.get.jersey;

import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jettison.json.JSONArray;

@Path("/updateUserPrivilege")  
public class UpdateUserPrivilege {
	@Provider
	public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
	{
	   ObjectMapper mapper;

	   public ObjectMapperProvider(){
	       mapper = new ObjectMapper();
	       mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
	   }
	   @Override
	   public ObjectMapper getContext(Class<?> type) {
	       return mapper;
	   }
	}	
	
	@JsonIgnoreProperties
	
	@XmlRootElement
	public static class contactDetails {
	    @XmlElement public String contactId;
	    @XmlElement public String task;	   
	}
	
	@POST
	@Path("/updateMembers")
	

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	
	 public String startMethod(contactDetails input){
		 System.out.println("get user Details");
	        String response = "";
	
	        int retCode = updatePrivilege(input.contactId,input.task);
	        if(retCode == 0){
	            response = Utitlity.constructJSON("register",true);
	        }else if(retCode == 1){
	            response = Utitlity.constructJSON("register",false, "You are already registered");
	        }else if(retCode == 2){
	            response = Utitlity.constructJSON("register",false, "Special Characters are not allowed in Username and Password");
	        }else if(retCode == 3){
	            response = Utitlity.constructJSON("register",false, "Error occured");
	        }
	        return response;

	    }
	 
	 private int updatePrivilege(String contactId,String task){
		 JSONArray str = null;
		 int result = 3;
	        
	        if(Utitlity.isNotNull(contactId) && Utitlity.isNotNull(task)){
	            try {
	                if(DBConnection.updatePrivilege(contactId, task)){
	                    System.out.println("update user privilege");
	                    result = 0;
	                }
	            } catch(SQLException sqle){
	                System.out.println("RegisterUSer catch sqle");
	                //When Primary key violation occurs that means user is already registered
	                if(sqle.getErrorCode() == 1062){
	                    result = 1;
	                } 
	                //When special characters are used in name,username or password
	                else if(sqle.getErrorCode() == 1064){
	                    System.out.println(sqle.getErrorCode());
	                    result = 2;
	                }
	            }
	            catch (Exception e) {
	                // TODO Auto-generated catch block
	                System.out.println("Inside checkCredentials catch e ");
	                result = 3;
	            }
	        }else{
	            System.out.println("Inside checkCredentials else");
	            result = 3;
	        }
	        return result;
	 }

}
