package com.get.jersey;

public class Constants {
	public static String dbClass = "com.mysql.jdbc.Driver";
    private static String dbName= "group_expenses_tracker";
    public static String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    public static String dbUser = "root";
    public static String dbPwd = "";

}
