package com.get.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
@Path("/getGroupById")  
public class GetGroupById {
	
	 @GET
	    // Path: http://localhost/<appln-folder-name>/register/doregister
	    @Path("/getGroupDetails")  
	    // Produces JSON as response
	    @Produces(MediaType.APPLICATION_JSON)
	    // Query parameters are parameters: http://localhost/<appln-folder-name>/register/doregister?name=pqrs&username=abc&password=xyz
	 public String getParmas(@QueryParam("userId") String userId,@QueryParam("groupId") String groupId){
		 System.out.println("get user Details");
	        String response = "";
	        response = getGroupById(userId,groupId);
	        return response;
	 
	    }
	 
	 private String getGroupById(String userId,String groupId){
		 JSONArray str = null;
		 try {
			 str = DBConnection.selectGroupId(userId,groupId);
				   System.out.println("selectGroup");	 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return str.toString();
	 }

}
